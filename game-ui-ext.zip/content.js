// 임시(placeholder) content.js - 실제 content.js로 교체하세요.
(function () {
  if (window.__gameUiExtLoaded) return;
  window.__gameUiExtLoaded = true;
  let box = null;
  function toggle() {
    if (box) { box.remove(); box = null; return; }
    box = document.createElement('div');
    box.textContent = '게임기 오버레이 (임시 content.js)';
    box.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;background:#222;color:#fff;padding:12px 16px;border-radius:8px;font:14px sans-serif;';
    (document.body || document.documentElement).appendChild(box);
  }
  chrome.runtime.onMessage.addListener((m) => { if (m && m.t === 'toggle') toggle(); });
})();
