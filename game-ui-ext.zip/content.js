(function () {
  if (window.__gameUiExtLoaded) return;
  window.__gameUiExtLoaded = true;

  const send = (m) => new Promise((res) => {
    try { chrome.runtime.sendMessage(m, (r) => res(chrome.runtime.lastError ? { ok: false, err: 'EXT' } : r || { ok: false })); }
    catch (e) { res({ ok: false, err: 'EXT' }); }
  });

  // ---- 폴더 사이트(백그라운드 탭)에서는 로그인 후 자동으로 닫히게 ----
  if (location.host === 'folio.itt.link') {
    send({ t: 'amSeek' }).then((r) => {
      if (r && r.v) {
        const iv = setInterval(() => {
          if (document.querySelector('[id^="BBSA"]') || /CMMNTY_\d+/.test(document.documentElement.innerHTML)) {
            clearInterval(iv); send({ t: 'seekDone' });
          }
        }, 1500);
      }
    });
  }

  function start() {
    if (document.getElementById('game-ui-ext-host')) return;

    // 폰트는 shadow 밖(문서)에 등록해야 적용됨
    try {
      const fs = document.createElement('style');
      fs.textContent = '@font-face{font-family:"GameUIFont";src:url("' + chrome.runtime.getURL('font.woff2') + '") format("woff2");font-display:swap}';
      (document.head || document.documentElement).appendChild(fs);
    } catch (e) {}

    const host = document.createElement('div');
    host.id = 'game-ui-ext-host';
    host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;';
    const root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `
<style>
*{box-sizing:border-box}
.wrap{position:fixed;inset:0;pointer-events:none;font-family:"GameUIFont",system-ui,sans-serif;color:#222}
.hide .console,.hide .card{display:none}
.console{pointer-events:auto;position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:320px;background:linear-gradient(160deg,#7b8cff,#4a5bd8);border-radius:22px 22px 60px 22px;padding:16px 18px 20px;box-shadow:0 12px 40px rgba(0,0,0,.45),inset 0 -6px 0 rgba(0,0,0,.18);user-select:none}
.bar{display:flex;justify-content:space-between;align-items:center;color:#fff;font-size:13px;cursor:move;margin-bottom:8px}
.x{pointer-events:auto;background:rgba(0,0,0,.25);color:#fff;border:0;border-radius:50%;width:22px;height:22px;cursor:pointer;font-size:13px;line-height:22px;padding:0}
.screenbox{background:#2b2f4a;border-radius:10px 10px 28px 10px;padding:12px}
canvas{display:block;width:100%;background:#9bbc0f;image-rendering:pixelated;border-radius:4px}
.score{color:#cfd3ff;font-size:12px;text-align:center;margin-top:6px}
.pad{display:flex;justify-content:space-between;align-items:center;margin-top:14px}
.dp{display:grid;grid-template-columns:repeat(3,38px);grid-template-rows:repeat(3,38px);gap:2px}
.dp button,.ab{border:0;background:#1f2340;color:#fff;cursor:pointer;font-size:14px;border-radius:8px}
.dp button:active,.ab:active{background:#0e1128}
.ab{width:64px;height:64px;border-radius:50%;background:#e8476a;box-shadow:0 4px 0 #a02a45;font-size:13px}
.card{pointer-events:auto;position:absolute;right:20px;bottom:20px;width:300px;max-height:60vh;background:#fff;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.35);overflow:hidden;display:flex;flex-direction:column}
.ch{background:#4a5bd8;color:#fff;padding:8px 12px;font-size:13px;display:flex;justify-content:space-between;align-items:center}
.cb{padding:12px;overflow:auto;font-size:13px;line-height:1.5}
.cb h4{margin:0 0 4px;font-size:15px}
.meta{color:#888;font-size:11px;margin-bottom:8px}
.cb img{max-width:100%;border-radius:6px;margin-top:6px}
.cf{display:flex;gap:6px;padding:8px 12px;border-top:1px solid #eee;align-items:center}
.cf button{border:0;background:#eef0ff;color:#334;border-radius:6px;padding:5px 10px;cursor:pointer;font-family:inherit}
.cf span{flex:1;text-align:center;font-size:11px;color:#888}
a.lnk{color:#4a5bd8;word-break:break-all}
</style>
<div class="wrap" id="w">
  <div class="console" id="con">
    <div class="bar" id="drag"><span>🎮 게임기</span><button class="x" id="cx">✕</button></div>
    <div class="screenbox"><canvas id="cv" width="240" height="192"></canvas><div class="score" id="sc">방향키/버튼으로 시작</div></div>
    <div class="pad">
      <div class="dp">
        <span></span><button data-d="U">▲</button><span></span>
        <button data-d="L">◀</button><span></span><button data-d="R">▶</button>
        <span></span><button data-d="D">▼</button><span></span>
      </div>
      <button class="ab" id="ab">START</button>
    </div>
  </div>
  <div class="card" id="card">
    <div class="ch"><span id="ct">게시물</span><button class="x" id="cc">✕</button></div>
    <div class="cb" id="cb">불러오는 중…</div>
    <div class="cf"><button id="pv">◀</button><span id="pg"></span><button id="nx">▶</button><button id="rf">⟳</button></div>
  </div>
</div>`;
    (document.body || document.documentElement).appendChild(host);
    const $ = (id) => root.getElementById(id);

    // 표시/숨김 토글 (아이콘 클릭)
    chrome.runtime.onMessage.addListener((m) => {
      if (m && m.t === 'toggle') $('w').classList.toggle('hide');
    });
    $('cx').onclick = () => { $('con').style.display = 'none'; };
    $('cc').onclick = () => { $('card').style.display = 'none'; };

    // 게임기 드래그
    (function () {
      const con = $('con'), bar = $('drag');
      let ox = 0, oy = 0, dr = false;
      bar.addEventListener('mousedown', (e) => {
        if (e.target.id === 'cx') return;
        const r = con.getBoundingClientRect();
        con.style.transform = 'none'; con.style.left = r.left + 'px'; con.style.top = r.top + 'px';
        ox = e.clientX - r.left; oy = e.clientY - r.top; dr = true; e.preventDefault();
      });
      window.addEventListener('mousemove', (e) => { if (dr) { con.style.left = (e.clientX - ox) + 'px'; con.style.top = (e.clientY - oy) + 'px'; } });
      window.addEventListener('mouseup', () => { dr = false; });
    })();

    // ---- 미니 게임 (뱀 게임) ----
    const cv = $('cv'), ctx = cv.getContext('2d');
    const S = 12, W = cv.width / S, H = cv.height / S;
    let snake, dir, nd, food, score, timer = null, over = false, focus = false;
    const best = () => +(localStorage.getItem('gui_best') || 0);
    function reset() {
      snake = [{ x: 10, y: 8 }, { x: 9, y: 8 }, { x: 8, y: 8 }]; dir = nd = 'R'; score = 0; over = false; placeFood();
    }
    function placeFood() {
      do { food = { x: Math.floor(Math.random() * W), y: Math.floor(Math.random() * H) }; }
      while (snake.some((s) => s.x === food.x && s.y === food.y));
    }
    function draw() {
      ctx.fillStyle = '#9bbc0f'; ctx.fillRect(0, 0, cv.width, cv.height);
      ctx.fillStyle = '#0f380f';
      snake.forEach((s) => ctx.fillRect(s.x * S + 1, s.y * S + 1, S - 2, S - 2));
      ctx.fillStyle = '#306230'; ctx.fillRect(food.x * S + 2, food.y * S + 2, S - 4, S - 4);
      if (over) {
        ctx.fillStyle = 'rgba(15,56,15,.75)'; ctx.fillRect(0, 70, cv.width, 52);
        ctx.fillStyle = '#9bbc0f'; ctx.font = '16px sans-serif'; ctx.textAlign = 'center';
        ctx.fillText('GAME OVER', cv.width / 2, 100);
      }
    }
    function tick() {
      dir = nd;
      const h = { x: snake[0].x, y: snake[0].y };
      if (dir === 'U') h.y--; else if (dir === 'D') h.y++; else if (dir === 'L') h.x--; else h.x++;
      if (h.x < 0 || h.y < 0 || h.x >= W || h.y >= H || snake.some((s) => s.x === h.x && s.y === h.y)) {
        over = true; clearInterval(timer); timer = null;
        try { if (score > best()) localStorage.setItem('gui_best', score); } catch (e) {}
        $('sc').textContent = '점수 ' + score + ' · 최고 ' + best() + ' · START로 다시';
        $('ab').textContent = 'START'; draw(); return;
      }
      snake.unshift(h);
      if (h.x === food.x && h.y === food.y) { score++; placeFood(); } else snake.pop();
      $('sc').textContent = '점수 ' + score + ' · 최고 ' + best();
      draw();
    }
    function begin() {
      if (timer) return;
      if (over || !snake) reset();
      timer = setInterval(tick, 140); $('ab').textContent = 'PAUSE';
    }
    function toggleRun() {
      if (timer) { clearInterval(timer); timer = null; $('ab').textContent = 'START'; } else begin();
    }
    function turn(d) {
      const opp = { U: 'D', D: 'U', L: 'R', R: 'L' };
      if (d !== opp[dir]) nd = d;
      begin();
    }
    reset(); draw();
    $('ab').onclick = toggleRun;
    root.querySelectorAll('.dp button').forEach((b) => { b.onclick = () => turn(b.dataset.d); });
    $('con').addEventListener('mouseenter', () => { focus = true; });
    $('con').addEventListener('mouseleave', () => { focus = false; });
    window.addEventListener('keydown', (e) => {
      if (!focus) return;
      const map = { ArrowUp: 'U', ArrowDown: 'D', ArrowLeft: 'L', ArrowRight: 'R', w: 'U', s: 'D', a: 'L', d: 'R' };
      if (map[e.key]) { e.preventDefault(); e.stopPropagation(); turn(map[e.key]); }
      else if (e.key === ' ') { e.preventDefault(); toggleRun(); }
    }, true);

    // ---- 게시물 카드 ----
    let items = [], idx = 0;
    const strip = (h) => { try { return new DOMParser().parseFromString(String(h || ''), 'text/html').body.textContent.trim(); } catch (e) { return ''; } };
    function esc(t) { return String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
    function showMsg(html) { $('cb').innerHTML = html; $('pg').textContent = ''; }
    function render() {
      if (!items.length) return showMsg('게시물이 없어요.');
      const it = items[idx];
      let h = '<h4>' + esc(it.title || '(제목 없음)') + '</h4><div class="meta">' + esc(it.who) + ' · ' + esc(it.date) + '</div>';
      h += '<div>' + esc(strip(it.body)).replace(/\n/g, '<br>') + '</div>';
      (it.links || []).slice(0, 3).forEach((l) => { h += '<div><a class="lnk" target="_blank" rel="noopener" href="' + esc(l) + '">' + esc(l) + '</a></div>'; });
      (it.imgs || []).slice(0, 2).forEach((im) => { if (im.u) h += '<img src="' + esc(im.u) + '">'; });
      $('cb').innerHTML = h; $('pg').textContent = (idx + 1) + ' / ' + items.length;
    }
    async function load() {
      showMsg('불러오는 중…');
      let saved = {};
      try { saved = (await chrome.storage.local.get('boards')).boards || {}; } catch (e) {}
      let b = saved.story || saved.share;
      if (!b) {
        const d = await send({ t: 'discover', sel: { mode: 'first' } });
        if (!d.ok) return needLogin(d.err);
        b = d.d.story || d.d.share;
        $('ct').textContent = '📌 ' + (d.d.name || '게시물');
        try { await chrome.storage.local.set({ boards: d.d }); } catch (e) {}
      }
      const r = await send({ t: 'board', b: b });
      if (!r.ok) return needLogin(r.err);
      items = r.items || []; idx = 0; render();
    }
    function needLogin(err) {
      if (err === 'EXT') return showMsg('확장 프로그램이 업데이트됐어요. 페이지를 새로고침 해주세요.');
      showMsg('톡톡클래스 로그인이 필요해요.<br><br><button id="lg" style="border:0;background:#4a5bd8;color:#fff;border-radius:6px;padding:6px 12px;cursor:pointer">로그인 · 주소 찾기</button><div class="meta" style="margin-top:8px">(' + esc(err || '') + ')</div>');
      const b = root.getElementById('lg');
      if (b) b.onclick = async () => {
        try { await chrome.storage.local.remove('boards'); } catch (e) {}
        await send({ t: 'seek' }); showMsg('새 탭에서 로그인한 뒤 ⟳ 를 눌러주세요.');
      };
    }
    $('pv').onclick = () => { if (items.length) { idx = (idx - 1 + items.length) % items.length; render(); } };
    $('nx').onclick = () => { if (items.length) { idx = (idx + 1) % items.length; render(); } };
    $('rf').onclick = load;
    load();
  }

  if (document.body) start();
  else document.addEventListener('DOMContentLoaded', start);
})();
