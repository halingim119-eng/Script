const FOLIO_BASE = 'https://folio.itt.link';
const FOLIO_MAIN = FOLIO_BASE + '/cop/cmy/index.do';

chrome.action.onClicked.addListener((tab) => {
  if (tab.id != null) chrome.tabs.sendMessage(tab.id, { t: 'toggle' }).catch(() => {});
});

// 처음 설치하면 톡톡클래스를 한 번 열어서, 들어온 화면에서 튜토리얼이 바로 뜨게 한다.
chrome.runtime.onInstalled.addListener((d) => {
  if (d && d.reason === 'install') chrome.tabs.create({ url: FOLIO_MAIN });
});

// ===== 이야기방/공유방 주소 자동 찾기 (로그인 세션만 있으면 됨) =====
const nwUnesc = (t) => String(t || '').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
function nwParseNav(html) {
  const out = {};
  const re = /<li[^>]*\sid="(BBSA\d+)"[^>]*>\s*<a[^>]+href="([^"]+)"/g;
  let m;
  while ((m = re.exec(html))) {
    try {
      const u = new URL(nwUnesc(m[2]), FOLIO_BASE);
      const bbsId = u.searchParams.get('bbsId'), trgetId = u.searchParams.get('trgetId');
      if (bbsId && trgetId && !out[m[1]]) out[m[1]] = { bbsId: bbsId, trgetId: trgetId };
    } catch (e) {}
  }
  return out;
}
async function nwGet(p) {
  const r = await fetch(FOLIO_BASE + p, { credentials: 'include' });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  if (r.url && r.url.indexOf(FOLIO_BASE) !== 0) throw new Error('LOGIN');
  return { html: await r.text(), url: r.url || '' };
}
function nwLinks(html) {
  const links = [], seen = {};
  const re = /<a[^>]+href="(\/cmy\/[^"?#]+\.do)[^"]*"[^>]*>([\s\S]*?)<\/a>/g;
  let m;
  while ((m = re.exec(html))) {
    if (seen[m[1]]) continue;
    const st = m[2].match(/class="st"[^>]*>([\s\S]*?)</);
    const name = nwUnesc((st ? st[1] : m[2].replace(/<[^>]*>/g, ''))).replace(/\s+/g, '');
    if (!name) continue;
    seen[m[1]] = 1;
    links.push({ href: m[1], name: name });
  }
  return links;
}
async function nwDiscover(sel) {
  const home = await nwGet('/cop/cmy/index.do');
  const links = nwLinks(home.html);
  let pick = null;
  if (sel.mode === 'pick' && sel.pick) pick = links.filter((x) => x.href === sel.pick)[0] || null;
  else if (sel.mode === 'name') pick = links.filter((x) => x.name.indexOf(sel.key) > -1)[0] || null;
  if (!pick) pick = links[0] || null;

  let nav = {}, name = '', tid = '';
  const cm = home.html.match(/classId:\s*"(CMMNTY_\d+)"/);
  if (cm) tid = cm[1];
  if (pick) {
    name = pick.name.slice(0, 24);
    const cp = await nwGet(pick.href);
    nav = nwParseNav(cp.html);
    const t = (cp.url + ' ' + cp.html).match(/CMMNTY_\d+/);
    if (t) tid = t[0];
  }
  if (!nav.BBSA20 && !nav.BBSA50 && tid) {
    const hp = await nwGet('/cop/cmy/bbs/selectClassHome.do?trgetId=' + encodeURIComponent(tid) + '&isMenu=Y');
    nav = nwParseNav(hp.html);
  }
  if (!nav.BBSA20 && !nav.BBSA50) throw new Error('NOBOARD');
  return { name: name, story: nav.BBSA20 || null, share: nav.BBSA50 || null };
}

// ===== 게시물 목록 (최대 300개) =====
const BOARD_MAX = 300;
const BOARD_PAGE = 20;
const IMG_RE = /\.(jpe?g|png|gif|bmp|webp)$/i;
async function pullBoard(b) {
  const out = [], seen = {};
  for (let page = 1; page <= 15 && out.length < BOARD_MAX; page++) {
    const p = new URLSearchParams({
      trgetId: b.trgetId, bbsId: b.bbsId, nttNo: '', searchOrdrCode: '', searchOrdrCodeDp: '',
      searchCate: '', searchTextbook: '', searchCnd: 'ALL', pageUnit: String(BOARD_PAGE),
      pageSize: String(BOARD_PAGE), pageIndex: String(page), searchOthbcAt: '', loadingEndYn: 'N',
      ajaxFlag: 'Y', searchWrd: ''
    });
    const r = await fetch(FOLIO_BASE + '/cop/cmy/bbs/selectBoardList.json?' + p.toString(), { credentials: 'include' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    let j;
    try { j = await r.json(); } catch (e) { throw new Error('LOGIN'); }
    const list = (j && j.data && j.data.resultList) || [];
    let added = 0;
    list.forEach((i) => {
      if (!i || !i.frstRegisterId || seen[i.nttNo] || out.length >= BOARD_MAX) return;
      seen[i.nttNo] = 1;
      added++;
      const files = [], imgs = [];
      (i.fileList || []).forEach((f) => {
        const nm = f.orignlFileNm || '';
        if (IMG_RE.test(nm) || IMG_RE.test('.' + (f.fileExtsn || ''))) {
          const cdn = (f.fileCdnUrl && f.fileCdnUrl !== 'null') ? f.fileCdnUrl : f.fileStreWebCours;
          imgs.push({ n: nm, u: (cdn && f.streFileNm) ? cdn + '/' + f.streFileNm : '', id: f.atchFileId, sn: f.fileSn });
        } else {
          files.push({ n: nm, id: f.atchFileId, sn: f.fileSn });
        }
      });
      out.push({
        no: i.nttNo, ord: i.ordrCode || '', dp: (i.ordrCodeDp == null ? '' : String(i.ordrCodeDp)),
        title: i.nttSj || '', who: i.ntcrNm || '',
        date: i.frstRegisterPnttmTmp || '',
        body: String(i.nttCn || '').slice(0, 1200),
        links: (i.linkList || []).map((l) => l.link).filter(Boolean),
        files: files, imgs: imgs
      });
    });
    if (!added) break;
  }
  return out;
}

// ===== 주소 찾으러 백그라운드 탭 열기 (로그인 사이트 → 로그인 → 톡클래스 → 이야기방/공유방) =====
const SEEK_LIMIT = 150000;
async function endSeek(id) {
  const s = (await chrome.storage.local.get('seek')).seek;
  if (s && (id == null || s.tabId === id)) {
    await chrome.storage.local.remove('seek');
    try { await chrome.tabs.remove(s.tabId); } catch (e) {}
  }
}
async function startSeek() {
  const s = (await chrome.storage.local.get('seek')).seek;
  if (s && Date.now() - s.ts < SEEK_LIMIT) return { ok: true, already: true };
  const tab = await chrome.tabs.create({ url: FOLIO_MAIN, active: false });
  await chrome.storage.local.set({ seek: { tabId: tab.id, ts: Date.now() } });
  setTimeout(() => endSeek(tab.id), SEEK_LIMIT);
  return { ok: true };
}
chrome.tabs.onRemoved.addListener((id) => { endSeek(id).catch(() => {}); });

chrome.runtime.onMessage.addListener((m, sender, send) => {
  if (!m) return;
  const fail = (e) => send({ ok: false, err: String((e && e.message) || e) });
  if (m.t === 'board') { pullBoard(m.b).then((items) => send({ ok: true, items: items })).catch(fail); return true; }
  if (m.t === 'discover') { nwDiscover(m.sel || {}).then((d) => send({ ok: true, d: d })).catch(fail); return true; }
  if (m.t === 'classes') { nwGet('/cop/cmy/index.do').then((h) => send({ ok: true, list: nwLinks(h.html) })).catch(fail); return true; }
  if (m.t === 'seek') { startSeek().then(send).catch(fail); return true; }
  if (m.t === 'amSeek') {
    chrome.storage.local.get('seek').then((d) => {
      send({ v: !!(d.seek && sender.tab && d.seek.tabId === sender.tab.id) });
    }).catch(() => send({ v: false }));
    return true;
  }
  if (m.t === 'seekDone') {
    const id = sender.tab && sender.tab.id;
    setTimeout(() => endSeek(id).catch(() => {}), 700);
    send({ ok: true });
  }
});
