(() => {
  if (document.getElementById('gp-overlay-host')) return;

  const host = document.createElement('div');
  host.id = 'gp-overlay-host';
  host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;';
  const root = host.attachShadow({ mode: 'open' });

  root.innerHTML = `
<style>
  :host{all:initial}
  .wrap{position:fixed;inset:0;pointer-events:none}

  /* 게임기: 화면 중앙, 화면의 약 1/2 */
  .pad{
    position:absolute;left:50%;top:50%;
    width:min(50vw, calc(50vh * 920 / 480));
    aspect-ratio:920/480;
    transform:translate(-50%,-50%);
  }
  .pad svg{width:100%;height:100%;display:block;overflow:visible}

  /* 화면 네 구석 하얀 코너 (ㄱ ㄴ) */
  .c{
    position:absolute;width:56px;height:56px;
    filter:drop-shadow(0 0 2px rgba(0,0,0,.45)) drop-shadow(0 2px 6px rgba(0,0,0,.25));
  }
  .tl{left:16px;top:16px;border-left:6px solid #fff;border-top:6px solid #fff;border-top-left-radius:6px}
  .tr{right:16px;top:16px;border-right:6px solid #fff;border-top:6px solid #fff;border-top-right-radius:6px}
  .bl{left:16px;bottom:16px;border-left:6px solid #fff;border-bottom:6px solid #fff;border-bottom-left-radius:6px}
  .br{right:16px;bottom:16px;border-right:6px solid #fff;border-bottom:6px solid #fff;border-bottom-right-radius:6px}
</style>

<div class="wrap">
  <div class="c tl"></div><div class="c tr"></div>
  <div class="c bl"></div><div class="c br"></div>

  <div class="pad">
    <svg viewBox="0 0 920 480" aria-hidden="true">
      <defs>
        <filter id="shBody" x="-10%" y="-10%" width="120%" height="130%">
          <feDropShadow dx="0" dy="1" stdDeviation="0.8" flood-color="#000" flood-opacity=".10"/>
          <feDropShadow dx="0" dy="8" stdDeviation="7" flood-color="#000" flood-opacity=".13"/>
        </filter>
        <filter id="shKey" x="-30%" y="-30%" width="160%" height="170%">
          <feDropShadow dx="0" dy="1" stdDeviation="0.8" flood-color="#000" flood-opacity=".30"/>
          <feDropShadow dx="0" dy="3" stdDeviation="2.5" flood-color="#000" flood-opacity=".10"/>
        </filter>
      </defs>

      <!-- 본체 -->
      <path filter="url(#shBody)" fill="#fff" stroke="rgba(0,0,0,.06)" stroke-width="1.5"
        d="M 460 36 L 400 36 C 370 36 340 36 320 32 C 290 26 270 12 232 12 C 190 12 160 22 132 38 C 70 72 34 130 22 210 C 10 290 4 350 8 400 C 12 448 48 476 94 470 C 142 464 188 412 222 372 C 252 336 290 318 345 318 L 575 318 C 630 318 668 336 698 372 C 732 412 778 464 826 470 C 872 476 908 448 912 400 C 916 350 910 290 898 210 C 886 130 850 72 788 38 C 760 22 730 12 688 12 C 650 12 630 26 600 32 C 580 36 550 36 520 36 L 460 36 Z"/>

      <!-- 방향키 -->
      <g filter="url(#shKey)" fill="#fff">
        <rect x="118" y="65" width="24" height="70" rx="7"/>
        <rect x="95" y="88" width="70" height="24" rx="7"/>
      </g>

      <!-- ABXY 버튼 -->
      <g filter="url(#shKey)" fill="#fff">
        <circle cx="790" cy="69" r="14"/>
        <circle cx="759" cy="100" r="14"/>
        <circle cx="821" cy="100" r="14"/>
        <circle cx="790" cy="131" r="14"/>
      </g>
      <g fill="#9ca3af" font-size="11" font-family="sans-serif" text-anchor="middle" dominant-baseline="central">
        <text x="790" y="69">Y</text>
        <text x="759" y="100">X</text>
        <text x="821" y="100">B</text>
        <text x="790" y="131">A</text>
      </g>
    </svg>
  </div>
</div>`;

  document.documentElement.appendChild(host);
})();
