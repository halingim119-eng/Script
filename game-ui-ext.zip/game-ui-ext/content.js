(() => {
  if (document.getElementById('gp-pad-host')) return;

  const mkHost = (id, z) => {
    const h = document.createElement('div');
    h.id = id;
    h.style.cssText = `all:initial;position:fixed;inset:0;z-index:${z};pointer-events:none;`;
    return { h, root: h.attachShadow({ mode: 'open' }) };
  };

  /* ===== 1) 닌텐도 스위치 모양 게임기: 낮은 z-index → 다른 UI가 위로 올라와서 가리지 않음 ===== */
  const pad = mkHost('gp-pad-host', 1);
  pad.root.innerHTML = `
<style>
  :host{all:initial}
  .pad{
    position:absolute;left:50%;top:50%;
    width:min(60vw, calc(60vh * 1170 / 500));   /* 크기: 60 을 바꾸면 커지고 작아져요 */
    aspect-ratio:1170/500;
    transform:translate(-50%,-50%);
  }
  .pad svg{width:100%;height:100%;display:block;overflow:visible}
</style>
<div class="pad">
<svg viewBox="0 0 1170 500" aria-hidden="true">
  <defs>
    <linearGradient id="gL" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2bd3f4"/><stop offset="1" stop-color="#00a8d3"/></linearGradient>
    <linearGradient id="gR" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff5f6c"/><stop offset="1" stop-color="#e82f3e"/></linearGradient>
    <linearGradient id="gT" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#25272b"/><stop offset="1" stop-color="#0f1012"/></linearGradient>
    <radialGradient id="gBtn" cx="42%" cy="35%" r="70%"><stop offset="0" stop-color="#4b4e54"/><stop offset="1" stop-color="#1e1f22"/></radialGradient>
    <radialGradient id="gCap" cx="40%" cy="32%" r="75%"><stop offset="0" stop-color="#5a5d63"/><stop offset="1" stop-color="#202125"/></radialGradient>
    <radialGradient id="gWell" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#0a0a0b"/><stop offset="1" stop-color="#1b1c1f"/></radialGradient>
    <filter id="shOnly" x="-6%" y="-6%" width="112%" height="130%">
      <feGaussianBlur in="SourceAlpha" stdDeviation="9" result="b"/>
      <feOffset in="b" dy="11" result="o"/>
      <feColorMatrix in="o" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 .38 0" result="s"/>
      <feComposite in="s" in2="SourceAlpha" operator="out"/>
    </filter>
    <filter id="shBtn" x="-40%" y="-40%" width="180%" height="190%">
      <feDropShadow dx="0" dy="2" stdDeviation="1.6" flood-color="#000" flood-opacity=".45"/>
    </filter>
  </defs>

  <!-- 바깥 그림자 (실루엣 바깥쪽에만) -->
  <path filter="url(#shOnly)" fill="#000"
    d="M64 0H1106A64 64 0 0 1 1170 64V436A64 64 0 0 1 1106 500H64A64 64 0 0 1 0 436V64A64 64 0 0 1 64 0Z"/>

  <!-- Joy-Con L -->
  <path fill="url(#gL)" d="M64 0H172V500H64A64 64 0 0 1 0 436V64A64 64 0 0 1 64 0Z"/>
  <path fill="none" stroke="rgba(255,255,255,.35)" stroke-width="2" d="M64 1H172M172 499H64A63 63 0 0 1 1 436V64A63 63 0 0 1 64 1"/>
  <!-- Joy-Con R -->
  <path fill="url(#gR)" d="M998 0H1106A64 64 0 0 1 1170 64V436A64 64 0 0 1 1106 500H998Z"/>
  <path fill="none" stroke="rgba(255,255,255,.35)" stroke-width="2" d="M998 1H1106A63 63 0 0 1 1169 64V436A63 63 0 0 1 1106 499H998"/>

  <!-- 본체(태블릿) + 화면 구멍 -->
  <path fill="url(#gT)" fill-rule="evenodd"
    d="M166 0H1004V500H166Z M263 64H907a8 8 0 0 1 8 8V428a8 8 0 0 1-8 8H263a8 8 0 0 1-8-8V72a8 8 0 0 1 8-8Z"/>
  <rect x="255" y="64" width="660" height="372" rx="8" fill="none" stroke="rgba(255,255,255,.10)" stroke-width="1.5"/>
  <rect x="166" y="0" width="838" height="500" fill="none" stroke="rgba(0,0,0,.55)" stroke-width="2"/>
  <circle cx="585" cy="32" r="4" fill="#2c2e33"/><circle cx="604" cy="32" r="2.4" fill="#2c2e33"/>

  <!-- ===== Joy-Con L ===== -->
  <!-- 마이너스 -->
  <rect x="112" y="31" width="32" height="14" rx="7" fill="url(#gBtn)" filter="url(#shBtn)"/>
  <rect x="122" y="36.5" width="12" height="3" rx="1.5" fill="#d2d5da"/>
  <!-- 왼쪽 스틱 -->
  <circle cx="80" cy="122" r="43" fill="url(#gWell)" stroke="rgba(255,255,255,.18)" stroke-width="1.5"/>
  <circle cx="80" cy="122" r="31" fill="url(#gCap)" filter="url(#shBtn)"/>
  <circle cx="80" cy="122" r="31" fill="none" stroke="#6a6d73" stroke-width="1.5"/>
  <circle cx="80" cy="122" r="25" fill="none" stroke="rgba(255,255,255,.13)" stroke-width="4" stroke-dasharray="1.2 3.6"/><circle cx="80" cy="122" r="17" fill="none" stroke="rgba(255,255,255,.10)" stroke-width="2"/>
  <circle cx="80" cy="122" r="10" fill="none" stroke="rgba(255,255,255,.08)" stroke-width="2"/>
  <!-- 방향 버튼 4개 -->
  <g filter="url(#shBtn)" fill="url(#gBtn)">
    <circle cx="88" cy="294" r="20"/><circle cx="88" cy="372" r="20"/>
    <circle cx="49" cy="333" r="20"/><circle cx="127" cy="333" r="20"/>
  </g>
  <g fill="#d2d5da">
    <polygon points="88,286 96,299 80,299"/><polygon points="88,380 96,367 80,367"/>
    <polygon points="41,333 54,325 54,341"/><polygon points="135,333 122,325 122,341"/>
  </g>
  <!-- 캡처 -->
  <rect x="117" y="429" width="24" height="24" rx="5" fill="url(#gBtn)" filter="url(#shBtn)"/>
  <circle cx="129" cy="441" r="7" fill="none" stroke="#d2d5da" stroke-width="2"/>

  <!-- ===== Joy-Con R ===== -->
  <!-- 플러스 -->
  <rect x="1026" y="31" width="32" height="14" rx="7" fill="url(#gBtn)" filter="url(#shBtn)"/>
  <rect x="1036" y="36.5" width="12" height="3" rx="1.5" fill="#d2d5da"/><rect x="1040.5" y="32" width="3" height="12" rx="1.5" fill="#d2d5da"/>
  <!-- ABXY -->
  <g filter="url(#shBtn)" fill="url(#gBtn)">
    <circle cx="1082" cy="88" r="20"/><circle cx="1082" cy="166" r="20"/>
    <circle cx="1043" cy="127" r="20"/><circle cx="1121" cy="127" r="20"/>
  </g>
  <g fill="#d2d5da" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="19" text-anchor="middle" dominant-baseline="central">
    <text x="1082" y="89">X</text><text x="1082" y="167">B</text><text x="1043" y="128">Y</text><text x="1121" y="128">A</text>
  </g>
  <!-- 오른쪽 스틱 -->
  <circle cx="1090" cy="338" r="43" fill="url(#gWell)" stroke="rgba(255,255,255,.18)" stroke-width="1.5"/>
  <circle cx="1090" cy="338" r="31" fill="url(#gCap)" filter="url(#shBtn)"/>
  <circle cx="1090" cy="338" r="31" fill="none" stroke="#6a6d73" stroke-width="1.5"/>
  <circle cx="1090" cy="338" r="25" fill="none" stroke="rgba(255,255,255,.13)" stroke-width="4" stroke-dasharray="1.2 3.6"/><circle cx="1090" cy="338" r="17" fill="none" stroke="rgba(255,255,255,.10)" stroke-width="2"/>
  <circle cx="1090" cy="338" r="10" fill="none" stroke="rgba(255,255,255,.08)" stroke-width="2"/>
  <!-- 홈 -->
  <circle cx="1042" cy="441" r="15" fill="url(#gBtn)" filter="url(#shBtn)"/>
  <circle cx="1042" cy="441" r="10" fill="none" stroke="#d2d5da" stroke-width="2"/>
  <path d="M1042 436l-5 4.5h1.8v4.5h6.4v-4.5h1.8z" fill="#d2d5da"/>
</svg>

</div>`;

  /* ===== 2) 화면 구석 코너: 항상 맨 위 ===== */
  const cor = mkHost('gp-corner-host', 2147483647);
  cor.root.innerHTML = `
<style>
  :host{all:initial}
  .c{
    position:absolute;width:84px;height:84px;
    filter:drop-shadow(0 0 2px rgba(0,0,0,.45)) drop-shadow(0 2px 6px rgba(0,0,0,.25));
  }
  .tl{left:14px;top:14px;border-left:14px solid #fff;border-top:14px solid #fff;border-top-left-radius:12px}
  .tr{right:14px;top:14px;border-right:14px solid #fff;border-top:14px solid #fff;border-top-right-radius:12px}
  .bl{left:14px;bottom:14px;border-left:14px solid #fff;border-bottom:14px solid #fff;border-bottom-left-radius:12px}
  .br{right:14px;bottom:14px;border-right:14px solid #fff;border-bottom:14px solid #fff;border-bottom-right-radius:12px}
</style>
<div class="c tl"></div><div class="c tr"></div>
<div class="c bl"></div><div class="c br"></div>`;

  document.documentElement.appendChild(pad.h);
  document.documentElement.appendChild(cor.h);
})();
