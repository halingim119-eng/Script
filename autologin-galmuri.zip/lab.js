// 실험실: 어느 사이트에서나 쓸 수 있는 유용한 기능 44개
(function (g) {
  'use strict';

  let C = {
    get: (k, d) => d, set: () => {},
    jget: (k, d) => d, jset: () => {}
  };
  const FONT = "'Galmuri9','Malgun Gothic','Apple SD Gothic Neo',sans-serif";

  // ───────── 공용 도구 ─────────
  function mk(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const pad = (n) => String(n).padStart(2, '0');
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  function sty(id, css) {
    let s = document.getElementById(id);
    if (!css) { if (s) s.remove(); return; }
    if (!s) {
      s = document.createElement('style');
      s.id = id;
      document.documentElement.appendChild(s);
    }
    s.textContent = css;
  }

  async function copy(text) {
    try { await navigator.clipboard.writeText(text); return true; } catch (e) {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.cssText = 'position:fixed;left:-9999px;top:0';
        document.documentElement.appendChild(ta);
        ta.select();
        const ok = document.execCommand('copy');
        ta.remove();
        return ok;
      } catch (e2) { return false; }
    }
  }

  function beep(n) {
    try {
      const A = new (g.AudioContext || g.webkitAudioContext)();
      n = n || 3;
      for (let i = 0; i < n; i++) {
        const o = A.createOscillator(), gn = A.createGain();
        o.type = 'sine';
        o.frequency.value = 880;
        o.connect(gn);
        gn.connect(A.destination);
        const t = A.currentTime + i * 0.35;
        gn.gain.setValueAtTime(0.0001, t);
        gn.gain.exponentialRampToValueAtTime(0.4, t + 0.02);
        gn.gain.exponentialRampToValueAtTime(0.0001, t + 0.28);
        o.start(t);
        o.stop(t + 0.3);
      }
      setTimeout(() => { try { A.close(); } catch (e) {} }, n * 400 + 600);
    } catch (e) {}
  }

  // ───────── 화면 위에 얹는 층 (토스트, 시계, 형광 띠 등) ─────────
  const OV_CSS = `
*{box-sizing:border-box;margin:0;padding:0;font-family:${FONT}}
.toast{position:fixed;left:50%;top:18px;transform:translateX(-50%);background:#0f172a;color:#fff;padding:10px 18px;border-radius:12px;font-size:14px;box-shadow:0 6px 24px rgba(0,0,0,.35);max-width:80vw;text-align:center;line-height:1.5}
.pill{position:fixed;left:56px;bottom:14px;background:#0f172a;color:#fff;padding:7px 14px;border-radius:20px;font-size:15px;font-weight:700;box-shadow:0 4px 16px rgba(0,0,0,.3)}
.pill.end{background:#dc2626}
.clock{position:fixed;left:50%;top:10px;transform:translateX(-50%);background:rgba(15,23,42,.88);color:#fff;padding:6px 18px;border-radius:14px;text-align:center;cursor:pointer;pointer-events:auto;box-shadow:0 4px 16px rgba(0,0,0,.3);user-select:none}
.clock .t{font-size:24px;font-weight:700;letter-spacing:1px}
.clock .d{font-size:11px;opacity:.8}
.clock.big{top:50%;transform:translate(-50%,-50%);padding:28px 56px;border-radius:28px}
.clock.big .t{font-size:110px}
.clock.big .d{font-size:26px;margin-top:6px}
.ruler{position:fixed;left:0;right:0;height:34px;margin-top:-17px;background:rgba(250,204,21,.22);border-top:2px solid rgba(202,138,4,.65);border-bottom:2px solid rgba(202,138,4,.65)}
.spot{position:fixed;inset:0;background:radial-gradient(circle 160px at var(--x,50%) var(--y,50%),transparent 0,transparent 85%,rgba(0,0,0,.78) 100%)}
.ring{position:fixed;width:46px;height:46px;margin:-23px 0 0 -23px;border:3px solid #ef4444;border-radius:50%;background:rgba(239,68,68,.12)}
.iprev{position:fixed;top:50%;transform:translateY(-50%);max-width:48vw;max-height:84vh;border:3px solid #fff;box-shadow:0 10px 40px rgba(0,0,0,.5);background:#fff;border-radius:8px}
.sb{position:fixed;right:14px;width:38px;height:38px;border-radius:50%;border:none;background:#0f172a;color:#fff;font-size:16px;cursor:pointer;pointer-events:auto;box-shadow:0 3px 12px rgba(0,0,0,.35)}
.sb:hover{background:#2563eb}
.dcv{position:fixed;left:0;top:0;width:100vw;height:100vh;pointer-events:auto;cursor:crosshair;touch-action:none}
.dtb{position:fixed;left:50%;bottom:16px;transform:translateX(-50%);display:flex;gap:6px;align-items:center;background:#fff;border:1px solid #cbd5e1;border-radius:14px;padding:7px 10px;box-shadow:0 6px 24px rgba(0,0,0,.3);pointer-events:auto;flex-wrap:wrap;justify-content:center;max-width:94vw}
.dtb button{border:1px solid #cbd5e1;background:#f8fafc;border-radius:8px;padding:5px 9px;font-size:12px;font-weight:700;cursor:pointer;color:#334155}
.dtb button.on{background:#2563eb;color:#fff;border-color:#2563eb}
.dtb button.red{background:#ef4444;color:#fff;border-color:#ef4444}
.dtb .c{width:24px;height:24px;border-radius:50%;padding:0;border:2px solid #fff;box-shadow:0 0 0 1px #94a3b8}
.dtb .c.on{box-shadow:0 0 0 3px #2563eb}
`;
  let ovHost = null, ovRoot = null;
  function overlay() {
    if (ovHost && ovHost.isConnected) return ovRoot;
    ovHost = document.createElement('div');
    ovHost.id = '__nw_lab_ov__';
    ovHost.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483646;pointer-events:none;display:block';
    ovRoot = ovHost.attachShadow({ mode: 'open' });
    const st = document.createElement('style');
    st.textContent = OV_CSS;
    ovRoot.appendChild(st);
    document.documentElement.appendChild(ovHost);
    return ovRoot;
  }
  function ovAdd(el) { overlay().appendChild(el); return el; }

  let toastEl = null, toastTimer = null;
  function toast(msg, ms) {
    try {
      if (toastEl) toastEl.remove();
      toastEl = ovAdd(mk('div', 'toast', msg));
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => { if (toastEl) toastEl.remove(); toastEl = null; }, ms || 2600);
    } catch (e) {}
  }

  // 마우스 따라다니는 것들이 같이 쓰는 감시
  const mouse = { x: 0, y: 0 };
  const trackers = new Set();
  let mmOn = false;
  const mm = (e) => { mouse.x = e.clientX; mouse.y = e.clientY; trackers.forEach((f) => f(e)); };
  function track(fn) {
    trackers.add(fn);
    if (!mmOn) { document.addEventListener('mousemove', mm, { passive: true, capture: true }); mmOn = true; }
  }
  function untrack(fn) {
    trackers.delete(fn);
    if (!trackers.size && mmOn) { document.removeEventListener('mousemove', mm, true); mmOn = false; }
  }

  // ───────── 화면 필터 (다크, 눈 보호, 밝기, 흑백, 선명) ─────────
  const fx = { dark: false, eye: false, bright: 100, gray: false, contrast: false };
  function applyFilter() {
    const p = [];
    if (fx.dark) p.push('invert(1) hue-rotate(180deg)');
    if (fx.eye) p.push('sepia(.35) saturate(.9)');
    if (fx.bright !== 100) p.push('brightness(' + (fx.bright / 100) + ')');
    if (fx.gray) p.push('grayscale(1)');
    if (fx.contrast) p.push('contrast(1.25)');
    let css = '';
    if (p.length) css = 'html{filter:' + p.join(' ') + '!important}';
    if (fx.dark) {
      css += 'html img,html video,html picture,html canvas{filter:invert(1) hue-rotate(180deg)!important}' +
             '#__nw_root__,#__nw_lab_ov__{filter:invert(1) hue-rotate(180deg)!important}';
    }
    sty('nw-lab-filter', css);
  }

  const cssFeature = (id, css) => ({
    on: () => sty('nw-lab-' + id, css),
    off: () => sty('nw-lab-' + id, '')
  });

  // ───────── 개별 기능들 ─────────
  // 떠 있는 배너 숨기기
  let stickyTimer = null;
  const hidden = new Set();
  function stickyScan() {
    const vh = innerHeight;
    document.querySelectorAll('body *').forEach((el) => {
      if (el.id === '__nw_root__' || el.id === '__nw_lab_ov__' || el.hasAttribute('data-nw-hid')) return;
      let cs;
      try { cs = getComputedStyle(el); } catch (e) { return; }
      if (cs.position !== 'fixed' && cs.position !== 'sticky') return;
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height || r.height > vh * 0.5) return;
      el.setAttribute('data-nw-hid', el.style.display || '-');
      el.style.setProperty('display', 'none', 'important');
      hidden.add(el);
    });
  }
  function stickyOff() {
    clearInterval(stickyTimer);
    hidden.forEach((el) => {
      const v = el.getAttribute('data-nw-hid');
      el.removeAttribute('data-nw-hid');
      el.style.removeProperty('display');
      if (v && v !== '-') el.style.display = v;
    });
    hidden.clear();
  }

  // 읽기 가이드 줄 / 스포트라이트 / 마우스 링
  let ruler = null, rulerFn = null;
  let spot = null, spotFn = null;
  let ring = null, ringFn = null;

  // 이미지 확대 미리보기
  let ipEl = null, ipOver = null, ipOut = null;
  function ipHide() { if (ipEl) { ipEl.remove(); ipEl = null; } }

  // 자동 스크롤
  let asRaf = 0, asSpeed = 3, asAcc = 0;
  function asLoop() {
    asAcc += asSpeed * 0.5;
    const d = Math.floor(asAcc);
    if (d >= 1) { g.scrollBy(0, d); asAcc -= d; }
    asRaf = requestAnimationFrame(asLoop);
  }

  // 위/아래 이동 버튼
  let sbEls = [];

  // 영상
  let vTimer = null, vRate = 1, vLoop = false;
  const vids = () => Array.from(document.querySelectorAll('video,audio'));
  function vApply() {
    vids().forEach((v) => {
      try {
        if (vRate !== 1 && v.playbackRate !== vRate) v.playbackRate = vRate;
        if (vLoop && !v.loop) v.loop = true;
      } catch (e) {}
    });
  }
  function vEnsure() {
    if ((vRate !== 1 || vLoop) && !vTimer) vTimer = setInterval(vApply, 800);
    if (vRate === 1 && !vLoop && vTimer) { clearInterval(vTimer); vTimer = null; }
    vApply();
  }

  // 단어 형광펜
  function clearMarks() {
    document.querySelectorAll('mark[data-nw]').forEach((m) => {
      const p = m.parentNode;
      if (!p) return;
      p.replaceChild(document.createTextNode(m.textContent), m);
      p.normalize();
    });
  }
  function markWord(word) {
    clearMarks();
    if (!word || !document.body) return 0;
    const test = new RegExp(esc(word), 'i');
    const all = new RegExp(esc(word), 'gi');
    const nodes = [];
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        const p = n.parentNode;
        if (!p || /^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA|MARK)$/.test(p.nodeName)) return NodeFilter.FILTER_REJECT;
        if (p.closest && p.closest('#__nw_root__,#__nw_lab_ov__')) return NodeFilter.FILTER_REJECT;
        return test.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    while (w.nextNode() && nodes.length < 800) nodes.push(w.currentNode);
    let count = 0, first = null;
    nodes.forEach((n) => {
      const t = n.nodeValue, frag = document.createDocumentFragment();
      let last = 0, m;
      all.lastIndex = 0;
      while ((m = all.exec(t)) && count < 1500) {
        if (m.index > last) frag.appendChild(document.createTextNode(t.slice(last, m.index)));
        const mark = document.createElement('mark');
        mark.setAttribute('data-nw', '1');
        mark.style.cssText = 'background:#fde047;color:#000;padding:0 1px;border-radius:2px';
        mark.textContent = m[0];
        frag.appendChild(mark);
        if (!first) first = mark;
        last = m.index + m[0].length;
        count++;
        if (!m[0].length) all.lastIndex++;
      }
      if (last < t.length) frag.appendChild(document.createTextNode(t.slice(last)));
      if (n.parentNode) n.parentNode.replaceChild(frag, n);
    });
    if (first) first.scrollIntoView({ block: 'center', behavior: 'smooth' });
    return count;
  }

  // ───────── 타이머 (페이지를 옮겨도 이어짐) ─────────
  const T_END = 'labTimerEnd', T_PAUSE = 'labTimerPause';
  let tTick = null, pill = null;
  const timerListeners = new Set();
  const tRemain = () => {
    const e = C.get(T_END, 0);
    return e ? Math.max(0, e - Date.now()) : (C.get(T_PAUSE, 0) || 0);
  };
  function fmtMs(ms) {
    const s = Math.ceil(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
    return (h ? h + ':' + pad(m) : pad(m)) + ':' + pad(r);
  }
  function pillUpdate() {
    const end = C.get(T_END, 0), paused = C.get(T_PAUSE, 0);
    if (!end && !paused) { if (pill) { pill.remove(); pill = null; } return; }
    if (!pill || !pill.isConnected) pill = ovAdd(mk('div', 'pill'));
    pill.textContent = '타이머 ' + fmtMs(tRemain()) + (end ? '' : ' (멈춤)');
  }
  function timerEnsure() {
    const end = C.get(T_END, 0);
    if (end && !tTick) tTick = setInterval(timerTick, 250);
    if (!end && tTick) { clearInterval(tTick); tTick = null; }
    pillUpdate();
    timerListeners.forEach((f) => f());
  }
  function timerTick() {
    const end = C.get(T_END, 0);
    if (!end) { timerEnsure(); return; }
    const left = end - Date.now();
    if (left > 0) { pillUpdate(); timerListeners.forEach((f) => f()); return; }
    const visible = document.visibilityState === 'visible';
    if (!visible && left > -3000) return;
    C.set(T_END, 0);
    C.set(T_PAUSE, 0);
    if (visible) { beep(4); toast('타이머가 끝났어요!', 6000); }
    timerEnsure();
  }
  const timerStart = (ms) => { C.set(T_PAUSE, 0); C.set(T_END, Date.now() + ms); timerEnsure(); };
  const timerPause = () => { const r = tRemain(); C.set(T_END, 0); C.set(T_PAUSE, r); timerEnsure(); };
  const timerReset = () => { C.set(T_END, 0); C.set(T_PAUSE, 0); timerEnsure(); };

  // ───────── 쉬는 시간 알림 ─────────
  let brTimer = null, brMin = 20;
  function brStart(min) {
    brMin = min;
    clearInterval(brTimer);
    const nx = C.get('labBreakNext', 0);
    if (!nx || nx > Date.now() + min * 60000) C.set('labBreakNext', Date.now() + min * 60000);
    brTimer = setInterval(() => {
      if (document.visibilityState !== 'visible') return;
      if (Date.now() >= C.get('labBreakNext', 0)) {
        C.set('labBreakNext', Date.now() + brMin * 60000);
        beep(2);
        toast('잠깐 쉬어요! 먼 곳을 20초 바라보고 어깨를 풀어 주세요.', 8000);
      }
    }, 15000);
  }
  function brStop() { clearInterval(brTimer); brTimer = null; C.set('labBreakNext', 0); }

  // ───────── 큰 시계 ─────────
  let clockEl = null, clockTimer = null;
  function clockOn() {
    clockOff();
    clockEl = ovAdd(mk('div', 'clock'));
    const t = mk('div', 't'), d = mk('div', 'd');
    clockEl.appendChild(t);
    clockEl.appendChild(d);
    clockEl.title = '누르면 크게/작게';
    clockEl.onclick = () => clockEl.classList.toggle('big');
    const upd = () => {
      const n = new Date();
      t.textContent = pad(n.getHours()) + ':' + pad(n.getMinutes()) + ':' + pad(n.getSeconds());
      d.textContent = n.getFullYear() + '.' + (n.getMonth() + 1) + '.' + n.getDate() + ' ' + '일월화수목금토'[n.getDay()] + '요일';
    };
    upd();
    clockTimer = setInterval(upd, 500);
  }
  function clockOff() {
    clearInterval(clockTimer);
    if (clockEl) clockEl.remove();
    clockEl = null;
  }

  // ───────── 칠판 펜 ─────────
  let draw = null;
  function drawOn() {
    drawOff();
    const dpr = g.devicePixelRatio || 1;
    const cv = ovAdd(mk('canvas', 'dcv'));
    const tb = ovAdd(mk('div', 'dtb'));
    const st = { color: '#111827', size: 4, eraser: false, down: false, snaps: [] };
    const ctx = () => cv.getContext('2d');
    function resize() {
      const old = document.createElement('canvas');
      old.width = cv.width; old.height = cv.height;
      if (cv.width) old.getContext('2d').drawImage(cv, 0, 0);
      cv.width = Math.round(innerWidth * dpr);
      cv.height = Math.round(innerHeight * dpr);
      if (old.width) ctx().drawImage(old, 0, 0);
    }
    resize();
    const pt = (e) => [e.clientX * dpr, e.clientY * dpr];
    cv.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      st.down = true;
      try { cv.setPointerCapture(e.pointerId); } catch (x) {}
      const c = ctx();
      try {
        st.snaps.push(c.getImageData(0, 0, cv.width, cv.height));
        if (st.snaps.length > 6) st.snaps.shift();
      } catch (x) {}
      c.globalCompositeOperation = st.eraser ? 'destination-out' : 'source-over';
      c.strokeStyle = st.color;
      c.lineWidth = (st.eraser ? st.size * 4 : st.size) * dpr;
      c.lineCap = 'round';
      c.lineJoin = 'round';
      const [x, y] = pt(e);
      c.beginPath();
      c.moveTo(x, y);
      c.lineTo(x + 0.01, y + 0.01);
      c.stroke();
    });
    cv.addEventListener('pointermove', (e) => {
      if (!st.down) return;
      const c = ctx(), [x, y] = pt(e);
      c.lineTo(x, y);
      c.stroke();
    });
    const up = () => { st.down = false; };
    cv.addEventListener('pointerup', up);
    cv.addEventListener('pointercancel', up);

    const colors = ['#111827', '#ef4444', '#2563eb', '#16a34a', '#f59e0b', '#ffffff'];
    const cbtns = colors.map((c) => {
      const b = mk('button', 'c' + (c === st.color ? ' on' : ''));
      b.style.background = c;
      b.title = '색';
      b.onclick = () => { st.color = c; st.eraser = false; sync(); };
      tb.appendChild(b);
      return b;
    });
    const sizes = [[2, '가늘게'], [5, '보통'], [12, '굵게']];
    const sbtns = sizes.map(([n, l]) => {
      const b = mk('button', '', l);
      b.onclick = () => { st.size = n; sync(); };
      tb.appendChild(b);
      return b;
    });
    const er = mk('button', '', '지우개');
    er.onclick = () => { st.eraser = !st.eraser; sync(); };
    const un = mk('button', '', '되돌리기');
    un.onclick = () => { const s = st.snaps.pop(); if (s) ctx().putImageData(s, 0, 0); };
    const cl = mk('button', '', '전체 지우기');
    cl.onclick = () => { ctx().clearRect(0, 0, cv.width, cv.height); st.snaps = []; };
    const ms = mk('button', '', '마우스 모드');
    ms.title = '켜면 그림은 그대로 두고 페이지를 누를 수 있어요';
    ms.onclick = () => {
      const pass = cv.style.pointerEvents !== 'none';
      cv.style.pointerEvents = pass ? 'none' : 'auto';
      ms.classList.toggle('on', pass);
    };
    const cx = mk('button', 'red', '끄기');
    cx.onclick = () => { setActive('draw', false); };
    [er, un, cl, ms, cx].forEach((b) => tb.appendChild(b));
    function sync() {
      cbtns.forEach((b, i) => b.classList.toggle('on', !st.eraser && colors[i] === st.color));
      sbtns.forEach((b, i) => b.classList.toggle('on', sizes[i][0] === st.size));
      er.classList.toggle('on', st.eraser);
    }
    sync();
    const onR = () => resize();
    g.addEventListener('resize', onR);
    draw = { cv, tb, onR };
  }
  function drawOff() {
    if (!draw) return;
    g.removeEventListener('resize', draw.onR);
    draw.cv.remove();
    draw.tb.remove();
    draw = null;
  }

  // ───────── 안전한 계산기 ─────────
  function calc(expr) {
    const s = expr.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/\s+/g, '');
    let i = 0;
    const bad = () => { throw new Error('bad'); };
    function primary() {
      if (s[i] === '(') { i++; const v = add(); if (s[i] !== ')') bad(); i++; return v; }
      const m = /^(\d+\.?\d*|\.\d+)/.exec(s.slice(i));
      if (!m) bad();
      i += m[0].length;
      return parseFloat(m[0]);
    }
    function factor() {
      if (s[i] === '-') { i++; return -factor(); }
      if (s[i] === '+') { i++; return factor(); }
      let v = primary();
      while (s[i] === '%') { i++; v /= 100; }
      return v;
    }
    function mul() {
      let v = factor();
      while (s[i] === '*' || s[i] === '/') { const o = s[i++]; const r = factor(); v = o === '*' ? v * r : v / r; }
      return v;
    }
    function add() {
      let v = mul();
      while (s[i] === '+' || s[i] === '-') { const o = s[i++]; const r = mul(); v = o === '+' ? v + r : v - r; }
      return v;
    }
    const v = add();
    if (i < s.length || !isFinite(v)) bad();
    return parseFloat(v.toPrecision(12));
  }

  // ───────── 도구 화면(탭 안에서 열리는 것들) ─────────
  const btn = (text, fn, cls) => { const b = mk('button', 'lb-b' + (cls ? ' ' + cls : ''), text); b.type = 'button'; b.onclick = fn; return b; };
  const num = (val, min, max, w) => {
    const i = mk('input', 'lb-in');
    i.type = 'number'; i.value = val; i.min = min; i.max = max;
    if (w) i.style.width = w;
    return i;
  };
  const row = (...els) => { const r = mk('div', 'lb-r'); els.forEach((e) => e && r.appendChild(e)); return r; };

  function buildTimer(box) {
    const disp = mk('div', 'lb-big');
    const mi = num(5, 0, 600, '64px'), se = num(0, 0, 59, '64px');
    const presets = row(...[1, 3, 5, 10, 15, 30].map((m) => btn(m + '분', () => { mi.value = m; se.value = 0; if (!C.get(T_END, 0)) show(); })));
    const go = btn('시작', () => {
      if (C.get(T_END, 0)) { timerPause(); return; }
      if (C.get(T_PAUSE, 0) > 0) { timerStart(C.get(T_PAUSE, 0)); return; }
      const ms = (parseInt(mi.value, 10) || 0) * 60000 + (parseInt(se.value, 10) || 0) * 1000;
      if (ms <= 0) { toast('시간을 입력해 주세요'); return; }
      timerStart(ms);
    }, 'main');
    const rs = btn('초기화', () => { timerReset(); });
    function show() {
      const run = C.get(T_END, 0), pz = C.get(T_PAUSE, 0);
      if (run || pz) disp.textContent = fmtMs(tRemain());
      else disp.textContent = pad(parseInt(mi.value, 10) || 0) + ':' + pad(parseInt(se.value, 10) || 0);
      go.textContent = run ? '일시정지' : (pz ? '계속' : '시작');
    }
    mi.oninput = se.oninput = () => { if (!C.get(T_END, 0) && !C.get(T_PAUSE, 0)) show(); };
    box.appendChild(disp);
    box.appendChild(row(mi, mk('span', 'lb-t', '분'), se, mk('span', 'lb-t', '초')));
    box.appendChild(presets);
    box.appendChild(row(go, rs));
    box.appendChild(mk('div', 'lb-note', '다른 사이트로 옮겨 가도 타이머가 이어져요. 끝나면 소리와 알림이 나와요.'));
    show();
    timerListeners.add(show);
    return () => timerListeners.delete(show);
  }

  const sw = { run: false, start: 0, acc: 0, laps: [] };
  function buildStopwatch(box) {
    const disp = mk('div', 'lb-big');
    const laps = mk('div', 'lb-list');
    const cur = () => sw.acc + (sw.run ? Date.now() - sw.start : 0);
    const f = (ms) => pad(Math.floor(ms / 60000)) + ':' + pad(Math.floor(ms / 1000) % 60) + '.' + pad(Math.floor(ms / 10) % 100);
    const go = btn('시작', () => {
      if (sw.run) { sw.acc += Date.now() - sw.start; sw.run = false; } else { sw.start = Date.now(); sw.run = true; }
      show();
    }, 'main');
    const lap = btn('랩', () => { if (sw.run || sw.acc) { sw.laps.unshift(f(cur())); show(); } });
    const rs = btn('초기화', () => { sw.run = false; sw.acc = 0; sw.laps = []; show(); });
    function show() {
      disp.textContent = f(cur());
      go.textContent = sw.run ? '멈춤' : '시작';
      laps.textContent = '';
      sw.laps.slice(0, 30).forEach((l, i) => laps.appendChild(mk('div', 'lb-li', (sw.laps.length - i) + '번  ' + l)));
    }
    box.appendChild(disp);
    box.appendChild(row(go, lap, rs));
    box.appendChild(laps);
    show();
    const iv = setInterval(() => { if (sw.run) disp.textContent = f(cur()); }, 50);
    return () => clearInterval(iv);
  }

  const rn = { used: [] };
  function buildRandNum(box) {
    const a = num(1, -9999, 9999, '70px'), b = num(30, -9999, 9999, '70px');
    const nr = document.createElement('input');
    nr.type = 'checkbox';
    const disp = mk('div', 'lb-big', '?');
    const info = mk('div', 'lb-note');
    let iv = null;
    const go = btn('뽑기', () => {
      let lo = parseInt(a.value, 10), hi = parseInt(b.value, 10);
      if (isNaN(lo) || isNaN(hi)) return;
      if (lo > hi) { const t = lo; lo = hi; hi = t; }
      const pool = [];
      for (let i = lo; i <= hi && pool.length < 20000; i++) if (!nr.checked || rn.used.indexOf(i) < 0) pool.push(i);
      if (!pool.length) { info.textContent = '더 뽑을 번호가 없어요. 기록을 지워 주세요.'; return; }
      const pick = pool[Math.floor(Math.random() * pool.length)];
      clearInterval(iv);
      let n = 0;
      iv = setInterval(() => {
        if (++n > 14) {
          clearInterval(iv);
          disp.textContent = pick;
          if (nr.checked) rn.used.push(pick);
          info.textContent = rn.used.length ? '뽑은 번호: ' + rn.used.join(', ') : '';
        } else disp.textContent = lo + Math.floor(Math.random() * (hi - lo + 1));
      }, 45);
    }, 'main');
    const clr = btn('기록 지우기', () => { rn.used = []; info.textContent = ''; });
    const lab = mk('label', 'lb-t');
    lab.appendChild(nr);
    lab.appendChild(document.createTextNode(' 뽑은 번호는 다시 안 뽑기'));
    box.appendChild(disp);
    box.appendChild(row(a, mk('span', 'lb-t', '부터'), b, mk('span', 'lb-t', '까지')));
    box.appendChild(row(lab));
    box.appendChild(row(go, clr));
    box.appendChild(info);
    info.textContent = rn.used.length ? '뽑은 번호: ' + rn.used.join(', ') : '';
    return () => clearInterval(iv);
  }

  const names = { used: [] };
  const getNames = () => String(C.get('labNames', '')).split(/\r?\n|,/).map((s) => s.trim()).filter(Boolean);
  function nameBox(box) {
    const ta = mk('textarea', 'lb-ta');
    ta.rows = 5;
    ta.placeholder = '이름을 한 줄에 한 명씩 적어 주세요';
    ta.value = String(C.get('labNames', ''));
    ta.oninput = () => C.set('labNames', ta.value);
    box.appendChild(ta);
    return ta;
  }
  function buildRandName(box) {
    nameBox(box);
    const nr = document.createElement('input');
    nr.type = 'checkbox';
    nr.checked = true;
    const disp = mk('div', 'lb-big sm', '?');
    const info = mk('div', 'lb-note');
    let iv = null;
    const go = btn('한 명 뽑기', () => {
      const all = getNames();
      const pool = all.filter((n) => !nr.checked || names.used.indexOf(n) < 0);
      if (!all.length) { info.textContent = '이름을 먼저 적어 주세요'; return; }
      if (!pool.length) { info.textContent = '모두 뽑았어요. 기록을 지워 주세요.'; return; }
      const pick = pool[Math.floor(Math.random() * pool.length)];
      clearInterval(iv);
      let n = 0;
      iv = setInterval(() => {
        if (++n > 14) {
          clearInterval(iv);
          disp.textContent = pick;
          if (nr.checked) names.used.push(pick);
          info.textContent = names.used.length ? '뽑힌 사람: ' + names.used.join(', ') : '';
        } else disp.textContent = all[Math.floor(Math.random() * all.length)];
      }, 45);
    }, 'main');
    const clr = btn('기록 지우기', () => { names.used = []; info.textContent = ''; });
    const lab = mk('label', 'lb-t');
    lab.appendChild(nr);
    lab.appendChild(document.createTextNode(' 뽑힌 사람은 다시 안 뽑기'));
    box.appendChild(disp);
    box.appendChild(row(lab));
    box.appendChild(row(go, clr));
    box.appendChild(info);
    return () => clearInterval(iv);
  }

  function buildTeams(box) {
    nameBox(box);
    const n = num(4, 2, 20, '64px');
    const out = mk('div', 'lb-list');
    let last = '';
    const go = btn('모둠 나누기', () => {
      const all = getNames();
      const k = clamp(parseInt(n.value, 10) || 2, 2, 20);
      out.textContent = '';
      if (all.length < 2) { out.appendChild(mk('div', 'lb-note', '이름을 두 명 이상 적어 주세요')); return; }
      for (let i = all.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = all[i]; all[i] = all[j]; all[j] = t; }
      const groups = Array.from({ length: Math.min(k, all.length) }, () => []);
      all.forEach((nm, i) => groups[i % groups.length].push(nm));
      last = groups.map((gr, i) => (i + 1) + '모둠: ' + gr.join(', ')).join('\n');
      groups.forEach((gr, i) => {
        const d = mk('div', 'lb-team');
        d.appendChild(mk('b', '', (i + 1) + '모둠 (' + gr.length + '명)'));
        d.appendChild(mk('div', '', gr.join(', ')));
        out.appendChild(d);
      });
    }, 'main');
    const cp = btn('결과 복사', async () => { if (last) toast((await copy(last)) ? '복사했어요' : '복사하지 못했어요'); });
    box.appendChild(row(mk('span', 'lb-t', '모둠 수'), n));
    box.appendChild(row(go, cp));
    box.appendChild(out);
    return null;
  }

  function buildDice(box) {
    const disp = mk('div', 'lb-big sm', '?');
    const faces = '⚀⚁⚂⚃⚄⚅';
    const cnt = mk('select', 'lb-in');
    for (let i = 1; i <= 6; i++) { const o = mk('option', '', i + '개'); o.value = i; cnt.appendChild(o); }
    const roll = btn('주사위 굴리기', () => {
      const k = parseInt(cnt.value, 10), r = [];
      for (let i = 0; i < k; i++) r.push(1 + Math.floor(Math.random() * 6));
      disp.textContent = r.map((x) => faces[x - 1] + x).join('  ') + (k > 1 ? '  = ' + r.reduce((a, b) => a + b, 0) : '');
    }, 'main');
    const coin = btn('동전 던지기', () => { disp.textContent = Math.random() < 0.5 ? '앞면' : '뒷면'; });
    box.appendChild(disp);
    box.appendChild(row(cnt, roll));
    box.appendChild(row(coin));
    return null;
  }

  function buildNoise(box) {
    let stream = null, ac = null, an = null, raf = 0, lastWarn = 0;
    const msg = mk('div', 'lb-note', '마이크를 켜면 교실 소리 크기를 막대로 보여줘요. 소리는 저장하거나 보내지 않아요.');
    const meter = mk('div', 'lb-meter'), fill = mk('div', 'lb-fill');
    meter.appendChild(fill);
    const val = mk('div', 'lb-big sm', '-');
    const thr = document.createElement('input');
    thr.type = 'range'; thr.min = 10; thr.max = 95; thr.value = 65; thr.className = 'lb-rng';
    const thrT = mk('span', 'lb-t', '기준 65');
    thr.oninput = () => { thrT.textContent = '기준 ' + thr.value; };
    const snd = document.createElement('input');
    snd.type = 'checkbox'; snd.checked = true;
    const sl = mk('label', 'lb-t');
    sl.appendChild(snd);
    sl.appendChild(document.createTextNode(' 기준을 넘으면 소리로 알리기'));
    const warn = mk('div', 'lb-warn', '조용히 해 주세요!');
    warn.style.display = 'none';
    const go = btn('마이크 켜기', async () => {
      if (stream) { stop(); go.textContent = '마이크 켜기'; return; }
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        ac = new (g.AudioContext || g.webkitAudioContext)();
        const src = ac.createMediaStreamSource(stream);
        an = ac.createAnalyser();
        an.fftSize = 1024;
        src.connect(an);
        go.textContent = '마이크 끄기';
        msg.textContent = '듣는 중...';
        loop();
      } catch (e) {
        stream = null;
        msg.textContent = '마이크를 쓸 수 없어요 (' + ((e && e.name) || '오류') + '). 주소창 왼쪽 자물쇠에서 마이크를 허용해 주세요. https 사이트에서만 돼요.';
      }
    }, 'main');
    function loop() {
      const buf = new Uint8Array(an.fftSize);
      an.getByteTimeDomainData(buf);
      let s = 0;
      for (let i = 0; i < buf.length; i++) { const v = (buf[i] - 128) / 128; s += v * v; }
      const rms = Math.sqrt(s / buf.length);
      const db = 20 * Math.log10(rms || 0.0001);
      const lv = clamp(Math.round((db + 60) / 60 * 100), 0, 100);
      fill.style.width = lv + '%';
      fill.style.background = lv >= thr.value ? '#ef4444' : '#22c55e';
      val.textContent = lv;
      const over = lv >= thr.value;
      warn.style.display = over ? 'block' : 'none';
      if (over && snd.checked && Date.now() - lastWarn > 4000) { lastWarn = Date.now(); beep(1); }
      raf = requestAnimationFrame(loop);
    }
    function stop() {
      cancelAnimationFrame(raf);
      if (stream) stream.getTracks().forEach((t) => t.stop());
      if (ac) { try { ac.close(); } catch (e) {} }
      stream = ac = an = null;
      warn.style.display = 'none';
    }
    box.appendChild(msg);
    box.appendChild(val);
    box.appendChild(meter);
    box.appendChild(warn);
    box.appendChild(row(mk('span', 'lb-t', '조용히 기준'), thr, thrT));
    box.appendChild(row(sl));
    box.appendChild(row(go));
    return stop;
  }

  function buildMemo(box) {
    const ta = mk('textarea', 'lb-ta tall');
    ta.placeholder = '여기에 적으면 자동으로 저장돼요 (모든 사이트에서 같은 메모)';
    ta.value = String(C.get('labMemo', ''));
    const info = mk('div', 'lb-note');
    let tm = null;
    const upd = () => { info.textContent = ta.value.length + '자'; };
    ta.oninput = () => { upd(); clearTimeout(tm); tm = setTimeout(() => C.set('labMemo', ta.value), 300); };
    box.appendChild(ta);
    box.appendChild(row(
      btn('복사', async () => toast((await copy(ta.value)) ? '복사했어요' : '복사하지 못했어요')),
      btn('모두 지우기', () => { if (ta.value && confirm('메모를 모두 지울까요?')) { ta.value = ''; C.set('labMemo', ''); upd(); } })
    ));
    box.appendChild(info);
    upd();
    return () => { clearTimeout(tm); C.set('labMemo', ta.value); };
  }

  function buildCalc(box) {
    const disp = document.createElement('input');
    disp.className = 'lb-in lb-calc';
    disp.placeholder = '0';
    disp.setAttribute('inputmode', 'none');
    const hist = mk('div', 'lb-note');
    const run = () => {
      if (!disp.value.trim()) return;
      try {
        const r = calc(disp.value);
        hist.textContent = disp.value + ' = ' + r;
        disp.value = String(r);
      } catch (e) { hist.textContent = '계산할 수 없는 식이에요'; }
    };
    disp.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); run(); } };
    const keys = [['C', '(', ')', '⌫'], ['7', '8', '9', '÷'], ['4', '5', '6', '×'], ['1', '2', '3', '−'], ['0', '.', '%', '+']];
    const grid = mk('div', 'lb-grid');
    keys.forEach((r) => r.forEach((k) => {
      const b = btn(k, () => {
        if (k === 'C') { disp.value = ''; hist.textContent = ''; } else if (k === '⌫') disp.value = disp.value.slice(0, -1); else disp.value += k;
        disp.focus();
      });
      grid.appendChild(b);
    }));
    const eq = btn('=', run, 'main');
    eq.style.gridColumn = '1 / -1';
    grid.appendChild(eq);
    box.appendChild(disp);
    box.appendChild(hist);
    box.appendChild(grid);
    return null;
  }

  function buildCount(box) {
    const ta = mk('textarea', 'lb-ta tall');
    ta.placeholder = '글을 붙여 넣거나, 페이지에서 글을 선택하고 아래 버튼을 눌러요';
    const out = mk('div', 'lb-stats');
    const upd = () => {
      const t = ta.value;
      const items = [
        ['공백 포함', t.length + '자'],
        ['공백 제외', t.replace(/\s/g, '').length + '자'],
        ['단어', (t.trim() ? t.trim().split(/\s+/).length : 0) + '개'],
        ['줄', (t ? t.split(/\r?\n/).length : 0) + '줄'],
        ['바이트(UTF-8)', new Blob([t]).size + 'B']
      ];
      out.textContent = '';
      items.forEach(([k, v]) => {
        const d = mk('div', 'lb-stat');
        d.appendChild(mk('span', 'lb-t', k));
        d.appendChild(mk('b', '', v));
        out.appendChild(d);
      });
    };
    ta.oninput = upd;
    box.appendChild(ta);
    box.appendChild(row(btn('선택한 글 가져오기', () => { ta.value = String(g.getSelection() || '') || ta.value; upd(); }), btn('지우기', () => { ta.value = ''; upd(); })));
    box.appendChild(out);
    upd();
    return null;
  }

  function buildColor(box) {
    const info = mk('div', 'lb-note');
    const cur = mk('div', 'lb-swatch');
    const hex = mk('div', 'lb-big sm', '-');
    const hist = mk('div', 'lb-sws');
    const list = C.jget('labColors', []);
    const draw2 = () => {
      hist.textContent = '';
      list.forEach((c) => {
        const s = mk('button', 'lb-sw1');
        s.style.background = c;
        s.title = c;
        s.type = 'button';
        s.onclick = async () => { show(c); toast((await copy(c)) ? c + ' 복사했어요' : c); };
        hist.appendChild(s);
      });
    };
    const show = (c) => {
      cur.style.background = c;
      const m = /^#([0-9a-f]{6})/i.exec(c);
      hex.textContent = c.toUpperCase() + (m ? '  (' + parseInt(m[1].slice(0, 2), 16) + ', ' + parseInt(m[1].slice(2, 4), 16) + ', ' + parseInt(m[1].slice(4, 6), 16) + ')' : '');
    };
    const go = btn('화면에서 색 고르기', async () => {
      if (!g.EyeDropper) { info.textContent = '이 브라우저는 색 추출을 지원하지 않아요.'; return; }
      try {
        const r = await new g.EyeDropper().open();
        const c = r.sRGBHex;
        show(c);
        list.unshift(c);
        if (list.length > 12) list.pop();
        C.jset('labColors', list);
        draw2();
        info.textContent = (await copy(c)) ? '색 코드를 복사했어요' : '';
      } catch (e) {}
    }, 'main');
    box.appendChild(cur);
    box.appendChild(hex);
    box.appendChild(row(go));
    box.appendChild(info);
    box.appendChild(mk('div', 'lb-t', '최근에 고른 색 (누르면 복사)'));
    box.appendChild(hist);
    draw2();
    return null;
  }

  function buildFind(box) {
    const q = mk('input', 'lb-in');
    q.placeholder = '찾을 단어';
    q.style.width = '100%';
    const info = mk('div', 'lb-note');
    const go = () => { const n = markWord(q.value.trim()); info.textContent = q.value.trim() ? (n + '곳에 표시했어요') : ''; };
    q.onkeydown = (e) => { if (e.key === 'Enter') go(); };
    box.appendChild(q);
    box.appendChild(row(btn('형광펜 칠하기', go, 'main'), btn('지우기', () => { clearMarks(); info.textContent = ''; })));
    box.appendChild(info);
    return null;
  }

  function buildTts(box) {
    const ta = mk('textarea', 'lb-ta tall');
    ta.placeholder = '읽을 글 (페이지에서 글을 선택하고 "선택한 글 가져오기")';
    const rate = mk('select', 'lb-in');
    [['0.7', '느리게'], ['1', '보통'], ['1.3', '빠르게'], ['1.6', '아주 빠르게']].forEach(([v, l]) => {
      const o = mk('option', '', l);
      o.value = v;
      if (v === '1') o.selected = true;
      rate.appendChild(o);
    });
    const speak = btn('읽기', () => {
      const t = ta.value.trim() || String(g.getSelection() || '').trim();
      if (!t) { toast('읽을 글이 없어요'); return; }
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(t);
      u.lang = 'ko-KR';
      u.rate = parseFloat(rate.value);
      speechSynthesis.speak(u);
    }, 'main');
    box.appendChild(ta);
    box.appendChild(row(btn('선택한 글 가져오기', () => { const s = String(g.getSelection() || ''); if (s) ta.value = s; }), rate));
    box.appendChild(row(speak, btn('멈춤', () => speechSynthesis.cancel())));
    return () => { try { speechSynthesis.cancel(); } catch (e) {} };
  }

  // ───────── 기능 목록 ─────────
  const CATS = [
    ['screen', '화면'], ['read', '읽기 · 보기'], ['page', '페이지 도구'],
    ['media', '영상'], ['class', '수업 도구'], ['util', '유틸']
  ];

  const F = [
    // 화면
    { id: 'dark', cat: 'screen', name: '다크 모드', desc: '어두운 화면으로 바꿔요', persist: true,
      on: () => { fx.dark = true; applyFilter(); }, off: () => { fx.dark = false; applyFilter(); } },
    { id: 'eye', cat: 'screen', name: '눈 보호 모드', desc: '따뜻한 색으로 눈이 덜 피곤해요', persist: true,
      on: () => { fx.eye = true; applyFilter(); }, off: () => { fx.eye = false; applyFilter(); } },
    { id: 'bright', cat: 'screen', name: '밝기 조절', desc: '페이지 밝기를 낮추거나 높여요', persist: true,
      opt: { min: 40, max: 130, step: 5, def: 80, fmt: (v) => v + '%' },
      on: (v) => { fx.bright = v === true ? 80 : v; applyFilter(); }, off: () => { fx.bright = 100; applyFilter(); } },
    { id: 'gray', cat: 'screen', name: '흑백 화면', desc: '색을 빼서 집중하기 좋아요', persist: true,
      on: () => { fx.gray = true; applyFilter(); }, off: () => { fx.gray = false; applyFilter(); } },
    { id: 'contrast', cat: 'screen', name: '선명하게 보기', desc: '글자와 배경 대비를 높여요', persist: true,
      on: () => { fx.contrast = true; applyFilter(); }, off: () => { fx.contrast = false; applyFilter(); } },
    { id: 'zoom', cat: 'screen', name: '페이지 확대 · 축소', desc: '페이지 전체를 키우거나 줄여요', persist: true,
      opt: { min: 60, max: 220, step: 10, def: 125, fmt: (v) => v + '%' },
      on: (v) => sty('nw-lab-zoom', 'html body{zoom:' + ((v === true ? 125 : v) / 100) + '}'), off: () => sty('nw-lab-zoom', '') },
    Object.assign({ id: 'lh', cat: 'screen', name: '줄 간격 넓히기', desc: '글이 빽빽할 때 읽기 편해져요', persist: true },
      cssFeature('lh', 'p,li,td,dd,blockquote,article div,.content div{line-height:1.9!important}')),
    Object.assign({ id: 'pfont', cat: 'screen', name: '갈무리 글꼴로 보기', desc: '페이지 글꼴을 도트 글꼴로 바꿔요', persist: true },
      cssFeature('pfont', "body,body :is(p,li,td,th,dd,dt,h1,h2,h3,h4,h5,h6,a,div,button,input,textarea,label,blockquote,span):not([class*='icon' i]):not([class*='fa-' i]):not(.material-icons){font-family:'Galmuri9','Malgun Gothic',sans-serif!important}")),
    Object.assign({ id: 'noimg', cat: 'screen', name: '이미지 숨기기', desc: '그림을 감춰서 글에 집중해요', persist: true },
      cssFeature('noimg', 'img,picture,video{opacity:0!important}')),
    Object.assign({ id: 'noanim', cat: 'screen', name: '움직임 멈추기', desc: '애니메이션과 부드러운 이동을 꺼요', persist: true },
      cssFeature('noanim', '*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}')),
    { id: 'sticky', cat: 'screen', name: '떠 있는 배너 숨기기', desc: '화면에 고정된 광고·안내창을 숨겨요', persist: true,
      on: () => { stickyOff(); stickyScan(); stickyTimer = setInterval(stickyScan, 1500); }, off: stickyOff },

    // 읽기 · 보기
    Object.assign({ id: 'reader', cat: 'read', name: '읽기 모드', desc: '메뉴·옆 칸을 숨기고 글만 가운데에 보여줘요' },
      cssFeature('reader', 'header,nav,aside,footer,[role=banner],[role=navigation],[role=complementary],[class*="sidebar" i],[id*="sidebar" i]{display:none!important}body{max-width:780px!important;margin:0 auto!important;padding:24px 18px!important;font-size:18px!important;line-height:1.85!important;background:#fbfbf7!important;color:#222!important}')),
    Object.assign({ id: 'focus', cat: 'read', name: '문단 집중', desc: '마우스를 올린 문단만 선명하게 보여요' },
      cssFeature('focus', 'p,li,blockquote,h1,h2,h3,h4{opacity:.28;transition:opacity .12s}p:hover,li:hover,blockquote:hover,h1:hover,h2:hover,h3:hover,h4:hover{opacity:1}')),
    { id: 'ruler', cat: 'read', name: '읽기 가이드 줄', desc: '마우스를 따라다니는 형광 띠로 줄을 놓치지 않아요',
      on: () => {
        if (ruler) return;
        ruler = ovAdd(mk('div', 'ruler'));
        ruler.style.top = mouse.y + 'px';
        rulerFn = (e) => { ruler.style.top = e.clientY + 'px'; };
        track(rulerFn);
      },
      off: () => { untrack(rulerFn); if (ruler) ruler.remove(); ruler = null; } },
    { id: 'spot', cat: 'read', name: '스포트라이트', desc: '마우스 둘레만 밝게, 나머지는 어둡게 해요',
      on: () => {
        if (spot) return;
        spot = ovAdd(mk('div', 'spot'));
        spot.style.setProperty('--x', mouse.x + 'px');
        spot.style.setProperty('--y', mouse.y + 'px');
        spotFn = (e) => { spot.style.setProperty('--x', e.clientX + 'px'); spot.style.setProperty('--y', e.clientY + 'px'); };
        track(spotFn);
      },
      off: () => { untrack(spotFn); if (spot) spot.remove(); spot = null; } },
    { id: 'ring', cat: 'read', name: '마우스 강조 링', desc: '발표·수업 때 마우스 위치가 잘 보여요', persist: true,
      on: () => {
        if (ring) return;
        ring = ovAdd(mk('div', 'ring'));
        ring.style.left = mouse.x + 'px';
        ring.style.top = mouse.y + 'px';
        ringFn = (e) => { ring.style.left = e.clientX + 'px'; ring.style.top = e.clientY + 'px'; };
        track(ringFn);
      },
      off: () => { untrack(ringFn); if (ring) ring.remove(); ring = null; } },
    { id: 'imgzoom', cat: 'read', name: '이미지 확대 미리보기', desc: '작은 그림에 마우스를 올리면 크게 보여줘요', persist: true,
      on: () => {
        if (ipOver) return;
        ipOver = (e) => {
          const t = e.target;
          if (!t || t.tagName !== 'IMG' || !t.currentSrc) return;
          const r = t.getBoundingClientRect();
          if (r.width < 30 || r.height < 30) return;
          ipHide();
          ipEl = ovAdd(mk('img', 'iprev'));
          ipEl.src = t.currentSrc;
          if (r.left + r.width / 2 > innerWidth / 2) ipEl.style.left = '12px'; else ipEl.style.right = '12px';
        };
        ipOut = (e) => { if (e.target && e.target.tagName === 'IMG') ipHide(); };
        document.addEventListener('mouseover', ipOver, true);
        document.addEventListener('mouseout', ipOut, true);
      },
      off: () => {
        if (ipOver) document.removeEventListener('mouseover', ipOver, true);
        if (ipOut) document.removeEventListener('mouseout', ipOut, true);
        ipOver = ipOut = null;
        ipHide();
      } },
    Object.assign({ id: 'linkhl', cat: 'read', name: '링크 강조', desc: '누를 수 있는 링크를 노랗게 표시해요', persist: true },
      cssFeature('linkhl', 'a[href]{background-color:#fff3a3!important;color:#0b3d91!important;text-decoration:underline!important;outline:1px solid #f59e0b}')),
    { id: 'unlock', cat: 'read', name: '복사·드래그 풀기', desc: '글 선택이나 오른쪽 클릭이 막힌 페이지를 풀어요', persist: true,
      on: () => {
        sty('nw-lab-unlock', '*{-webkit-user-select:text!important;user-select:text!important}');
        if (!g.__nwUnlock) {
          g.__nwUnlock = (e) => { if (g.__nwUnlockOn) e.stopImmediatePropagation(); };
          ['contextmenu', 'copy', 'cut', 'selectstart', 'dragstart', 'mousedown'].forEach((n) => g.addEventListener(n, g.__nwUnlock, true));
        }
        g.__nwUnlockOn = true;
        try { document.oncontextmenu = null; document.onselectstart = null; document.body && (document.body.oncontextmenu = null); } catch (e) {}
      },
      off: () => { g.__nwUnlockOn = false; sty('nw-lab-unlock', ''); } },
    { id: 'autoscroll', cat: 'read', name: '자동 스크롤', desc: '손 안 대고 천천히 내려가요',
      opt: { min: 1, max: 10, step: 1, def: 3, fmt: (v) => v + '단계' },
      on: (v) => { asSpeed = v === true ? 3 : v; if (!asRaf) { asAcc = 0; asRaf = requestAnimationFrame(asLoop); } },
      off: () => { cancelAnimationFrame(asRaf); asRaf = 0; } },

    // 페이지 도구
    { id: 'find', cat: 'page', name: '단어 형광펜', desc: '페이지 안의 단어를 모두 노랗게 칠해요', kind: 'tool', build: buildFind },
    { id: 'tts', cat: 'page', name: '글 읽어주기', desc: '선택한 글을 소리 내어 읽어줘요', kind: 'tool', build: buildTts },
    { id: 'edit', cat: 'page', name: '페이지 글 고치기', desc: '페이지의 글을 직접 고쳐서 확인해 봐요 (새로고침하면 원래대로)',
      on: () => { document.designMode = 'on'; }, off: () => { document.designMode = 'off'; } },
    { id: 'copyurl', cat: 'page', name: '제목 + 주소 복사', desc: '지금 페이지의 제목과 주소를 복사해요', kind: 'action',
      run: async () => toast((await copy(document.title + '\n' + location.href)) ? '제목과 주소를 복사했어요' : '복사하지 못했어요') },
    { id: 'copytext', cat: 'page', name: '페이지 글 전체 복사', desc: '보이는 글을 모두 복사해요', kind: 'action',
      run: async () => {
        const t = (document.body && document.body.innerText || '').slice(0, 200000);
        toast((await copy(t)) ? t.length + '자를 복사했어요' : '복사하지 못했어요');
      } },
    { id: 'fs', cat: 'page', name: '전체화면 켜기/끄기', desc: 'F11과 같아요', kind: 'action',
      run: () => { try { chrome.runtime.sendMessage({ t: 'fs-toggle' }); } catch (e) {} } },
    { id: 'scrollbtn', cat: 'page', name: '위/아래 이동 버튼', desc: '오른쪽 아래에 맨 위·맨 아래 버튼을 달아요', persist: true,
      on: () => {
        if (sbEls.length) return;
        const up = ovAdd(mk('button', 'sb', '▲')), dn = ovAdd(mk('button', 'sb', '▼'));
        up.style.bottom = '60px'; dn.style.bottom = '14px';
        up.title = '맨 위로'; dn.title = '맨 아래로';
        up.onclick = () => g.scrollTo({ top: 0, behavior: 'smooth' });
        dn.onclick = () => g.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' });
        sbEls = [up, dn];
      },
      off: () => { sbEls.forEach((e) => e.remove()); sbEls = []; } },

    // 영상
    { id: 'vspeed', cat: 'media', name: '영상 속도 조절', desc: '페이지의 영상·소리 재생 속도를 바꿔요', persist: true,
      opt: { min: 0.5, max: 3, step: 0.25, def: 1.5, fmt: (v) => v + '배' },
      on: (v) => { vRate = v === true ? 1.5 : v; vEnsure(); },
      off: () => { const r = vRate; vRate = 1; vids().forEach((x) => { try { if (x.playbackRate === r) x.playbackRate = 1; } catch (e) {} }); vEnsure(); } },
    { id: 'pip', cat: 'media', name: '화면 속 화면', desc: '영상을 작은 창으로 띄워 다른 일을 하며 봐요', kind: 'action',
      run: async () => {
        const v = vids().filter((x) => x.tagName === 'VIDEO' && x.readyState > 0)
          .sort((a, b) => (b.clientWidth * b.clientHeight) - (a.clientWidth * a.clientHeight))[0];
        if (!v) { toast('이 페이지에서 영상을 찾지 못했어요'); return; }
        try {
          if (document.pictureInPictureElement) await document.exitPictureInPicture(); else await v.requestPictureInPicture();
        } catch (e) { toast('이 영상은 작은 창으로 띄울 수 없어요'); }
      } },
    { id: 'vloop', cat: 'media', name: '영상 반복 재생', desc: '영상이 끝나면 처음부터 다시 틀어요', persist: true,
      on: () => { vLoop = true; vEnsure(); },
      off: () => { vLoop = false; vids().forEach((x) => { try { x.loop = false; } catch (e) {} }); vEnsure(); } },

    // 수업 도구
    { id: 'timer', cat: 'class', name: '타이머', desc: '수업·활동 시간을 재요. 사이트를 옮겨도 이어져요', kind: 'tool', build: buildTimer },
    { id: 'stopwatch', cat: 'class', name: '스톱워치', desc: '시간을 재고 랩을 기록해요', kind: 'tool', build: buildStopwatch },
    { id: 'rnum', cat: 'class', name: '번호 뽑기', desc: '출석번호를 무작위로 뽑아요', kind: 'tool', build: buildRandNum },
    { id: 'rname', cat: 'class', name: '이름 뽑기', desc: '이름 목록에서 한 명을 뽑아요', kind: 'tool', build: buildRandName },
    { id: 'teams', cat: 'class', name: '모둠 나누기', desc: '이름을 섞어서 모둠을 만들어요', kind: 'tool', build: buildTeams },
    { id: 'dice', cat: 'class', name: '주사위 · 동전', desc: '주사위를 굴리고 동전을 던져요', kind: 'tool', build: buildDice },
    { id: 'draw', cat: 'class', name: '칠판 펜', desc: '화면 위에 바로 그림을 그리며 설명해요',
      on: drawOn, off: drawOff },
    { id: 'noise', cat: 'class', name: '소음 측정기', desc: '교실 소리 크기를 막대로 보여줘요', kind: 'tool', build: buildNoise },
    { id: 'break', cat: 'class', name: '쉬는 시간 알림', desc: '정해진 시간마다 눈·몸을 쉬라고 알려줘요', persist: true,
      opt: { min: 5, max: 120, step: 5, def: 20, fmt: (v) => v + '분마다' },
      on: (v) => brStart(v === true ? 20 : v), off: brStop },
    { id: 'clock', cat: 'class', name: '큰 시계', desc: '화면 위에 시계를 띄워요. 누르면 크게 보여요',
      on: clockOn, off: clockOff },

    // 유틸
    { id: 'memo', cat: 'util', name: '메모장', desc: '어느 사이트에서나 같은 메모를 쓰고 저장해요', kind: 'tool', build: buildMemo },
    { id: 'calc', cat: 'util', name: '계산기', desc: '사칙연산, 괄호, 퍼센트를 계산해요', kind: 'tool', build: buildCalc },
    { id: 'count', cat: 'util', name: '글자 수 세기', desc: '글자·단어·줄 수를 세요', kind: 'tool', build: buildCount },
    { id: 'color', cat: 'util', name: '색 뽑기', desc: '화면에서 색을 찍어 색 코드를 복사해요', kind: 'tool', build: buildColor }
  ];
  F.forEach((f) => { f.kind = f.kind || (f.on ? 'toggle' : 'action'); });
  const byId = {};
  F.forEach((f) => { byId[f.id] = f; });

  // 현재 페이지에서 켜져 있는 기능 { id: true | 값 }
  const active = {};
  let uiRefresh = null;

  function setActive(id, v) {
    const f = byId[id];
    if (!f) return;
    const m = C.jget('labOn', {});
    if (v) {
      try { f.on(v); } catch (e) { console.warn('[lab]', id, e); }
      active[id] = v;
      if (f.persist) { m[id] = v; C.jset('labOn', m); }
    } else {
      try { if (f.off) f.off(); } catch (e) { console.warn('[lab]', id, e); }
      delete active[id];
      if (f.persist && m[id] !== undefined) { delete m[id]; C.jset('labOn', m); }
    }
    if (uiRefresh) uiRefresh();
  }

  // ───────── 실험실 탭 화면 ─────────
  const CSS = `
.lb-wrap{flex:1;min-height:0;display:flex;flex-direction:column}
.lb-q{margin:8px 10px 4px;padding:7px 10px;border:1px solid #cbd5e1;border-radius:8px;font-size:12px;width:calc(100% - 20px);outline:none;background:#fff;color:#1e293b}
.lb-q:focus{border-color:#2563eb}
.lb-scroll{flex:1;min-height:0;overflow-y:auto;padding:0 10px 14px;overscroll-behavior:contain}
.lb-h{margin:12px 2px 2px;font-size:12px;font-weight:700;color:#4338ca}
.lb-item{margin-top:6px}
.lb-row{display:flex;align-items:center;gap:8px;padding:8px 10px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc}
.lb-item.on .lb-row{background:#eff6ff;border-color:#93c5fd}
.lb-item.on.hasopt .lb-row{border-radius:10px 10px 0 0}
.lb-tx{flex:1;min-width:0}
.lb-n{font-size:13px;font-weight:700;color:#1e293b}
.lb-d{font-size:11px;color:#64748b;margin-top:2px;line-height:1.4;word-break:keep-all}
.lb-sw{width:38px;height:22px;border-radius:12px;border:none;background:#cbd5e1;position:relative;cursor:pointer;flex:none;padding:0}
.lb-sw::after{content:'';position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:50%;background:#fff;transition:left .15s}
.lb-sw.on{background:#2563eb}
.lb-sw.on::after{left:19px}
.lb-go{flex:none;padding:5px 11px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;color:#334155;font-size:12px;font-weight:700;cursor:pointer}
.lb-go:hover{background:#eff6ff;border-color:#2563eb}
.lb-sl{display:flex;align-items:center;gap:8px;padding:6px 12px;background:#eff6ff;border:1px solid #93c5fd;border-top:none;border-radius:0 0 10px 10px;font-size:11px;color:#1e3a8a}
.lb-sl input{flex:1;min-width:0;accent-color:#2563eb}
.lb-sl b{min-width:50px;text-align:right}
.lb-empty{padding:24px 8px;text-align:center;color:#94a3b8;font-size:12px}
.lb-thead{display:flex;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid #f1f5f9;flex:none}
.lb-thead b{font-size:14px;color:#1e293b}
.lb-tbody{flex:1;min-height:0;overflow-y:auto;padding:10px 12px 14px;display:flex;flex-direction:column;gap:8px}
.lb-r{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
.lb-t{font-size:12px;color:#475569}
.lb-note{font-size:11px;color:#64748b;line-height:1.5;word-break:keep-all}
.lb-b{padding:6px 12px;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc;color:#334155;font-size:12px;font-weight:700;cursor:pointer}
.lb-b:hover{background:#eff6ff;border-color:#2563eb}
.lb-b.main{background:#2563eb;border-color:#2563eb;color:#fff}
.lb-b.main:hover{background:#1d4ed8}
.lb-in{padding:6px 8px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;background:#fff;color:#1e293b;outline:none;min-width:0}
.lb-in:focus{border-color:#2563eb}
.lb-ta{width:100%;padding:8px;border:1px solid #cbd5e1;border-radius:8px;font-size:12px;resize:vertical;outline:none;background:#fff;color:#1e293b;line-height:1.5}
.lb-ta.tall{min-height:150px}
.lb-ta:focus{border-color:#2563eb}
.lb-big{font-size:46px;font-weight:700;text-align:center;color:#0f172a;padding:10px 0;letter-spacing:1px;word-break:break-all}
.lb-big.sm{font-size:26px}
.lb-list{display:flex;flex-direction:column;gap:6px}
.lb-li{padding:5px 8px;background:#f1f5f9;border-radius:6px;font-size:12px}
.lb-team{padding:8px 10px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc;font-size:12px;line-height:1.6}
.lb-team b{color:#4338ca}
.lb-meter{height:16px;border-radius:8px;background:#e2e8f0;overflow:hidden}
.lb-fill{height:100%;width:0;background:#22c55e;transition:width .08s}
.lb-warn{padding:10px;border-radius:10px;background:#fee2e2;color:#b91c1c;font-weight:700;text-align:center;font-size:16px}
.lb-rng{flex:1;min-width:80px;accent-color:#2563eb}
.lb-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}
.lb-grid .lb-b{padding:10px 0;font-size:15px}
.lb-calc{width:100%;font-size:20px;text-align:right;padding:10px}
.lb-stats{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.lb-stat{padding:8px 10px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc;display:flex;flex-direction:column;gap:2px}
.lb-stat b{font-size:16px;color:#1e293b}
.lb-swatch{height:64px;border-radius:12px;border:1px solid #cbd5e1;background:#f1f5f9}
.lb-sws{display:flex;flex-wrap:wrap;gap:6px}
.lb-sw1{width:28px;height:28px;border-radius:8px;border:1px solid #cbd5e1;cursor:pointer;padding:0}
`;

  function mount(box) {
    box.textContent = '';
    const wrap = mk('div', 'lb-wrap');
    box.appendChild(wrap);

    const listView = mk('div', 'lb-wrap');
    const q = mk('input', 'lb-q');
    q.placeholder = '기능 검색 (예: 타이머, 다크)';
    q.type = 'search';
    const scroll = mk('div', 'lb-scroll');
    listView.appendChild(q);
    listView.appendChild(scroll);

    const toolView = mk('div', 'lb-wrap');
    toolView.style.display = 'none';
    wrap.appendChild(listView);
    wrap.appendChild(toolView);
    let cleanup = null;

    function render() {
      const key = q.value.trim().toLowerCase();
      const top = scroll.scrollTop;
      scroll.textContent = '';
      let shown = 0;
      CATS.forEach(([cid, cname]) => {
        const items = F.filter((f) => f.cat === cid && (!key || (f.name + ' ' + f.desc).toLowerCase().indexOf(key) > -1));
        if (!items.length) return;
        scroll.appendChild(mk('div', 'lb-h', cname));
        items.forEach((f) => {
          shown++;
          const on = !!active[f.id];
          const item = mk('div', 'lb-item' + (on ? ' on' : '') + (on && f.opt ? ' hasopt' : ''));
          const r = mk('div', 'lb-row');
          const tx = mk('div', 'lb-tx');
          tx.appendChild(mk('div', 'lb-n', f.name));
          tx.appendChild(mk('div', 'lb-d', f.desc));
          r.appendChild(tx);
          if (f.kind === 'toggle') {
            const s = mk('button', 'lb-sw' + (on ? ' on' : ''));
            s.type = 'button';
            s.setAttribute('role', 'switch');
            s.setAttribute('aria-checked', on ? 'true' : 'false');
            s.setAttribute('aria-label', f.name);
            s.onclick = () => setActive(f.id, on ? false : (f.opt ? f.opt.def : true));
            r.appendChild(s);
          } else {
            const b = mk('button', 'lb-go', f.kind === 'tool' ? '열기' : '실행');
            b.type = 'button';
            b.onclick = () => (f.kind === 'tool' ? openTool(f) : f.run());
            r.appendChild(b);
          }
          item.appendChild(r);
          if (on && f.opt) {
            const sl = mk('div', 'lb-sl');
            const inp = document.createElement('input');
            inp.type = 'range';
            inp.min = f.opt.min; inp.max = f.opt.max; inp.step = f.opt.step;
            inp.value = typeof active[f.id] === 'number' ? active[f.id] : f.opt.def;
            const lab = mk('b', '', f.opt.fmt(parseFloat(inp.value)));
            let tm = null;
            inp.oninput = () => {
              const v = parseFloat(inp.value);
              lab.textContent = f.opt.fmt(v);
              try { f.on(v); } catch (e) {}
              active[f.id] = v;
              clearTimeout(tm);
              tm = setTimeout(() => {
                if (f.persist) { const m = C.jget('labOn', {}); m[f.id] = v; C.jset('labOn', m); }
              }, 250);
            };
            sl.appendChild(inp);
            sl.appendChild(lab);
            item.appendChild(sl);
          }
          scroll.appendChild(item);
        });
      });
      if (!shown) scroll.appendChild(mk('div', 'lb-empty', '찾는 기능이 없어요'));
      scroll.scrollTop = top;
    }

    function backToList() {
      if (cleanup) { try { cleanup(); } catch (e) {} cleanup = null; }
      toolView.style.display = 'none';
      toolView.textContent = '';
      listView.style.display = 'flex';
      render();
    }
    function openTool(f) {
      listView.style.display = 'none';
      toolView.style.display = 'flex';
      toolView.textContent = '';
      const head = mk('div', 'lb-thead');
      const back = mk('button', 'lb-go', '← 목록');
      back.type = 'button';
      back.onclick = backToList;
      head.appendChild(back);
      head.appendChild(mk('b', '', f.name));
      const body = mk('div', 'lb-tbody');
      toolView.appendChild(head);
      toolView.appendChild(body);
      try { cleanup = f.build(body) || null; } catch (e) { body.appendChild(mk('div', 'lb-note', '열 수 없어요: ' + e.message)); }
    }

    q.oninput = render;
    render();
    uiRefresh = () => { if (listView.style.display !== 'none') render(); };
    return { refresh: render, back: backToList };
  }

  // ───────── 바깥에서 쓰는 입구 ─────────
  g.NWLab = {
    css: CSS,
    count: F.length,
    init(ctx) { C = Object.assign(C, ctx); },
    // 페이지가 열릴 때: 저장된 켜짐 상태 복원, 타이머·쉬는 알림 이어가기
    boot() {
      const m = C.jget('labOn', {});
      F.forEach((f) => {
        if (f.persist && m[f.id]) {
          try { f.on(m[f.id]); active[f.id] = m[f.id]; } catch (e) { console.warn('[lab]', f.id, e); }
        }
      });
      timerEnsure();
    },
    sync() { try { timerEnsure(); } catch (e) {} },
    mount: mount,
    toast: toast
  };
})(self);
