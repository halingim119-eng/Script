(function () {
  'use strict';

  const cache = {};

  function GM_getValue(k, d) {
    return Object.prototype.hasOwnProperty.call(cache, k) ? cache[k] : d;
  }
  function GM_setValue(k, v) {
    cache[k] = v;
    try { chrome.storage.local.set({ [k]: v }); } catch (e) {}
  }

  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area !== 'local') return;
      for (const k in ch) {
        if (ch[k].newValue === undefined) delete cache[k]; else cache[k] = ch[k].newValue;
      }
    });
  } catch (e) {}

  function main() {
    const DEFAULT_CLASS = '6학년2반';
    const FOLIO_MAIN = 'https://folio.itt.link/cop/cmy/index.do';
    const FLOW_HOSTS = ['auth.worksmobile.com', 'newtab.itt.link', 'folio.itt.link'];
    const LIVE_KEEP = 30000;

    const host = location.hostname;
    const path = location.pathname.replace(/;.*$/, '');
    const now = () => Date.now();

    const isFolioHome = host === 'folio.itt.link' &&
      /^\/(index\.do|main\.do|cop\/cmy\/(index|main)\.do)?$/.test(path);
    const isClassPage = host === 'folio.itt.link' && /^\/cmy\/[^\/]+\.do$/.test(path);

    const jget = (k, d) => {
      try { const v = GM_getValue(k, ''); return v ? JSON.parse(v) : d; } catch (e) { return d; }
    };
    const jset = (k, v) => GM_setValue(k, JSON.stringify(v));

    const cfg = {
      get id() { return GM_getValue('id', ''); },
      get pw() { return GM_getValue('pw', ''); },
      get enabled() { return GM_getValue('enabled', true); },
      get showUi() { return GM_getValue('showUi', true); },
      get boardOn() { return GM_getValue('boardOn', true); },
      get doneSec() {
        const n = parseInt(GM_getValue('doneSec', 3), 10);
        return isNaN(n) ? 3 : Math.min(30, Math.max(1, n));
      },
      get dest() {
        const d = GM_getValue('dest', 'auto');
        return (d === 'classroom' || d === 'class') ? 'auto' : d;
      },
      get custom() { return GM_getValue('customUrl', ''); },
      get classMode() { return GM_getValue('classMode', 'name'); },
      get classKey() { return (GM_getValue('classKey', '') || DEFAULT_CLASS).replace(/\s+/g, ''); },
      get classPick() { return GM_getValue('classPick', ''); }
    };

    const hasCreds = () => !!(cfg.id && cfg.pw);

    function destUrl() {
      const d = cfg.dest;
      if (d === 'auto' || d === 'folio') return FOLIO_MAIN;
      if (d === 'custom' && cfg.custom) return cfg.custom;
      return null;
    }

    function fontCss() {
      let u = '';
      try { u = chrome.runtime.getURL('font.woff2'); } catch (e) {}
      return u ? "@font-face{font-family:'Galmuri11';src:url('" + u + "') format('woff2');font-display:block}" : '';
    }


    const iconUrl = () => {
      try { return chrome.runtime.getURL('icons/icon128.png'); } catch (e) { return ''; }
    };

    const scopeCss = (css, id) => css.replace(/([^{}]+)\{/g, (m, sel) =>
      sel.split(',').map((s) => id + ' ' + s.trim()).join(',') + '{');

    const ROOT_CSS = `
#__nw_win__{position:fixed;right:16px;bottom:16px;width:660px;height:470px;max-width:calc(100vw - 16px);max-height:calc(100vh - 16px);
  z-index:2147483647;margin:0;padding:0;color:#1e293b;font-size:13px;line-height:1.4;text-align:left}
#__nw_win__.big{width:960px;height:640px}` + `@keyframes nwShimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}@keyframes nwPop{0%{opacity:0;transform:translateY(10px) scale(.98)}100%{opacity:1;transform:none}}@keyframes nwFade{0%{opacity:0}100%{opacity:1}}@keyframes nwBounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}`;

    const WIN_RAW = `
*{box-sizing:border-box;margin:0;padding:0;font-family:'Galmuri11','Malgun Gothic','Apple SD Gothic Neo',sans-serif!important}
.w-win{width:100%;height:100%;display:flex;flex-direction:column;background:#f6f7fb;border-radius:18px;border:1px solid rgba(99,102,241,.28);
  box-shadow:0 26px 64px -16px rgba(49,46,129,.5),0 6px 18px rgba(15,23,42,.14);overflow:hidden;animation:nwPop .22s ease-out}

.w-bar{flex:none;height:46px;display:flex;align-items:center;gap:10px;padding:0 10px 0 14px;background:linear-gradient(120deg,#4f46e5 0%,#7c3aed 58%,#db2777 135%);
  cursor:move;user-select:none;-webkit-user-select:none;touch-action:none}
.w-bar img{width:26px;height:26px;flex:none;pointer-events:none;border-radius:8px;background:rgba(255,255,255,.92);padding:2px}
.w-ttl{flex:1;min-width:0;font-size:14px;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none;letter-spacing:.2px}
.w-btns{display:flex;gap:5px;flex:none}
.w-bt{width:30px;height:26px;border:none;border-radius:9px;background:rgba(255,255,255,.18);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:background .15s}
.w-bt:hover{background:rgba(255,255,255,.34)}
.w-bt.x:hover{background:#ef4444}
.w-bt i{display:block;position:relative;width:10px;height:10px}
.w-bt.mx i{border:1.5px solid #fff;border-radius:2px}
.w-bt.x i::before,.w-bt.x i::after{content:'';position:absolute;left:-1px;top:4px;width:12px;height:1.5px;background:#fff;border-radius:1px}
.w-bt.x i::before{transform:rotate(45deg)}
.w-bt.x i::after{transform:rotate(-45deg)}

.w-body{flex:1;min-height:0;display:flex}
.w-rail{flex:none;width:98px;background:#fff;border-right:1px solid #e8eaf3;padding:14px 9px;display:flex;flex-direction:column;gap:7px}
.w-logo{display:block;width:56px;height:56px;margin:0 auto 10px;filter:drop-shadow(0 6px 8px rgba(124,58,237,.3))}
.w-tab{display:flex;flex-direction:column;align-items:center;gap:4px;padding:10px 4px;border:1px solid transparent;border-radius:13px;background:transparent;color:#6b7280;font-size:12px;font-weight:700;cursor:pointer;transition:all .15s}
.w-tab .ti{font-style:normal;font-size:19px;line-height:1}
.w-tab:hover{background:#f1f2fb;color:#4338ca}
.w-tab.on{background:linear-gradient(135deg,#eef2ff,#f5f3ff);color:#4338ca;border-color:#c7d2fe;box-shadow:0 5px 12px -5px rgba(79,70,229,.4)}

.w-main{flex:1;min-width:0;display:flex;flex-direction:column;background:#f6f7fb}
.w-pane{display:none;flex:1;min-height:0;flex-direction:column}
.w-pane.on{display:flex}

.bd-top{flex:none;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:11px 14px 4px}
.bd-sub{min-width:0;font-size:12px;font-weight:700;color:#4338ca;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bd-find{flex:none;padding:6px 14px 2px}
.bd-search{width:100%;padding:8px 13px;border:1px solid #dfe3f1;border-radius:12px;background:#fff;font-size:12px;color:#1e293b;outline:none;transition:border-color .15s,box-shadow .15s}
.bd-search:focus{border-color:#818cf8;box-shadow:0 0 0 3px rgba(129,140,248,.25)}
.bd-grid{flex:1;min-height:0;overflow-y:auto;padding:10px 14px 16px;display:grid;grid-template-columns:repeat(auto-fill,minmax(235px,1fr));gap:12px;align-content:start;align-items:start;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-color:#c7cbe6 transparent}
.bd-msg{grid-column:1/-1;padding:40px 10px;text-align:center;color:#475569;font-size:13px;line-height:1.75;word-break:keep-all}
.bd-msg .nw-sbtn{margin-top:12px}
.bd-sk{height:104px;border-radius:15px;background:linear-gradient(90deg,#eceef7 25%,#f8f9fe 50%,#eceef7 75%);background-size:200% 100%;animation:nwShimmer 1.3s linear infinite}

.bd-item{position:relative;display:flex;flex-direction:column;gap:9px;padding:13px 14px 11px;border:1px solid #e6e8f2;border-radius:16px;background:#fff;min-width:0;cursor:pointer;
  box-shadow:0 1px 2px rgba(15,23,42,.05);transition:transform .15s,box-shadow .15s,border-color .15s}
.bd-item:hover{transform:translateY(-2px);border-color:#a5b4fc;box-shadow:0 12px 24px -12px rgba(79,70,229,.5)}
.bd-head{display:flex;gap:10px;align-items:flex-start;min-width:0}
.bd-av{flex:none;width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px;font-weight:700;box-shadow:0 3px 8px -3px rgba(79,70,229,.6)}
.bd-hx{flex:1;min-width:0}
.bd-t{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:13px;font-weight:700;color:#1e1b4b;text-decoration:none;word-break:break-all;line-height:1.4}
.bd-t:hover{color:#4f46e5}
.bd-m{margin-top:3px;font-size:11px;color:#94a3b8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bd-p{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;font-size:12px;color:#475569;word-break:break-all;line-height:1.55;padding:8px 10px;border-radius:10px;background:#f8f9fd}
.bd-chips{display:flex;flex-wrap:wrap;gap:5px}
.bd-c{display:inline-block;max-width:100%;padding:3px 10px;border-radius:12px;font-size:11px;text-decoration:none;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bd-c.l{background:#eef2ff;color:#4338ca;border:1px solid #c7d2fe}
.bd-c.f{background:#ecfdf5;color:#047857;border:1px solid #a7f3d0}
.bd-c:hover{filter:brightness(.94)}
.bd-imgbtn{align-self:flex-start;padding:4px 11px;border:1px solid #fcd34d;border-radius:9px;background:#fffbeb;color:#b45309;font-size:11px;font-weight:700;cursor:pointer}
.bd-imgbtn:hover{filter:brightness(.96)}
.bd-imgbtn.on{background:#f1f5f9;border-color:#cbd5e1;color:#475569}
.bd-imgs{display:flex;flex-direction:column;gap:6px}
.bd-imgs a{display:block;border-radius:10px;overflow:hidden;border:1px solid #e2e8f0;background:#f1f5f9;font-size:11px;color:#64748b;text-decoration:none;word-break:break-all}
.bd-imgs img{display:block;width:100%;height:auto;max-height:260px;object-fit:contain}
.bd-go{align-self:flex-end;font-size:11px;font-weight:700;color:#6366f1;opacity:0;transform:translateX(-4px);transition:all .15s}
.bd-item:hover .bd-go{opacity:1;transform:none}

.st-tabs{flex:none;display:flex;gap:5px;flex-wrap:wrap;padding:12px 14px 0}
.st-tab{padding:5px 13px;font-size:12px;font-weight:700;border:1px solid #e2e5f2;border-radius:10px;background:#fff;color:#6b7280;cursor:pointer;transition:all .15s}
.st-tab:hover{border-color:#a5b4fc;color:#4338ca}
.st-tab.on{background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;border-color:transparent;box-shadow:0 5px 12px -5px rgba(79,70,229,.6)}
.st-body{flex:1;min-height:0;overflow-y:auto;padding:8px 14px;scrollbar-width:thin}
.st-pane{display:none}
.st-pane.on{display:block}
.st-foot{flex:none;display:flex;justify-content:flex-end;align-items:center;gap:7px;padding:9px 14px;border-top:1px solid #e8eaf3;background:#fff}

.nw-row{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 4px;border-bottom:1px solid #eceef6;font-size:13px;color:#334155;cursor:pointer}
.nw-row.col{flex-direction:column;align-items:stretch;cursor:default;gap:4px}
.nw-row.rad{justify-content:flex-start}
.nw-row input[type=checkbox],.nw-row input[type=radio]{width:16px;height:16px;accent-color:#6366f1;flex:none;cursor:pointer}
.nw-lb{font-size:11px;color:#64748b}
.nw-in{width:100%;padding:8px 10px;border:1px solid #dfe3f1;border-radius:10px;font-size:12px;background:#fff;color:#1e293b;outline:none;transition:border-color .15s,box-shadow .15s}
.nw-in:focus{border-color:#818cf8;box-shadow:0 0 0 3px rgba(129,140,248,.25)}
.nw-in.num{width:72px;text-align:right}
.nw-two{display:flex;gap:6px;align-items:center}
.nw-sbtn{padding:7px 13px;border:1px solid #dfe3f1;border-radius:10px;background:#fff;color:#4338ca;font-size:12px;font-weight:700;cursor:pointer;white-space:nowrap;transition:all .15s}
.nw-sbtn:hover{background:#eef2ff;border-color:#818cf8}
.nw-sbtn.main{background:linear-gradient(135deg,#4f46e5,#7c3aed);border-color:transparent;color:#fff;box-shadow:0 6px 14px -6px rgba(79,70,229,.7)}
.nw-sbtn.main:hover{filter:brightness(1.07)}
.nw-saved{color:#16a34a;font-weight:700;font-size:12px;margin-right:auto}
.nw-ibox{border-radius:14px;border:1px solid #e6e8f2;background:#fff;padding:11px 15px;display:flex;flex-direction:column;gap:6px;margin:9px 0;min-width:0}
.nw-ih{font-size:12px;font-weight:700;color:#4338ca}
.nw-k{font-size:10px;color:#64748b;margin-top:2px}
.nw-v{font-size:13px;font-weight:700;color:#1e293b;word-break:break-all;line-height:1.35}
.nw-keys{font-size:11px;color:#475569;line-height:1.75}

.w-st{flex:none;display:flex;align-items:center;gap:9px;padding:8px 14px;min-height:44px;border-top:1px solid #e8eaf3;background:#fff}
.w-st[data-st=working]{background:#eef2ff;border-top-color:#c7d2fe}
.w-st[data-st=done]{background:#f0fdf4;border-top-color:#bbf7d0}
.w-st[data-st=error]{background:#fef2f2;border-top-color:#fecaca}
.w-st[data-st=need]{background:#fffbeb;border-top-color:#fde68a}
.nw-chip{flex:none;padding:3px 10px;border-radius:12px;background:#94a3b8;color:#fff;font-size:11px;font-weight:700}
.w-st[data-st=working] .nw-chip{background:#6366f1}
.w-st[data-st=done] .nw-chip{background:#22c55e}
.w-st[data-st=error] .nw-chip{background:#ef4444}
.w-st[data-st=need] .nw-chip{background:#f59e0b}
.w-stx{flex:1;min-width:0}
.nw-st-t{font-size:12px;font-weight:700;color:#1e293b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.nw-st-s{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:11px;color:#475569;margin-top:1px;line-height:1.35;word-break:keep-all}
.nw-st-time{flex:none;font-size:11px;color:#94a3b8}`;

    const WIN_CSS = ROOT_CSS + scopeCss(WIN_RAW, '#__nw_win__');

    const boardPaneHtml = (k) =>
      '<div class="w-pane" data-t="' + k + '"><div class="bd-top"><div class="bd-sub"></div>' +
      '<button type="button" class="nw-sbtn bd-refresh" data-k="' + k + '" title="새로고침">↻ 새로고침</button></div>' +
      '<div class="bd-find"><input type="search" class="bd-search" placeholder="🔍  제목 · 내용 · 작성자로 찾기" autocomplete="off"></div>' +
      '<div class="bd-grid"></div></div>';

    const WIN_HTML = () => `
<style>${fontCss()}${WIN_CSS}</style>
<div class="w-win">
  <div class="w-bar" id="__nw_bar__">
    <img src="${iconUrl()}" alt="">
    <div class="w-ttl" id="__nw_ttl__">설정</div>
    <div class="w-btns">
      <button type="button" class="w-bt mx" id="__nw_size__" title="크게 / 작게"><i></i></button>
      <button type="button" class="w-bt x" id="__nw_x__" title="닫기 (Esc)"><i></i></button>
    </div>
  </div>
  <div class="w-body">
    <div class="w-rail">
      <img class="w-logo" src="${iconUrl()}" alt="자동 로그인">
      <button type="button" class="w-tab" data-t="story"><i class="ti">💬</i><span>이야기방</span></button>
      <button type="button" class="w-tab" data-t="share"><i class="ti">📌</i><span>게시물방</span></button>
      <button type="button" class="w-tab" data-t="set"><i class="ti">⚙️</i><span>설정</span></button>
    </div>
    <div class="w-main">
      ${boardPaneHtml('story')}
      ${boardPaneHtml('share')}
      <div class="w-pane" data-t="set">
        <div class="st-tabs">
          <button type="button" class="st-tab on" data-p="acc">계정</button>
          <button type="button" class="st-tab" data-p="act">동작</button>
          <button type="button" class="st-tab" data-p="dst">이동</button>
          <button type="button" class="st-tab" data-p="cls">반</button>
          <button type="button" class="st-tab" data-p="inf">정보</button>
        </div>
        <div class="st-body">
          <div class="st-pane on" data-p="acc">
            <div class="nw-row col"><span class="nw-lb">아이디</span><input class="nw-in" id="__nw_id__" type="text" autocomplete="off"></div>
            <div class="nw-row col"><span class="nw-lb">비밀번호</span><div class="nw-two"><input class="nw-in" id="__nw_pw__" type="password" autocomplete="new-password"><button type="button" class="nw-sbtn" id="__nw_pwshow__">비밀번호 보이기</button></div></div>
          </div>
          <div class="st-pane" data-p="act">
            <label class="nw-row"><span>자동 로그인 사용</span><input type="checkbox" id="__nw_en__"></label>
            <label class="nw-row"><span>작동 중 화면 표시</span><input type="checkbox" id="__nw_ui__"></label>
            <label class="nw-row"><span>로그인 후 게시물방 열어주기</span><input type="checkbox" id="__nw_bd__"></label>
            <div class="nw-row"><span>완료 후 화면 유지 (초)</span><input class="nw-in num" id="__nw_ds__" type="number" min="1" max="30"></div>
          </div>
          <div class="st-pane" data-p="dst">
            <label class="nw-row rad"><input type="radio" name="nwd" value="auto"><span>내 반으로 바로 들어가기</span></label>
            <label class="nw-row rad"><input type="radio" name="nwd" value="folio"><span>톡톡클래스 메인</span></label>
            <label class="nw-row rad"><input type="radio" name="nwd" value="stay"><span>이동 안 함</span></label>
            <label class="nw-row rad"><input type="radio" name="nwd" value="custom"><span>직접 입력</span></label>
            <div class="nw-row col"><input class="nw-in" id="__nw_url__" type="text" placeholder="https://..."></div>
          </div>
          <div class="st-pane" data-p="cls">
            <label class="nw-row rad"><input type="radio" name="nwc" value="name"><span>이름으로 찾기</span></label>
            <div class="nw-row col"><input class="nw-in" id="__nw_ck__" type="text" placeholder="예: 6학년2반"></div>
            <label class="nw-row rad"><input type="radio" name="nwc" value="pick"><span>목록에서 고르기</span></label>
            <div class="nw-row col"><div class="nw-two"><select class="nw-in" id="__nw_cp__"></select><button type="button" class="nw-sbtn" id="__nw_reload__">목록 불러오기</button></div></div>
            <label class="nw-row rad"><input type="radio" name="nwc" value="top"><span>올해 맨 위 반</span></label>
          </div>
          <div class="st-pane" data-p="inf">
            <div class="nw-ibox">
              <div class="nw-ih">현재 사이트</div>
              <div><div class="nw-k">사이트</div><div class="nw-v" id="__nw_site_n__"></div></div>
              <div><div class="nw-k">주소</div><div class="nw-v" id="__nw_site_u__" style="font-size:11px;font-weight:400"></div></div>
              <div><div class="nw-k">로그인 후 이동</div><div class="nw-v" id="__nw_site_d__"></div></div>
            </div>
            <div class="nw-ibox">
              <div class="nw-ih">내 계정</div>
              <div><div class="nw-k">이메일</div><div class="nw-v" id="__nw_a_id__"></div></div>
              <div><div class="nw-k">비밀번호</div><div class="nw-v" id="__nw_a_pw__"></div></div>
              <div><div class="nw-k">들어갈 반</div><div class="nw-v" id="__nw_a_c__"></div></div>
            </div>
            <div class="nw-ibox">
              <div class="nw-ih">단축키</div>
              <div class="nw-keys">Ctrl+1 / Alt+1 : 설정<br>Ctrl+2 / Alt+2 : 게시물방<br>Esc : 닫기 · 제목줄을 끌어서 이동 · 제목줄 더블클릭 : 위치 초기화</div>
            </div>
          </div>
        </div>
        <div class="st-foot">
          <span class="nw-saved" id="__nw_saved__"></span>
          <button type="button" class="nw-sbtn" id="__nw_go__">지금 내 반으로</button>
          <button type="button" class="nw-sbtn main" id="__nw_save__">저장</button>
        </div>
      </div>
    </div>
  </div>
  <div class="w-st" id="__nw_status__" data-st="idle">
    <span class="nw-chip" id="__nw_chip__">대기 중</span>
    <div class="w-stx">
      <div class="nw-st-t" id="__nw_st_t__"></div>
      <div class="nw-st-s" id="__nw_st_s__"></div>
    </div>
    <span class="nw-st-time" id="__nw_st_time__"></span>
    <button type="button" class="nw-sbtn" id="__nw_retry__" style="display:none">다시 시도</button>
  </div>
</div>`;

    let curState = null, closeTimer = null, tickTimer = null, manualOpen = false, pwShown = false, pwTimer = null, curTab = 'set';
    const TAB_NAME = { story: '이야기방', share: '게시물방', set: '설정' };
    const IDLE = { t: '대기 중', s: 'Ctrl+1 설정 · Ctrl+2 게시물방 · Esc 닫기', st: 'idle', ts: 0 };
    const dismissed = () => now() - GM_getValue('dismiss', 0) < 120000;


    function whenRoot(fn, n) {
      n = n || 0;
      if (document.documentElement) { fn(); return; }
      if (n < 400) setTimeout(() => whenRoot(fn, n + 1), 5);
    }


    const DEST_LABEL = {
      auto: '내 반으로 바로 들어가기',
      folio: '톡톡클래스 메인',
      stay: '이동 안 함',
      custom: '직접 입력한 주소'
    };

    function siteName() {
      if (host === 'auth.worksmobile.com') return 'NAVER WORKS 로그인';
      if (host === 'newtab.itt.link') return '아이톡톡 뉴탭';
      if (host === 'folio.itt.link') {
        if (isClassPage) return '톡톡클래스 (내 반)';
        if (isFolioHome) return '톡톡클래스 메인';
        return '톡톡클래스';
      }
      return host;
    }

    function classLabel() {
      const m = cfg.classMode;
      if (m === 'top') return '올해 맨 위 반';
      if (m === 'pick') {
        const e = jget('classMap', {})[cfg.classPick];
        return e ? (typeof e === 'string' ? e : e.n) : '(목록에서 고른 반)';
      }
      return cfg.classKey;
    }

    function updateInfo() {
      const set = (id, t) => { const e = document.getElementById(id); if (e) e.textContent = t; };
      set('__nw_a_id__', cfg.id || '입력 필요');
      set('__nw_a_pw__', cfg.pw ? (pwShown ? cfg.pw : '*'.repeat(cfg.pw.length)) : '입력 필요');
      set('__nw_a_c__', classLabel());
      set('__nw_site_n__', siteName());
      set('__nw_site_u__', host + path);
      set('__nw_site_d__', DEST_LABEL[cfg.dest] || cfg.dest);
    }

    function updateTime() {
      const el = document.getElementById('__nw_st_time__');
      if (!el || !curState) return;
      let txt = '';
      if (curState.st === 'working') {
        const s = GM_getValue('flowStart', 0);
        if (s && now() - s < 180000) txt = '로그인 후 ' + ((now() - s) / 1000).toFixed(1) + '초';
      } else {
        txt = curState.time || '';
      }
      el.textContent = txt;
      el.style.display = txt ? 'block' : 'none';
    }

    // ===== 창(하단 오른쪽 작은 창): 위치·드래그 =====
    function clampWin(w) {
      if (!w || !w.style.left) return;
      const r = w.getBoundingClientRect();
      const x = Math.min(Math.max(0, r.left), Math.max(0, window.innerWidth - r.width));
      const y = Math.min(Math.max(0, r.top), Math.max(0, window.innerHeight - r.height));
      w.style.left = x + 'px';
      w.style.top = y + 'px';
    }

    function placeWin(w) {
      const pos = jget('winPos', null);
      if (pos && typeof pos.x === 'number' && typeof pos.y === 'number') {
        w.style.left = pos.x + 'px';
        w.style.top = pos.y + 'px';
        w.style.right = 'auto';
        w.style.bottom = 'auto';
        clampWin(w);
      }
    }

    function resetWinPos(w) {
      GM_setValue('winPos', '');
      w.style.left = w.style.top = '';
      w.style.right = w.style.bottom = '';
    }

    function enableDrag(w, bar) {
      let drag = false, sx = 0, sy = 0, ox = 0, oy = 0;
      bar.addEventListener('pointerdown', (e) => {
        if (e.button !== 0 || (e.target.closest && e.target.closest('button'))) return;
        const r = w.getBoundingClientRect();
        drag = true; sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top;
        w.style.left = ox + 'px';
        w.style.top = oy + 'px';
        w.style.right = 'auto';
        w.style.bottom = 'auto';
        try { bar.setPointerCapture(e.pointerId); } catch (err) {}
        e.preventDefault();
      });
      bar.addEventListener('pointermove', (e) => {
        if (!drag) return;
        const r = w.getBoundingClientRect();
        const x = Math.min(Math.max(0, ox + e.clientX - sx), Math.max(0, window.innerWidth - r.width));
        const y = Math.min(Math.max(0, oy + e.clientY - sy), Math.max(0, window.innerHeight - r.height));
        w.style.left = x + 'px';
        w.style.top = y + 'px';
      });
      const end = (e) => {
        if (!drag) return;
        drag = false;
        try { bar.releasePointerCapture(e.pointerId); } catch (err) {}
        const r = w.getBoundingClientRect();
        jset('winPos', { x: Math.round(r.left), y: Math.round(r.top) });
      };
      bar.addEventListener('pointerup', end);
      bar.addEventListener('pointercancel', end);
      bar.addEventListener('dblclick', (e) => {
        if (e.target.closest && e.target.closest('button')) return;
        resetWinPos(w);
      });
    }

    function removeWin(fade) {
      const w = document.getElementById('__nw_win__');
      if (!w) return;
      clearInterval(tickTimer);
      clearTimeout(closeTimer);
      clearTimeout(pwTimer);
      pwShown = false;
      manualOpen = false;
      if (fade) {
        w.dataset.closing = '1';
        w.style.transition = 'opacity .4s';
        w.style.opacity = '0';
        setTimeout(() => w.remove(), 400);
      } else {
        w.remove();
      }
    }

    function closeByUser() {
      GM_setValue('dismiss', now());
      removeWin(false);
    }

    function setTab(tab) {
      const w = document.getElementById('__nw_win__');
      if (!w || !TAB_NAME[tab]) return;
      curTab = tab;
      w.querySelectorAll('.w-tab').forEach((t) => t.classList.toggle('on', t.getAttribute('data-t') === tab));
      w.querySelectorAll('.w-pane').forEach((p) => p.classList.toggle('on', p.getAttribute('data-t') === tab));
      w.querySelector('#__nw_ttl__').textContent = TAB_NAME[tab];
      if (tab !== 'set' && !w._bd[tab]) {
        w._bd[tab] = 1;
        fillBoard(w, tab);
      }
    }

    function initWin(w) {
      const q = (s) => w.querySelector(s);
      const all = (s) => w.querySelectorAll(s);

      q('#__nw_id__').value = cfg.id;
      q('#__nw_pw__').value = cfg.pw;
      q('#__nw_en__').checked = cfg.enabled;
      q('#__nw_ui__').checked = cfg.showUi;
      q('#__nw_bd__').checked = cfg.boardOn;
      q('#__nw_ds__').value = cfg.doneSec;
      all('input[name="nwd"]').forEach((r) => { r.checked = r.value === cfg.dest; });
      q('#__nw_url__').value = cfg.custom;
      all('input[name="nwc"]').forEach((r) => { r.checked = r.value === cfg.classMode; });
      q('#__nw_ck__').value = GM_getValue('classKey', '') || DEFAULT_CLASS;
      updateInfo();

      all('.w-tab').forEach((t) => {
        t.onclick = () => { manualOpen = true; clearTimeout(closeTimer); setTab(t.getAttribute('data-t')); };
      });
      all('.st-tab').forEach((t) => {
        t.onclick = () => {
          all('.st-tab').forEach((x) => x.classList.toggle('on', x === t));
          all('.st-pane').forEach((pn) => pn.classList.toggle('on', pn.getAttribute('data-p') === t.getAttribute('data-p')));
        };
      });
      all('.bd-refresh').forEach((b) => { b.onclick = () => fillBoard(w, b.getAttribute('data-k')); });

      q('#__nw_x__').onclick = closeByUser;
      q('#__nw_size__').onclick = () => {
        const big = !w.classList.contains('big');
        w.classList.toggle('big', big);
        GM_setValue('winBig', big);
        clampWin(w);
      };
      enableDrag(w, q('#__nw_bar__'));

      const sel = q('#__nw_cp__');
      const map = jget('classMap', {});
      const items = Object.keys(map).map((k) => {
        const e = map[k];
        return typeof e === 'string' ? { p: k, n: e, y: 0 } : { p: k, n: e.n, y: e.y || 0 };
      }).sort((a, b) => (b.y - a.y) || a.n.localeCompare(b.n));
      if (!items.length) {
        const o = document.createElement('option');
        o.value = '';
        o.textContent = '아직 목록이 없어요. 옆 버튼으로 불러오세요';
        sel.appendChild(o);
      } else {
        items.forEach((i) => {
          const o = document.createElement('option');
          o.value = i.p;
          o.textContent = (i.y ? i.y + '년 ' : '') + i.n;
          if (i.p === cfg.classPick) o.selected = true;
          sel.appendChild(o);
        });
      }

      const pwIn = q('#__nw_pw__'), pwBtn = q('#__nw_pwshow__');
      const hidePw = () => {
        clearTimeout(pwTimer);
        pwShown = false;
        pwIn.type = 'password';
        pwBtn.textContent = '비밀번호 보이기';
        pwBtn.disabled = false;
        updateInfo();
      };
      pwBtn.onclick = () => {
        clearTimeout(pwTimer);
        pwShown = true;
        pwIn.type = 'text';
        pwBtn.textContent = '3초 후 가려져요';
        pwBtn.disabled = true;
        updateInfo();
        pwTimer = setTimeout(hidePw, 3000);
      };

      q('#__nw_reload__').onclick = () => {
        GM_setValue('noEnter', now());
        setTimeout(() => { location.href = FOLIO_MAIN; }, 30);
      };
      q('#__nw_go__').onclick = () => {
        GM_setValue('forceEnter', now());
        setTimeout(() => { location.href = FOLIO_MAIN; }, 30);
      };
      q('#__nw_retry__').onclick = () => {
        try { sessionStorage.removeItem('nw_tries'); } catch (e) {}
        GM_setValue('dismiss', 0);
        setTimeout(() => location.reload(), 30);
      };
      q('#__nw_save__').onclick = () => {
        const wasNeed = curState && curState.st === 'need';
        const d = w.querySelector('input[name="nwd"]:checked');
        const c = w.querySelector('input[name="nwc"]:checked');
        GM_setValue('id', q('#__nw_id__').value.trim());
        GM_setValue('pw', q('#__nw_pw__').value);
        GM_setValue('enabled', q('#__nw_en__').checked);
        GM_setValue('showUi', q('#__nw_ui__').checked);
        GM_setValue('boardOn', q('#__nw_bd__').checked);
        GM_setValue('doneSec', q('#__nw_ds__').value);
        GM_setValue('dest', d ? d.value : 'auto');
        GM_setValue('customUrl', q('#__nw_url__').value.trim());
        GM_setValue('classMode', c ? c.value : 'name');
        GM_setValue('classKey', q('#__nw_ck__').value.trim());
        GM_setValue('classPick', q('#__nw_cp__').value);
        updateInfo();
        const sv = q('#__nw_saved__');
        if (wasNeed && hasCreds()) {
          sv.textContent = '저장했어요. 로그인을 시작해요';
          try { sessionStorage.removeItem('nw_tries'); } catch (e) {}
          GM_setValue('dismiss', 0);
          setTimeout(() => location.reload(), 500);
          return;
        }
        sv.textContent = '저장했어요';
        setTimeout(() => { sv.textContent = ''; }, 2000);
      };
    }

    function ensureWin(tab) {
      let w = document.getElementById('__nw_win__');
      if (w && w.dataset.closing) { w.remove(); w = null; }
      if (w) return w;
      w = document.createElement('div');
      w.id = '__nw_win__';
      w._bd = {};
      if (GM_getValue('winBig', false)) w.classList.add('big');
      w.innerHTML = WIN_HTML();
      document.documentElement.appendChild(w);
      placeWin(w);
      initWin(w);
      paintState(w, curState || IDLE);
      setTab(tab || 'set');
      return w;
    }

    function paintState(w, u) {
      const stage = u.st || 'idle';
      const q = (s) => w.querySelector(s);
      q('#__nw_status__').setAttribute('data-st', stage);
      q('#__nw_chip__').textContent = { working: '작동 중', done: '완료', error: '확인 필요', need: '입력 필요', idle: '대기 중' }[stage] || '';
      q('#__nw_st_t__').textContent = u.t || '';
      const s = q('#__nw_st_s__');
      s.textContent = u.s || '';
      s.title = u.s || '';
      s.style.display = u.s ? '' : 'none';
      q('#__nw_retry__').style.display = stage === 'error' ? 'block' : 'none';
      updateInfo();
      updateTime();
    }

    function renderState(u, tab) {
      whenRoot(() => {
        const w = ensureWin(tab);
        curState = u;
        paintState(w, u);
        const stage = u.st || 'idle';
        clearInterval(tickTimer);
        clearTimeout(closeTimer);
        if (stage === 'working') tickTimer = setInterval(updateTime, 250);
        if (stage === 'done' && u.closeAt && !manualOpen) {
          closeTimer = setTimeout(() => {
            if (manualOpen) return;
            removeWin(true);
            GM_setValue('ui', '');
          }, Math.max(0, u.closeAt - now()));
        }
        if (stage === 'need') {
          setTab('set');
          const idEl = w.querySelector('#__nw_id__');
          if (idEl && !cfg.id) setTimeout(() => idEl.focus(), 50);
        }
      });
    }

    function openWin(tab, pin) {
      whenRoot(() => {
        ensureWin(tab);
        if (curTab !== tab) setTab(tab);
        if (pin) { manualOpen = true; clearTimeout(closeTimer); }
      });
    }

    function say(title, sub, stage, o) {
      o = o || {};
      const u = { t: title, s: sub || '', st: stage || 'working', ts: now(), time: o.time || '', custom: !!o.custom };
      if (u.st === 'done') u.closeAt = now() + cfg.doneSec * 1000;
      GM_setValue('ui', JSON.stringify(u));
      if (cfg.showUi && !dismissed()) renderState(u);
      if (u.st === 'done' && o.board && cfg.boardOn && now() - GM_getValue('boardTs', 0) > 10000) {
        GM_setValue('boardTs', now());
        openWin('share', true);
      }
    }

    function showNeed() {
      manualOpen = true;
      GM_setValue('dismiss', 0);
      renderState({
        t: '아이디와 비밀번호를 입력해 주세요',
        s: '설정의 계정 탭에 입력하고 저장하면 자동으로 로그인해요.',
        st: 'need',
        ts: now()
      }, 'set');
    }

    function endFlow() {
      GM_setValue('ui', '');
      if (!manualOpen) removeWin(false);
    }

    function flowLive() {
      const u = jget('ui', null);
      return !!(u && u.st === 'working' && now() - u.ts < LIVE_KEEP);
    }

    function finishTime() {
      const s = GM_getValue('flowStart', 0);
      GM_setValue('flowStart', 0);
      if (!s || now() - s > 180000) return '';
      return '로그인부터 ' + ((now() - s) / 1000).toFixed(1) + '초';
    }

    function toggleWin(tab) {
      const w = document.getElementById('__nw_win__');
      if (w && !w.dataset.closing) {
        if (curTab === tab) { closeByUser(); return; }
        manualOpen = true;
        clearTimeout(closeTimer);
        setTab(tab);
        return;
      }
      manualOpen = true;
      GM_setValue('dismiss', 0);
      if (!hasCreds()) { showNeed(); return; }
      const u = jget('ui', null);
      const live = u && u.st === 'working' && now() - u.ts < LIVE_KEEP;
      renderState(live ? u : IDLE, tab);
    }


    function runLogin() {
      const MAX = 4;
      const KEY = 'nw_tries';

      const fs = GM_getValue('flowStart', 0);
      if (!fs || now() - fs > 180000) {
        GM_setValue('flowStart', now());
        GM_setValue('dismiss', 0);
      }
      GM_setValue('pending', now());

      if (!curState || curState.st !== 'working') {
        say('지금 사이트: 로그인 페이지', '불러오는 중', 'working');
      }

      let rec;
      try { rec = JSON.parse(sessionStorage.getItem(KEY) || '{}'); } catch (e) { rec = {}; }
      if (!rec.t || now() - rec.t > 60000) rec = { t: now(), n: 0 };
      const save = () => sessionStorage.setItem(KEY, JSON.stringify(rec));

      if (rec.n >= MAX) {
        GM_setValue('pending', 0);
        say('자동 로그인을 멈췄어요', '짧은 시간에 여러 번 시도했어요. 아이디와 비밀번호를 확인한 뒤 다시 시도를 눌러 주세요.', 'error');
        return;
      }

      const used = new WeakSet();
      let stopped = false;
      const vis = (el) => !!el && el.offsetParent !== null;
      const mine = (el) => !!el.closest('#__nw_win__');

      function setVal(el, v) {
        const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value').set;
        el.focus();
        setter.call(el, v);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
      }

      function findBtn() {
        const sel = ['#loginStart', '#loginBtn', 'button.btn_submit',
                     'button[type="submit"]', 'input[type="submit"]'];
        for (const s of sel) {
          const b = document.querySelector(s);
          if (b && !mine(b) && vis(b) && !b.disabled) return b;
        }
        return null;
      }

      function clickBtn(pw) {
        let n = 0;
        const iv = setInterval(() => {
          const b = findBtn();
          if (b) { clearInterval(iv); b.click(); return; }
          if (++n > 60) {
            clearInterval(iv);
            if (pw && pw.form) pw.form.submit();
          }
        }, 25);
      }

      function keepLogin() {
        document.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
          if (mine(cb)) return;
          if (!cb.checked && vis(cb.parentElement || cb)) cb.click();
        });
      }

      function failMsg() {
        const el = document.querySelector('#fail_message, .invalid_desc');
        return (el && el.textContent.trim()) || '';
      }

      function tick() {
        if (stopped) return;
        const pw = Array.from(document.querySelectorAll('input[type="password"]')).filter((x) => !mine(x))[0] || null;
        const id = document.getElementById('user_id');
        const screen = (pw && !mine(pw) && vis(pw)) ? 'pw' : (vis(id) ? 'id' : 'wait');

        const err = failMsg();
        if (err && used.size) {
          stopped = true;
          rec.n = MAX; save();
          GM_setValue('pending', 0);
          say('로그인이 안 됐어요', err, 'error');
          return;
        }

        if (screen === 'wait') return;

        const target = screen === 'pw' ? pw : id;
        if (used.has(target)) return;

        const isPw = screen === 'pw';
        used.add(target);
        rec.n++; save();
        GM_setValue('pending', now());

        say('지금 사이트: ' + (isPw ? '비밀번호 입력' : '이메일 입력'),
            isPw ? '비밀번호를 넣고 로그인을 눌러요' : '이메일을 넣고 다음을 눌러요',
            'working');

        setVal(target, isPw ? cfg.pw : cfg.id);
        if (isPw) keepLogin();
        clickBtn(isPw ? pw : null);
      }

      function start() {
        tick();
        let n = 0;
        const iv = setInterval(() => {
          tick();
          if (stopped || ++n > 750) clearInterval(iv);
        }, 40);
      }
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start, { once: true });
      } else {
        start();
      }
    }

    function runNewtab() {
      const t = GM_getValue('pending', 0);
      const inFlow = flowLive();
      const u = destUrl();

      if ((t && now() - t < 120000) || inFlow) {
        GM_setValue('pending', 0);
        if (u) {
          say('지금 사이트: 뉴탭',
              cfg.dest === 'custom' ? '설정한 주소로 가는 중' : '톡톡클래스로 가는 중',
              'working', { custom: cfg.dest === 'custom' });
          try { window.stop(); } catch (e) {}
          location.replace(u);
        } else {
          say('지금 사이트: 뉴탭', '로그인이 끝났어요', 'done', { time: finishTime(), board: true });
        }
      } else {
        endFlow();
      }
    }

    const pathOf = (href) => {
      try { return new URL(href, location.href).pathname.replace(/;.*$/, ''); } catch (e) { return href; }
    };

    function listClasses() {
      const out = [];
      document.querySelectorAll('section.classList').forEach((sec, i) => {
        const h = sec.querySelector('h3');
        const m = h && h.textContent.match(/(20\d\d)/);
        const year = m ? parseInt(m[1], 10) : 0;
        sec.querySelectorAll('li.cmy a[href^="/cmy/"]').forEach((a) => {
          const st = a.querySelector('.st');
          const name = ((st && st.textContent) || a.textContent).replace(/\s+/g, '');
          const href = a.getAttribute('href');
          out.push({ sec: i, year: year, name: name, href: href, path: pathOf(href) });
        });
      });
      return out;
    }

    function pickClass(final) {
      const all = listClasses();
      if (!all.length) return null;

      if (cfg.classMode === 'pick' && cfg.classPick) {
        const c = all.filter((x) => x.path === cfg.classPick)[0];
        if (c) return c;
        if (!final) return null;
      }
      if (cfg.classMode !== 'top') {
        return all.filter((x) => x.name.indexOf(cfg.classKey) > -1)[0] || null;
      }
      if (!final) return all.filter((x) => x.sec === 0)[0] || null;
      const maxYear = Math.max.apply(null, all.map((x) => x.year));
      return all.filter((x) => x.year === maxYear)[0];
    }

    function rememberClasses(list) {
      const m = jget('classMap', {});
      list.forEach((c) => { m[c.path] = { n: c.name, y: c.year }; });
      jset('classMap', m);
    }

    function autoEnter(quiet) {
      if (!quiet) say('지금 사이트: 톡톡클래스', '내 반 찾는 중', 'working');
      let done = false, mo;

      const go = (c) => {
        done = true;
        if (mo) mo.disconnect();
        rememberClasses(listClasses());
        GM_setValue('enterTs', now());
        say('지금 사이트: 톡톡클래스', c.name + ' 들어가는 중', 'working');
        try { window.stop(); } catch (e) {}
        location.replace(new URL(c.href, location.href).href);
      };

      const attempt = (final) => {
        if (done || !document.body) return;
        const c = pickClass(final);
        if (c) { go(c); return; }
        if (final) {
          done = true;
          if (mo) mo.disconnect();
          if (quiet) return;
          const what = cfg.classMode === 'name' ? cfg.classKey + ' 반이 목록에 없어요'
                     : cfg.classMode === 'pick' ? '고른 반이 목록에 없어요'
                     : '반 목록이 비어 있어요';
          say('들어갈 반을 못 찾았어요', what, 'error');
        }
      };

      mo = new MutationObserver(() => attempt(false));
      mo.observe(document.documentElement, { childList: true, subtree: true });
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => attempt(true), { once: true });
      } else {
        attempt(true);
      }
    }

    function runFolio() {
      const inFlow = flowLive();
      GM_setValue('pending', 0);

      if (isFolioHome) {
        const nav = performance.getEntriesByType && performance.getEntriesByType('navigation')[0];
        const backFwd = !!(nav && nav.type === 'back_forward');
        let refHost = '', refPath = '';
        try { const r = new URL(document.referrer); refHost = r.hostname; refPath = r.pathname; } catch (e) {}
        const inSite = refHost === host && !/^\/uat\//.test(refPath);
        const recent = now() - GM_getValue('enterTs', 0) < 8000;
        const force = now() - GM_getValue('forceEnter', 0) < 20000;
        const noEnter = now() - GM_getValue('noEnter', 0) < 20000;
        GM_setValue('forceEnter', 0);
        GM_setValue('noEnter', 0);

        document.addEventListener('DOMContentLoaded', () => rememberClasses(listClasses()), { once: true });

        if (noEnter) {
          say('반 목록을 저장했어요', '설정 화면에서 고를 수 있어요', 'done');
        } else if (recent && !force) {
          say('반으로 못 들어갔어요', '톡톡클래스 메인으로 돌아왔어요', 'error');
        } else if (force || (cfg.dest === 'auto' && (inFlow || (!backFwd && !inSite)))) {
          autoEnter(false);
        } else if (inFlow) {
          say('지금 사이트: 톡톡클래스', '메인 화면이에요', 'done', { time: finishTime(), board: true });
        } else {
          endFlow();
        }
      } else if (isClassPage) {
        if (inFlow || now() - GM_getValue('enterTs', 0) < 20000) {
          const e = jget('classMap', {})[path];
          const name = e ? (typeof e === 'string' ? e : e.n) : '내 클래스';
          say('지금 사이트: 톡톡클래스', name, 'done', { time: finishTime(), board: true });
        } else {
          endFlow();
        }
      } else if (inFlow && cfg.dest === 'auto') {
        autoEnter(true);
      } else if (inFlow && cfg.dest === 'custom') {
        say('지금 사이트: 톡톡클래스', '도착했어요', 'done', { time: finishTime(), board: true });
      } else {
        endFlow();
      }
    }

    function runOther() {
      const u = jget('ui', null);
      if (u && u.st === 'working' && u.custom && now() - u.ts < 12000) {
        say('지금 사이트: ' + host, '도착했어요', 'done', { time: finishTime(), board: true });
      }
    }


    // ===== 이야기방 / 게시물방(공유방) 목록 (최대 100개) =====
    const BOARD_MAX = 100;
    const BOARD_PAGE = 20;
    const FOLIO_ORIGIN = 'https://folio.itt.link';
    const BOARD_KIND = {
      story: { key: 'storyIds', label: '이야기방', attr: 'BBSA20' },
      share: { key: 'boardIds', label: '게시물방', attr: 'BBSA50' }
    };
    const IMG_RE = /\.(jpe?g|png|gif|bmp|webp)$/i;

    function mk(tag, cls, text) {
      const e = document.createElement(tag);
      if (cls) e.className = cls;
      if (text != null) e.textContent = text;
      return e;
    }
    const hostOf = (u) => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return u; } };
    const safeUrl = (u) => {
      try { const x = new URL(u, FOLIO_ORIGIN); return /^https?:$/.test(x.protocol) ? x.href : null; } catch (e) { return null; }
    };
    const decode = (s) => {
      const t = document.createElement('textarea');
      t.innerHTML = String(s || '');
      return t.value;
    };

    // 현재 보고 있는 반이 "내 반"일 때만 게시판 주소(bbsId, trgetId)를 기억한다.
    function myClassNow(name) {
      const m = cfg.classMode;
      if (m === 'name') return !name || name.indexOf(cfg.classKey) > -1;
      const fresh = now() - GM_getValue('enterTs', 0) < 30000;
      if (m === 'pick') return path === cfg.classPick || (isClassPage && fresh);
      return isClassPage && fresh;
    }

    function learnBoardIds() {
      if (host !== 'folio.itt.link') return;
      const cn = document.querySelector('.classCon a');
      const name = cn ? cn.textContent.replace(/\s+/g, '') : '';
      let mineNow = null;
      Object.keys(BOARD_KIND).forEach((k) => {
        const a = document.querySelector('#' + BOARD_KIND[k].attr + ' a');
        if (!a) return;
        let u;
        try { u = new URL(a.getAttribute('href'), location.href); } catch (e) { return; }
        const bbsId = u.searchParams.get('bbsId'), trgetId = u.searchParams.get('trgetId');
        if (!bbsId || !trgetId) return;
        if (mineNow === null) mineNow = myClassNow(name);
        if (!mineNow) return;
        jset(BOARD_KIND[k].key, { bbsId: bbsId, trgetId: trgetId, name: name, ts: now() });
      });
    }

    // 게시판 목록 JSON을 불러온다. 로그인 세션(쿠키)은 브라우저가 알아서 보내 준다.
    async function pullBoard(base, b) {
      const out = [], seen = {};
      for (let page = 1; page <= 12 && out.length < BOARD_MAX; page++) {
        const p = new URLSearchParams({
          trgetId: b.trgetId, bbsId: b.bbsId, nttNo: '', searchOrdrCode: '', searchOrdrCodeDp: '',
          searchCate: '', searchTextbook: '', searchCnd: 'ALL', pageUnit: String(BOARD_PAGE),
          pageSize: String(BOARD_PAGE), pageIndex: String(page), searchOthbcAt: '', loadingEndYn: 'N',
          ajaxFlag: 'Y', searchWrd: ''
        });
        const r = await fetch(base + '/cop/cmy/bbs/selectBoardList.json?' + p.toString(), { credentials: 'include' });
        if (!r.ok) throw new Error('HTTP ' + r.status);
        let j;
        try { j = await r.json(); } catch (e) { throw new Error('LOGIN'); }
        const list = (j && j.data && j.data.resultList) || [];
        let added = 0;
        list.forEach((i) => {
          if (!i || !i.frstRegisterId || seen[i.nttNo] || out.length >= BOARD_MAX) return;
          seen[i.nttNo] = 1;
          added++;
          const files = [], imgs = [];
          (i.fileList || []).forEach((f) => {
            const nm = f.orignlFileNm || '';
            if (IMG_RE.test(nm) || IMG_RE.test('.' + (f.fileExtsn || ''))) {
              const cdn = (f.fileCdnUrl && f.fileCdnUrl !== 'null') ? f.fileCdnUrl : f.fileStreWebCours;
              imgs.push({ n: nm, u: (cdn && f.streFileNm) ? cdn + '/' + f.streFileNm : '', id: f.atchFileId, sn: f.fileSn });
            } else {
              files.push({ n: nm, id: f.atchFileId, sn: f.fileSn });
            }
          });
          out.push({
            no: i.nttNo, ord: i.ordrCode || '', dp: (i.ordrCodeDp == null ? '' : String(i.ordrCodeDp)),
            title: i.nttSj || '', who: i.ntcrNm || '',
            date: i.frstRegisterPnttmTmp || '',
            body: String(i.nttCn || '').slice(0, 3000),
            links: (i.linkList || []).map((l) => l.link).filter(Boolean),
            files: files, imgs: imgs
          });
        });
        if (!added) break;
      }
      return out;
    }

    // ===== 이야기방/게시물방 주소 자동 찾기 (아이디·토큰을 몰라도 로그인 세션만 있으면 됨) =====
    const FOLIO_BASE = 'https://folio.itt.link';
    const nwUnesc = (t) => String(t || '').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
    function nwParseNav(html) {
      const out = {};
      const re = /<li[^>]*\sid="(BBSA\d+)"[^>]*>\s*<a[^>]+href="([^"]+)"/g;
      let m;
      while ((m = re.exec(html))) {
        try {
          const u = new URL(nwUnesc(m[2]), FOLIO_BASE);
          const bbsId = u.searchParams.get('bbsId'), trgetId = u.searchParams.get('trgetId');
          if (bbsId && trgetId && !out[m[1]]) out[m[1]] = { bbsId: bbsId, trgetId: trgetId };
        } catch (e) {}
      }
      return out;
    }
    async function nwGet(p) {
      const r = await fetch(FOLIO_BASE + p, { credentials: 'include' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      if (r.url && r.url.indexOf(FOLIO_BASE) !== 0) throw new Error('LOGIN');
      return { html: await r.text(), url: r.url || '' };
    }
    async function nwDiscover(sel) {
      const home = await nwGet('/cop/cmy/index.do');
      const links = [], seenHref = {};
      const re = /<a[^>]+href="(\/cmy\/[^"?#]+\.do)[^"]*"[^>]*>([\s\S]*?)<\/a>/g;
      let m;
      while ((m = re.exec(home.html))) {
        if (seenHref[m[1]]) continue;
        const st = m[2].match(/class="st"[^>]*>([\s\S]*?)</);
        const name = nwUnesc((st ? st[1] : m[2].replace(/<[^>]*>/g, ''))).replace(/\s+/g, '');
        if (!name) continue;
        seenHref[m[1]] = 1;
        links.push({ href: m[1], name: name });
      }
      let pick = null;
      if (sel.mode === 'pick' && sel.pick) pick = links.filter((x) => x.href === sel.pick)[0] || null;
      else if (sel.mode === 'name') pick = links.filter((x) => x.name.indexOf(sel.key) > -1)[0] || null;
      if (!pick) pick = links[0] || null;

      let nav = {}, name = '', tid = '';
      const cm = home.html.match(/classId:\s*"(CMMNTY_\d+)"/);
      if (cm) tid = cm[1];
      if (pick) {
        name = pick.name.slice(0, 24);
        const cp = await nwGet(pick.href);
        nav = nwParseNav(cp.html);
        const t = (cp.url + ' ' + cp.html).match(/CMMNTY_\d+/);
        if (t) tid = t[0];
      }
      if (!nav.BBSA20 && !nav.BBSA50 && tid) {
        const hp = await nwGet('/cop/cmy/bbs/selectClassHome.do?trgetId=' + encodeURIComponent(tid) + '&isMenu=Y');
        nav = nwParseNav(hp.html);
      }
      if (!nav.BBSA20 && !nav.BBSA50) throw new Error('NOBOARD');
      return { name: name, story: nav.BBSA20 || null, share: nav.BBSA50 || null };
    }

    function loadDiscover() {
      const sel = { mode: cfg.classMode, key: cfg.classKey, pick: cfg.classPick };
      return new Promise((res) => {
        if (host === 'folio.itt.link') {
          nwDiscover(sel).then((d) => res({ ok: true, d: d }))
            .catch((e) => res({ ok: false, err: String((e && e.message) || e) }));
          return;
        }
        try {
          chrome.runtime.sendMessage({ t: 'discover', sel: sel }, (r) => {
            if (chrome.runtime.lastError || !r) res({ ok: false, err: '확장 프로그램 연결 실패' });
            else res(r);
          });
        } catch (e) { res({ ok: false, err: '확장 프로그램 연결 실패' }); }
      });
    }

    function loadBoard(b) {
      return new Promise((res) => {
        if (host === 'folio.itt.link') {
          pullBoard(location.origin, b).then((items) => res({ ok: true, items: items }))
            .catch((e) => res({ ok: false, err: String((e && e.message) || e) }));
          return;
        }
        try {
          chrome.runtime.sendMessage({ t: 'board', b: b }, (r) => {
            if (chrome.runtime.lastError || !r) res({ ok: false, err: '확장 프로그램 연결 실패' });
            else res(r);
          });
        } catch (e) { res({ ok: false, err: '확장 프로그램 연결 실패' }); }
      });
    }

    function imgSrc(it, im) {
      const u = im.u ? safeUrl(im.u) : null;
      if (u) return u;
      if (!im.id) return null;
      return FOLIO_ORIGIN + '/cmm/fms/FileDown.do?atchFileId=' + encodeURIComponent(im.id) +
        '&fileSn=' + encodeURIComponent(im.sn) + '&nttNo=' + encodeURIComponent(it.no);
    }

    const enc = encodeURIComponent;

    // 본문에 &lt;p&gt; 처럼 글자로 들어온 태그까지 모두 걷어낸다 (여러 겹이어도 반복해서)
    const plain = (v) => {
      let t = String(v || '');
      for (let i = 0; i < 4; i++) {
        const before = t;
        t = t.replace(/<\s*br\s*\/?>/gi, ' ').replace(/<\/(p|div|li|h[1-6]|tr)\s*>/gi, ' ').replace(/<\/?[a-z][^>]*>/gi, '');
        t = decode(t);
        if (t === before) break;
      }
      return t.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
    };

    // 이 게시물 하나를 바로 여는 주소 (톡톡클래스 자체 상세 이동 규칙: nttNo + ordrCode + ordrCodeDp)
    const postUrl = (b, it) => FOLIO_ORIGIN + '/cop/cmy/bbs/selectBoardList.do?bbsId=' + enc(b.bbsId) +
      '&trgetId=' + enc(b.trgetId) + '&nttNo=' + enc(it.no) +
      (it.ord ? '&ordrCode=' + enc(it.ord) + '&ordrCodeDp=' + enc(it.dp || '0') : '');

    const HUES = [239, 262, 292, 330, 12, 32, 160, 190, 212];
    const avatarBg = (t) => {
      let h = 0;
      for (let i = 0; i < t.length; i++) h = (h * 31 + t.charCodeAt(i)) >>> 0;
      const hue = HUES[h % HUES.length];
      return 'linear-gradient(135deg,hsl(' + hue + ',75%,62%),hsl(' + ((hue + 28) % 360) + ',72%,50%))';
    };

    function mkCard(b, it) {
      const url = postUrl(b, it);
      const row = mk('div', 'bd-item');
      row.title = '눌러서 이 게시물로 이동';
      const who = plain(it.who);
      const ttl = plain(it.title);
      const bodyTxt = plain(it.body).slice(0, 240);
      const shown = ttl || (bodyTxt ? bodyTxt.slice(0, 40) : '(제목 없음)');

      const head = mk('div', 'bd-head');
      const av = mk('span', 'bd-av', (who || '?').slice(0, 1));
      av.style.background = avatarBg(who || '?');
      const hx = mk('div', 'bd-hx');
      const t = mk('a', 'bd-t', shown);
      t.href = url;
      hx.appendChild(t);
      hx.appendChild(mk('div', 'bd-m', [who, it.date].filter(Boolean).join(' · ')));
      head.appendChild(av);
      head.appendChild(hx);
      row.appendChild(head);
      if (ttl && bodyTxt) row.appendChild(mk('div', 'bd-p', bodyTxt));

      if (it.links.length || it.files.length) {
        const chips = mk('div', 'bd-chips');
        it.links.forEach((l) => {
          const u = safeUrl(l);
          if (!u) return;
          const a = mk('a', 'bd-c l', '🔗 ' + hostOf(u));
          a.href = u; a.title = u;
          chips.appendChild(a);
        });
        it.files.forEach((f) => {
          const a = mk('a', 'bd-c f', '📎 ' + (f.n || '첨부파일'));
          a.href = FOLIO_ORIGIN + '/cmm/fms/FileDown.do?atchFileId=' + enc(f.id) +
            '&fileSn=' + enc(f.sn) + '&nttNo=' + enc(it.no);
          a.title = f.n || '';
          chips.appendChild(a);
        });
        row.appendChild(chips);
      }

      // 이미지는 처음엔 불러오지도, 보여주지도 않는다. 버튼을 눌러야 나타나고, 다시 누르면 가려진다.
      if (it.imgs && it.imgs.length) {
        const label = '🖼 이미지 보기 (' + it.imgs.length + ')';
        const btn = mk('button', 'bd-imgbtn', label);
        btn.type = 'button';
        const box = mk('div', 'bd-imgs');
        box.style.display = 'none';
        let built = false, shown2 = false;
        btn.onclick = () => {
          shown2 = !shown2;
          if (shown2 && !built) {
            built = true;
            it.imgs.forEach((im) => {
              const u = imgSrc(it, im);
              if (!u) return;
              const a = mk('a');
              a.href = u; a.target = '_blank'; a.rel = 'noopener';
              const img = document.createElement('img');
              img.alt = im.n || '';
              img.onerror = () => { a.textContent = '이미지를 불러오지 못했어요 · ' + (im.n || ''); };
              img.src = u;
              a.appendChild(img);
              box.appendChild(a);
            });
          }
          box.style.display = shown2 ? 'flex' : 'none';
          btn.textContent = shown2 ? '가리기' : label;
          btn.classList.toggle('on', shown2);
        };
        row.appendChild(btn);
        row.appendChild(box);
      }

      row.appendChild(mk('div', 'bd-go', '이 게시물로 이동 ›'));
      row.addEventListener('click', (e) => {
        if (e.target.closest && e.target.closest('a,button,img')) return;
        if (e.ctrlKey || e.metaKey) window.open(url, '_blank');
        else location.href = url;
      });
      row._t = (shown + ' ' + bodyTxt + ' ' + who).toLowerCase();
      return row;
    }

    function applyFilter(pane) {
      const inp = pane.querySelector('.bd-search');
      const q = ((inp && inp.value) || '').trim().toLowerCase();
      const cards = pane._cards || [];
      let n = 0;
      cards.forEach((c) => {
        const hit = !q || c._t.indexOf(q) > -1;
        c.style.display = hit ? '' : 'none';
        if (hit) n++;
      });
      if (pane._none) pane._none.style.display = (cards.length && !n) ? '' : 'none';
    }

    // 저장된 주소가 있으면 쓰고, 없거나 오래됐으면 톡톡클래스에서 알아서 찾아온다.
    async function ensureBoard(kind, force) {
      const K = BOARD_KIND[kind];
      const saved = jget(K.key, null);
      const has = !!(saved && saved.bbsId && saved.trgetId);
      if (has && !force && now() - (saved.ts || 0) < 12 * 3600 * 1000) return { ok: true, b: saved, fresh: false };
      const r = await loadDiscover();
      if (!r.ok) return has ? { ok: true, b: saved, fresh: false } : r;
      Object.keys(BOARD_KIND).forEach((k) => {
        const x = r.d[k];
        if (x) jset(BOARD_KIND[k].key, { bbsId: x.bbsId, trgetId: x.trgetId, name: r.d.name, ts: now() });
      });
      const x = r.d[kind];
      if (!x) return { ok: false, err: 'NOBOARD' };
      return { ok: true, b: { bbsId: x.bbsId, trgetId: x.trgetId, name: r.d.name, ts: now() }, fresh: true };
    }

    async function fillBoard(w, kind) {
      const K = BOARD_KIND[kind];
      const pane = w.querySelector('.w-pane[data-t="' + kind + '"]');
      if (!pane) return;
      const body = pane.querySelector('.bd-grid'), sub = pane.querySelector('.bd-sub');
      const inp = pane.querySelector('.bd-search');
      if (inp && !inp._bound) { inp._bound = 1; inp.addEventListener('input', () => applyFilter(pane)); }
      const tok = (w._tok = (w._tok || 0) + 1);
      const gone = () => !w.isConnected || w._tok !== tok;
      const msg = (t, btn) => {
        body.textContent = '';
        const d = mk('div', 'bd-msg', t);
        if (btn) {
          d.appendChild(document.createElement('br'));
          const bt = mk('button', 'nw-sbtn', btn.label);
          bt.type = 'button';
          bt.onclick = btn.fn;
          d.appendChild(bt);
        }
        body.appendChild(d);
      };
      const skeleton = () => {
        body.textContent = '';
        for (let i = 0; i < 6; i++) body.appendChild(mk('div', 'bd-sk'));
      };
      const retry = { label: '다시 시도', fn: () => fillBoard(w, kind) };

      pane._cards = [];
      pane._none = null;
      sub.textContent = K.label + ' · 주소 찾는 중...';
      skeleton();

      let g = await ensureBoard(kind, false);
      if (gone()) return;
      if (!g.ok) {
        sub.textContent = '';
        if (g.err === 'LOGIN') msg('로그인이 필요해요. 로그인한 뒤 다시 열어 주세요.', retry);
        else if (g.err === 'NOBOARD') msg(K.label + ' 주소를 찾지 못했어요. 톡톡클래스 내 반에 한 번 들어갔다 오면 해결돼요.', {
          label: '내 반으로 가기',
          fn: () => { GM_setValue('forceEnter', now()); setTimeout(() => { location.href = FOLIO_MAIN; }, 30); }
        });
        else msg('주소를 찾지 못했어요 (' + g.err + ')', retry);
        return;
      }

      let b = g.b;
      sub.textContent = (b.name || '') + ' · ' + K.label + ' · 불러오는 중...';
      let r = await loadBoard(b);
      if (gone()) return;

      // 저장해 둔 주소가 낡았을 수 있으니, 실패하거나 비어 있으면 한 번 더 새로 찾아본다.
      if (!g.fresh && ((!r.ok && r.err !== 'LOGIN') || (r.ok && !r.items.length))) {
        const g2 = await ensureBoard(kind, true);
        if (gone()) return;
        if (g2.ok && g2.fresh) {
          b = g2.b;
          r = await loadBoard(b);
          if (gone()) return;
        }
      }

      if (!r.ok) {
        sub.textContent = '';
        msg(r.err === 'LOGIN' ? '로그인이 필요해요. 로그인한 뒤 다시 열어 주세요.' : '불러오지 못했어요 (' + r.err + ')', retry);
        return;
      }
      if (!r.items.length) { sub.textContent = (b.name || '') + ' · ' + K.label; msg(K.label + '에 올라온 게시물이 없어요.'); return; }

      body.textContent = '';
      body.scrollTop = 0;
      sub.textContent = (b.name || '') + ' · ' + K.label + ' · ' + Math.min(r.items.length, BOARD_MAX) + '개';
      const cards = r.items.slice(0, BOARD_MAX).map((it) => mkCard(b, it));
      cards.forEach((c) => body.appendChild(c));
      pane._cards = cards;
      pane._none = mk('div', 'bd-msg', '찾는 게시물이 없어요');
      pane._none.style.display = 'none';
      body.appendChild(pane._none);
      applyFilter(pane);
    }

    // ===== "업데이트 됐어요!" 안내 (코드를 고칠 때마다 UPDATE_SIGNAL 값을 새로 바꾼다) =====
    const APP_VERSION = '11.1';
    const UPDATE_SIGNAL = 'upd-20261012-7qk3';
    const UPDATE_NOTES = [
      '화면이 더 예뻐졌어요',
      '게시물 글에 붙던 <p> 같은 글자를 없앴어요',
      '게시물을 누르면 그 게시물 주소로 바로 가요',
      '이야기방·게시물방 주소를 알아서 찾아와요'
    ];
    const UPD_ROOT = '#__nw_upd__{position:fixed;top:0;right:0;bottom:0;left:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;' +
      'background:rgba(15,23,42,.5);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);animation:nwFade .25s ease-out;margin:0;padding:0;font-size:13px;line-height:1.45;color:#1e293b}' +
      '@keyframes nwFade{0%{opacity:0}100%{opacity:1}}@keyframes nwPop{0%{opacity:0;transform:translateY(12px) scale(.97)}100%{opacity:1;transform:none}}' +
      '@keyframes nwBounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}';
    const UPD_RAW = `
*{box-sizing:border-box;margin:0;padding:0;font-family:'Galmuri11','Malgun Gothic','Apple SD Gothic Neo',sans-serif!important}
.u-card{width:360px;max-width:calc(100vw - 32px);padding:26px 24px 20px;border-radius:22px;background:#fff;text-align:center;border:1px solid rgba(99,102,241,.3);
  box-shadow:0 30px 70px -18px rgba(49,46,129,.6);animation:nwPop .3s ease-out}
.u-emoji{font-size:44px;line-height:1;display:inline-block;animation:nwBounce 1.2s ease-in-out infinite}
.u-ttl{margin-top:10px;font-size:22px;font-weight:700;color:#4338ca}
.u-ver{display:inline-block;margin-top:8px;padding:3px 12px;border-radius:12px;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;font-size:11px;font-weight:700}
.u-list{list-style:none;margin:16px 0 0;text-align:left;display:flex;flex-direction:column;gap:7px}
.u-list li{padding:8px 12px;border-radius:11px;background:#f5f6fd;color:#334155;font-size:12px;word-break:keep-all}
.u-list li::before{content:'✨ '}
.u-sig{margin-top:14px;font-size:10px;color:#94a3b8;word-break:break-all}
.u-ok{margin-top:14px;width:100%;padding:11px;border:none;border-radius:13px;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 10px 20px -8px rgba(79,70,229,.7)}
.u-ok:hover{filter:brightness(1.08)}`;

    function closeUpd() {
      GM_setValue('seenUpdate', UPDATE_SIGNAL);
      const o = document.getElementById('__nw_upd__');
      if (!o) return;
      o.style.transition = 'opacity .25s';
      o.style.opacity = '0';
      setTimeout(() => o.remove(), 260);
    }

    function showUpdateNotice() {
      if (GM_getValue('seenUpdate', '') === UPDATE_SIGNAL) return;
      whenRoot(() => {
        if (document.getElementById('__nw_upd__')) return;
        const o = document.createElement('div');
        o.id = '__nw_upd__';
        o.innerHTML = '<style>' + fontCss() + UPD_ROOT + scopeCss(UPD_RAW, '#__nw_upd__') + '</style>' +
          '<div class="u-card"><div class="u-emoji">🎉</div><div class="u-ttl">업데이트 됐어요!</div>' +
          '<div class="u-ver"></div><ul class="u-list"></ul><div class="u-sig"></div>' +
          '<button type="button" class="u-ok">확인</button></div>';
        o.querySelector('.u-ver').textContent = '자동 로그인 v' + APP_VERSION;
        o.querySelector('.u-sig').textContent = '업데이트 신호값 · ' + UPDATE_SIGNAL;
        const ul = o.querySelector('.u-list');
        UPDATE_NOTES.forEach((n) => { const li = document.createElement('li'); li.textContent = n; ul.appendChild(li); });
        o.querySelector('.u-ok').onclick = closeUpd;
        o.addEventListener('mousedown', (e) => { if (e.target === o) closeUpd(); });
        document.documentElement.appendChild(o);
        setTimeout(() => { if (document.getElementById('__nw_upd__') && document.visibilityState === 'visible') closeUpd(); }, 12000);
      });
    }

    (function boot() {
      if (!cfg.showUi || dismissed()) return;
      const u = jget('ui', null);
      if (!u || !u.t) return;
      const flowHost = FLOW_HOSTS.indexOf(host) > -1;
      if (u.st === 'working') {
        const left = LIVE_KEEP - (now() - u.ts);
        if (left > 0) {
          renderState(u);
          if (!flowHost) setTimeout(() => { if (!manualOpen) removeWin(true); }, left);
        }
        return;
      }
      if (u.st === 'done' && u.closeAt && now() < u.closeAt) renderState(u);
    })();

    const needUi = !hasCreds() && (FLOW_HOSTS.indexOf(host) > -1 || !dismissed());
    if (needUi) {
      showNeed();
    } else if (host === 'auth.worksmobile.com') {
      if (cfg.enabled) runLogin();
    } else if (host === 'newtab.itt.link') {
      runNewtab();
    } else if (host === 'folio.itt.link') {
      runFolio();
    } else {
      runOther();
    }

    window.addEventListener('resize', () => clampWin(document.getElementById('__nw_win__')));
    showUpdateNotice();

    if (host === 'folio.itt.link') {
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', learnBoardIds, { once: true });
      else learnBoardIds();
    }

    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (document.getElementById('__nw_upd__')) { closeUpd(); return; }
        if (document.getElementById('__nw_win__')) closeByUser();
        return;
      }
      if ((e.ctrlKey || e.altKey) && !e.shiftKey && (e.code === 'Digit2' || e.key === '2')) {
        e.preventDefault();
        e.stopPropagation();
        toggleWin('share');
        return;
      }
      if ((e.ctrlKey || e.altKey) && !e.shiftKey && (e.code === 'Digit1' || e.key === '1')) {
        e.preventDefault();
        e.stopPropagation();
        toggleWin('set');
      }
    }, true);

    try {
      chrome.runtime.onMessage.addListener((m) => {
        if (m && m.t === 'toggle') toggleWin('set');
        if (m && m.t === 'board-toggle') toggleWin('share');
      });
    } catch (e) {}
  }

  try {
    chrome.storage.local.get(null, (data) => {
      Object.assign(cache, data || {});
      main();
    });
  } catch (e) {
    main();
  }
})();
