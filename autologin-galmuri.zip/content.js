(function () {
  'use strict';

  const cache = {};

  function GM_getValue(k, d) {
    return Object.prototype.hasOwnProperty.call(cache, k) ? cache[k] : d;
  }
  function GM_setValue(k, v) {
    cache[k] = v;
    try { chrome.storage.local.set({ [k]: v }); } catch (e) {}
  }

  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area !== 'local') return;
      for (const k in ch) {
        if (ch[k].newValue === undefined) delete cache[k]; else cache[k] = ch[k].newValue;
      }
      try { if (self.NWLab) self.NWLab.sync(); } catch (e) {}
    });
  } catch (e) {}

  function main() {
    const DEFAULT_CLASS = '6학년2반';
    const FOLIO_MAIN = 'https://folio.itt.link/cop/cmy/index.do';
    const FLOW_HOSTS = ['auth.worksmobile.com', 'newtab.itt.link', 'folio.itt.link'];
    const LIVE_KEEP = 30000;

    const host = location.hostname;
    const path = location.pathname.replace(/;.*$/, '');
    const now = () => Date.now();

    const isFolioHome = host === 'folio.itt.link' &&
      /^\/(index\.do|main\.do|cop\/cmy\/(index|main)\.do)?$/.test(path);
    const isClassPage = host === 'folio.itt.link' && /^\/cmy\/[^\/]+\.do$/.test(path);

    const jget = (k, d) => {
      try { const v = GM_getValue(k, ''); return v ? JSON.parse(v) : d; } catch (e) { return d; }
    };
    const jset = (k, v) => GM_setValue(k, JSON.stringify(v));

    const cfg = {
      get id() { return GM_getValue('id', ''); },
      get pw() { return GM_getValue('pw', ''); },
      get enabled() { return GM_getValue('enabled', true); },
      get showUi() { return GM_getValue('showUi', true); },
      get fsOn() { return GM_getValue('fsOn', true); },
      get showAll() { return GM_getValue('showAll', true); },
      get doneSec() {
        const n = parseInt(GM_getValue('doneSec', 3), 10);
        return isNaN(n) ? 3 : Math.min(30, Math.max(1, n));
      },
      get dest() {
        const d = GM_getValue('dest', 'auto');
        return (d === 'classroom' || d === 'class') ? 'auto' : d;
      },
      get custom() { return GM_getValue('customUrl', ''); },
      get classMode() { return GM_getValue('classMode', 'name'); },
      get classKey() { return (GM_getValue('classKey', '') || DEFAULT_CLASS).replace(/\s+/g, ''); },
      get classPick() { return GM_getValue('classPick', ''); }
    };

    const hasCreds = () => !!(cfg.id && cfg.pw);

    function destUrl() {
      const d = cfg.dest;
      if (d === 'auto' || d === 'folio') return FOLIO_MAIN;
      if (d === 'custom' && cfg.custom) return cfg.custom;
      return null;
    }


    // ======================= 통합 창 (공유방 · 과제방 · 이야기방 · 실험실 · 설정) =======================
    const ROOT_ID = '__nw_root__';
    const TABS = [
      { id: 'share', label: '공유방' },
      { id: 'task', label: '과제방' },
      { id: 'story', label: '이야기방' },
      { id: 'lab', label: '실험실' },
      { id: 'set', label: '설정' }
    ];
    const TAB_IDS = TABS.map((t) => t.id);

    const whaleUrl = () => { try { return chrome.runtime.getURL('icons/whale.png'); } catch (e) { return ''; } };
    function fontCss() {
      let u = '';
      try { u = chrome.runtime.getURL('font.woff2'); } catch (e) {}
      return u ? "@font-face{font-family:'Galmuri9';src:url('" + u + "') format('woff2');font-display:block}" : '';
    }
    function ensureFont() {
      if (document.getElementById('__nw_font__') || !document.documentElement) return;
      const s = document.createElement('style');
      s.id = '__nw_font__';
      s.textContent = fontCss();
      document.documentElement.appendChild(s);
    }

    const UI_CSS = `
:host{all:initial}
*{box-sizing:border-box;margin:0;padding:0;font-family:'Galmuri9','Malgun Gothic','Apple SD Gothic Neo',sans-serif}
button,input,select,textarea{font-family:inherit}
.win{position:fixed;left:0;top:0;width:380px;height:500px;min-width:300px;min-height:280px;max-width:96vw;max-height:96vh;background:#fff;color:#1e293b;border:1px solid #cbd5e1;border-radius:14px;box-shadow:0 8px 30px rgba(15,23,42,.3);display:none;flex-direction:column;overflow:hidden;resize:both;font-size:13px;line-height:1.4;text-align:left}
.hd{display:flex;align-items:center;gap:7px;padding:7px 8px 7px 12px;background:#0f172a;color:#fff;cursor:move;user-select:none;flex:none;touch-action:none}
.hd-t{flex:1;font-size:13px;font-weight:700;letter-spacing:.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dot{width:9px;height:9px;border-radius:50%;background:#64748b;flex:none}
.dot[data-st=working]{background:#3b82f6;animation:nwp 1s infinite}
.dot[data-st=done]{background:#22c55e}
.dot[data-st=error]{background:#ef4444}
.dot[data-st=need]{background:#f59e0b}
@keyframes nwp{50%{opacity:.35}}
.ib{width:24px;height:24px;border:none;border-radius:6px;background:rgba(255,255,255,.14);color:#fff;font-size:15px;line-height:1;cursor:pointer;flex:none}
.ib:hover{background:rgba(255,255,255,.3)}
.st{display:none;align-items:flex-start;gap:8px;padding:8px 12px;border-bottom:1px solid #e2e8f0;background:#f8fafc;flex:none}
.st[data-st=working]{background:#eff6ff}
.st[data-st=done]{background:#f0fdf4}
.st[data-st=error]{background:#fef2f2}
.st[data-st=need]{background:#fffbeb}
.chip{flex:none;padding:2px 9px;border-radius:12px;background:#94a3b8;color:#fff;font-size:11px;font-weight:700;margin-top:1px}
.st[data-st=working] .chip{background:#2563eb}
.st[data-st=done] .chip{background:#22c55e}
.st[data-st=error] .chip{background:#ef4444}
.st[data-st=need] .chip{background:#f59e0b}
.st-x{flex:1;min-width:0}
.st-t{font-size:13px;font-weight:700;color:#1e293b;word-break:keep-all}
.st-s{font-size:11px;color:#475569;margin-top:2px;line-height:1.45;word-break:keep-all}
.st-time{font-size:10px;color:#94a3b8;margin-top:2px}
.tabs{display:flex;gap:4px;padding:7px 8px;border-bottom:1px solid #f1f5f9;flex:none;overflow-x:auto;scrollbar-width:none}
.tab{flex:none;padding:4px 11px;font-size:12px;border:1px solid #e2e8f0;border-radius:7px;background:#fff;color:#64748b;cursor:pointer;white-space:nowrap}
.tab:hover{border-color:#94a3b8}
.tab.on{background:#0f172a;color:#fff;border-color:#0f172a}
.tab.dragging{opacity:.4}
.tab.over{outline:2px dashed #2563eb;outline-offset:1px}
.panes{flex:1;min-height:0;position:relative}
.pane{display:none;position:absolute;inset:0;flex-direction:column;min-height:0}
.pane.on{display:flex}
.tb{display:flex;align-items:center;gap:6px;padding:6px 10px;border-bottom:1px solid #f1f5f9;flex:none}
.tb .sub{flex:1;min-width:0;font-size:11px;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sbtn{flex:none;padding:4px 10px;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc;color:#334155;font-size:12px;font-weight:700;cursor:pointer;white-space:nowrap}
.sbtn:hover{background:#eff6ff;border-color:#2563eb}
.sbtn.main{background:#2563eb;border-color:#2563eb;color:#fff}
.sbtn.main:hover{background:#1d4ed8}
.sbtn.on{background:#2563eb;border-color:#2563eb;color:#fff}
.col{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;overscroll-behavior:contain;scrollbar-width:thin;display:flex;flex-direction:column}
.bd-msg{margin:auto;padding:16px;text-align:center;color:#475569;font-size:12px;line-height:1.6;word-break:keep-all}
.bd-msg .sbtn{margin-top:8px}
.bd-b{padding:4px 10px;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc;color:#334155;font-size:12px;font-weight:700;cursor:pointer}
.bd-b:hover{background:#eff6ff;border-color:#2563eb}

/* 공유방 */
.bd-item{flex:none;margin:8px 10px 0;padding:8px 12px;border:1px solid #e2e8f0;border-radius:12px;background:#f8fafc}
.bd-item:last-child{margin-bottom:10px}
.bd-item:hover{border-color:#93c5fd;background:#f1f7ff}
.bd-t{display:block;font-size:13px;font-weight:700;color:#1e293b;text-decoration:none;word-break:break-all;line-height:1.4}
.bd-t:hover{color:#2563eb;text-decoration:underline}
.bd-m{font-size:11px;color:#94a3b8;margin-top:3px}
.bd-chips{display:flex;flex-wrap:wrap;gap:5px;margin-top:6px}
.bd-c{display:inline-block;max-width:100%;padding:3px 9px;border-radius:12px;font-size:11px;text-decoration:none;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bd-c.l{background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe}
.bd-c.f{background:#f0fdf4;color:#15803d;border:1px solid #bbf7d0}
.bd-c:hover{filter:brightness(.93)}

/* 이야기방 */
.sx-item{flex:none;padding:14px 14px 16px;border-bottom:8px solid #f1f5f9}
.sx-who{display:flex;align-items:baseline;justify-content:space-between;gap:8px}
.sx-name{font-size:14px;font-weight:700;color:#1e293b}
.sx-date{font-size:11px;color:#94a3b8;flex:none}
.sx-txt{margin-top:8px;font-size:13px;line-height:1.6;color:#334155;white-space:pre-wrap;word-break:break-all}
.sx-imgs{display:flex;flex-direction:column;gap:10px;margin-top:10px}
.sx-img{display:block;width:100%;background:#f1f5f9;border-radius:10px;overflow:hidden;line-height:0;text-align:center}
.sx-img img{max-width:100%;max-height:420px;width:auto;height:auto;object-fit:contain;cursor:zoom-in}
.sx-more{font-size:12px;color:#64748b;text-align:center;padding:2px}
.sx-btn{flex:none;padding:3px 10px;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc;color:#334155;font-size:11px;font-weight:700;cursor:pointer}
.sx-btn:hover{background:#eff6ff;border-color:#2563eb}
.sx-btn.on{background:#2563eb;border-color:#2563eb;color:#fff}
.sx-open{display:inline-block;margin-top:10px;font-size:12px;color:#2563eb;text-decoration:none}
.sx-open:hover{text-decoration:underline}

/* 과제방 */
.tk-item{flex:none;display:block;margin:8px 10px 0;padding:10px 12px;border:1px solid #e2e8f0;border-left:6px solid #94a3b8;border-radius:12px;background:#f8fafc;text-decoration:none;color:inherit}
.tk-item:last-child{margin-bottom:10px}
.tk-item:hover{background:#f1f7ff;border-color:#93c5fd}
.tk-item.open{border-left-color:#2563eb}
.tk-item.redy{border-left-color:#f59e0b}
.tk-top{display:flex;align-items:center;gap:8px}
.tk-chip{flex:none;padding:2px 9px;border-radius:12px;font-size:11px;font-weight:700;color:#fff;background:#94a3b8}
.open .tk-chip{background:#2563eb}
.redy .tk-chip{background:#f59e0b}
.tk-t{font-size:13px;font-weight:700;color:#1e293b;line-height:1.35;word-break:break-all}
.tk-s{margin-top:5px;font-size:11px;color:#64748b;line-height:1.5;word-break:keep-all}
.tk-row{margin-top:5px;display:flex;flex-wrap:wrap;gap:6px;align-items:center;font-size:11px;color:#334155}
.tk-st{padding:2px 8px;border-radius:8px;background:#e2e8f0;color:#334155;font-weight:700}
.tk-st.ok{background:#dcfce7;color:#15803d}
.tk-st.warn{background:#fee2e2;color:#b91c1c}

/* 설정 */
.stabs{display:flex;gap:4px;padding:6px 10px;flex:none;overflow-x:auto;scrollbar-width:none}
.stab{flex:none;padding:3px 10px;font-size:12px;border:1px solid #e2e8f0;border-radius:6px;background:#fff;color:#64748b;cursor:pointer}
.stab.on{background:#4338ca;color:#fff;border-color:#4338ca}
.sbody{flex:1;min-height:0;overflow-y:auto;padding:2px 12px 8px}
.spane{display:none}
.spane.on{display:block}
.nw-row{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:7px 2px;border-bottom:1px solid #f1f5f9;font-size:12px;color:#334155;cursor:pointer}
.nw-row.col1{flex-direction:column;align-items:stretch;cursor:default;gap:3px}
.nw-row.rad{justify-content:flex-start}
.nw-row input[type=checkbox],.nw-row input[type=radio]{width:16px;height:16px;accent-color:#2563eb;flex:none;cursor:pointer}
.nw-lb{font-size:11px;color:#64748b}
.nw-in{width:100%;padding:6px 8px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;background:#fff;color:#1e293b;outline:none;min-width:0}
.nw-in:focus{border-color:#2563eb}
.nw-in.num{width:64px;text-align:right}
.nw-two{display:flex;gap:6px;align-items:center}
.sfoot{display:flex;justify-content:flex-end;align-items:center;gap:6px;padding:8px 12px;border-top:1px solid #f1f5f9;flex:none}
.nw-saved{color:#16a34a;font-weight:700;font-size:12px;margin-right:auto}
.nw-ibox{border-radius:12px;border:1px solid #e2e8f0;background:#f8fafc;padding:9px 12px;display:flex;flex-direction:column;gap:5px;margin-top:8px}
.nw-ih{font-size:12px;font-weight:700;color:#4338ca}
.nw-k{font-size:10px;color:#64748b;margin-top:2px}
.nw-v{font-size:12px;font-weight:700;color:#1e293b;word-break:break-all;line-height:1.35}
.keys{margin-top:8px;font-size:11px;color:#475569;line-height:1.8}
.keys b{color:#1e293b}

/* 작게 줄였을 때 왼쪽 하얀 바 */
.bar{position:fixed;left:0;top:12vh;height:76vh;width:42px;background:#fff;border:1px solid #e2e8f0;border-left:none;border-radius:0 14px 14px 0;box-shadow:3px 0 16px rgba(15,23,42,.22);display:none;flex-direction:column;align-items:center;justify-content:space-between;padding:14px 0 12px;cursor:pointer;user-select:none;outline:none;transition:width .12s}
.bar:hover,.bar:focus-visible{width:48px;background:#f8fafc}
.bar-t{writing-mode:vertical-rl;font-size:15px;font-weight:700;letter-spacing:6px;color:#0f172a;margin-top:6px}
.bar img{width:30px;height:30px;border-radius:50%;display:block;flex:none}
.bar-dot{position:absolute;top:6px;left:50%;margin-left:-4px;width:8px;height:8px;border-radius:50%;background:transparent}
.bar-dot[data-st=working]{background:#3b82f6;animation:nwp 1s infinite}
.bar-dot[data-st=error]{background:#ef4444}
.bar-dot[data-st=need]{background:#f59e0b}
.bar-dot[data-st=done]{background:#22c55e}

/* 업데이트 안내 */
.modal{position:fixed;inset:0;background:rgba(15,23,42,.55);display:none;align-items:center;justify-content:center;padding:12px}
.mcard{width:min(400px,100%);background:#fff;border-radius:16px;padding:20px;box-shadow:0 10px 30px rgba(0,0,0,.35);font-size:13px;color:#1e293b}
.mtitle{font-size:19px;font-weight:700}
.mcard ul{margin:10px 0 0 18px;font-size:13px;color:#334155;line-height:1.7}
.msig{margin-top:10px;font-size:11px;color:#94a3b8;word-break:break-all}
.mok{margin-top:14px;width:100%;padding:10px;border:none;border-radius:8px;background:#2563eb;color:#fff;font-size:14px;font-weight:700;cursor:pointer}
.mok:hover{background:#1d4ed8}
` + (self.NWLab ? self.NWLab.css : '');

    const UI_HTML = `
<style>${'__CSS__'}</style>
<div class="win" id="win">
  <div class="hd" id="hd">
    <span class="dot" id="dot" data-st="idle"></span>
    <span class="hd-t">네이버 웨일 툴</span>
    <button type="button" class="ib" id="b-min" title="작게 줄이기 (Ctrl+1)">−</button>
    <button type="button" class="ib" id="b-hide" title="숨기기 (Ctrl+1로 다시 열기)">×</button>
  </div>
  <div class="st" id="st" data-st="idle">
    <span class="chip" id="chip">대기 중</span>
    <div class="st-x"><div class="st-t" id="st-t"></div><div class="st-s" id="st-s"></div><div class="st-time" id="st-time"></div></div>
    <button type="button" class="sbtn" id="retry" style="display:none">다시 시도</button>
  </div>
  <div class="tabs" id="tabs"></div>
  <div class="panes">
    <div class="pane" data-p="share">
      <div class="tb"><div class="sub" id="sub-share"></div><button type="button" class="sbtn" data-r="share">새로고침</button></div>
      <div class="col" id="body-share"></div>
    </div>
    <div class="pane" data-p="task">
      <div class="tb"><div class="sub" id="sub-task"></div><button type="button" class="sbtn" data-r="task">새로고침</button></div>
      <div class="col" id="body-task"></div>
    </div>
    <div class="pane" data-p="story">
      <div class="tb"><div class="sub" id="sub-story"></div><button type="button" class="sbtn" id="simg">이미지도 보기</button><button type="button" class="sbtn" data-r="story">새로고침</button></div>
      <div class="col" id="body-story"></div>
    </div>
    <div class="pane" data-p="lab" id="lab-box"></div>
    <div class="pane" data-p="set">
      <div class="stabs">
        <button type="button" class="stab on" data-s="acc">계정</button>
        <button type="button" class="stab" data-s="act">동작</button>
        <button type="button" class="stab" data-s="dst">이동</button>
        <button type="button" class="stab" data-s="cls">반</button>
        <button type="button" class="stab" data-s="info">정보</button>
      </div>
      <div class="sbody">
        <div class="spane on" data-s="acc">
          <div class="nw-row col1"><span class="nw-lb">아이디</span><input class="nw-in" id="s-id" type="text" autocomplete="off"></div>
          <div class="nw-row col1"><span class="nw-lb">비밀번호</span><div class="nw-two"><input class="nw-in" id="s-pw" type="password" autocomplete="new-password"><button type="button" class="sbtn" id="s-pwshow">보이기</button></div></div>
        </div>
        <div class="spane" data-s="act">
          <label class="nw-row"><span>자동 로그인 사용</span><input type="checkbox" id="s-en"></label>
          <label class="nw-row"><span>로그인 진행 상태 보여주기</span><input type="checkbox" id="s-ui"></label>
          <label class="nw-row"><span>사이트에 들어가면 전체화면 (F11)</span><input type="checkbox" id="s-fs"></label>
          <label class="nw-row"><span>모든 사이트에서 이 도구 보이기</span><input type="checkbox" id="s-all"></label>
          <div class="nw-row"><span>로그인 끝나면 작게 줄이기 (초)</span><input class="nw-in num" id="s-ds" type="number" min="1" max="30"></div>
        </div>
        <div class="spane" data-s="dst">
          <label class="nw-row rad"><input type="radio" name="nwd" value="auto"><span>내 반으로 바로 들어가기</span></label>
          <label class="nw-row rad"><input type="radio" name="nwd" value="folio"><span>톡톡클래스 메인</span></label>
          <label class="nw-row rad"><input type="radio" name="nwd" value="stay"><span>이동 안 함</span></label>
          <label class="nw-row rad"><input type="radio" name="nwd" value="custom"><span>직접 입력</span></label>
          <div class="nw-row col1"><input class="nw-in" id="s-url" type="text" placeholder="https://..."></div>
        </div>
        <div class="spane" data-s="cls">
          <label class="nw-row rad"><input type="radio" name="nwc" value="name"><span>이름으로 찾기</span></label>
          <div class="nw-row col1"><input class="nw-in" id="s-ck" type="text" placeholder="예: 6학년2반"></div>
          <label class="nw-row rad"><input type="radio" name="nwc" value="pick"><span>목록에서 고르기</span></label>
          <div class="nw-row col1"><div class="nw-two"><select class="nw-in" id="s-cp"></select><button type="button" class="sbtn" id="s-reload">불러오기</button></div></div>
          <label class="nw-row rad"><input type="radio" name="nwc" value="top"><span>올해 맨 위 반</span></label>
        </div>
        <div class="spane" data-s="info">
          <div class="nw-ibox">
            <div class="nw-ih">현재 사이트</div>
            <div><div class="nw-k">사이트</div><div class="nw-v" id="i-site-n"></div></div>
            <div><div class="nw-k">주소</div><div class="nw-v" id="i-site-u" style="font-size:11px;font-weight:400"></div></div>
            <div><div class="nw-k">로그인 후 이동</div><div class="nw-v" id="i-site-d"></div></div>
          </div>
          <div class="nw-ibox">
            <div class="nw-ih">내 계정</div>
            <div><div class="nw-k">이메일</div><div class="nw-v" id="i-id"></div></div>
            <div><div class="nw-k">비밀번호</div><div class="nw-v" id="i-pw"></div></div>
            <div><div class="nw-k">들어갈 반</div><div class="nw-v" id="i-c"></div></div>
          </div>
          <div class="keys"><b>Ctrl+1</b> 또는 <b>Alt+1</b> 열기 / 작게 줄이기<br><b>Ctrl+2</b> 또는 <b>Alt+2</b> 다음 탭으로<br><b>Esc</b> (창 안에서) 작게 줄이기<br>탭은 끌어서 순서를 바꿀 수 있어요</div>
        </div>
      </div>
      <div class="sfoot">
        <span class="nw-saved" id="s-saved"></span>
        <button type="button" class="sbtn" id="s-go">지금 내 반으로</button>
        <button type="button" class="sbtn main" id="s-save">저장</button>
      </div>
    </div>
  </div>
</div>
<div class="bar" id="bar" role="button" tabindex="0" title="눌러서 열기">
  <span class="bar-dot" id="bar-dot" data-st="idle"></span>
  <span class="bar-t">네이버 웨일 툴</span>
  <img id="bar-img" alt="">
</div>
<div class="modal" id="modal">
  <div class="mcard">
    <div class="mtitle">업데이트 됐어요!</div>
    <ul id="m-ul"></ul>
    <div class="msig" id="m-sig"></div>
    <button type="button" class="mok" id="m-ok">확인</button>
  </div>
</div>`;

    let ui = null;                       // { host, sh, loaded:{}, labBox }
    let forceShown = false;              // 단축키·아이콘으로 직접 켠 경우
    let curState = null, closeTimer = null, tickTimer = null, manualOpen = false, pwShown = false, pwTimer = null;
    const IDLE = { t: '대기 중', s: '', st: 'idle', ts: 0 };

    const getMode = () => { const m = GM_getValue('uiMode', 'open'); return (m === 'min' || m === 'hide') ? m : 'open'; };
    const isHtmlDoc = () => !document.contentType || /html/i.test(document.contentType);
    const flowHost = () => FLOW_HOSTS.indexOf(host) > -1;
    const uiOK = () => isHtmlDoc() && (cfg.showAll || flowHost() || forceShown);

    function whenRoot(fn, n) {
      n = n || 0;
      if (document.documentElement) { fn(); return; }
      if (n < 400) setTimeout(() => whenRoot(fn, n + 1), 5);
    }

    const DEST_LABEL = {
      auto: '내 반으로 바로 들어가기',
      folio: '톡톡클래스 메인',
      stay: '이동 안 함',
      custom: '직접 입력한 주소'
    };

    function siteName() {
      if (host === 'auth.worksmobile.com') return 'NAVER WORKS 로그인';
      if (host === 'newtab.itt.link') return '아이톡톡 뉴탭';
      if (host === 'folio.itt.link') {
        if (isClassPage) return '톡톡클래스 (내 반)';
        if (isFolioHome) return '톡톡클래스 메인';
        return '톡톡클래스';
      }
      return host;
    }

    function classLabel() {
      const m = cfg.classMode;
      if (m === 'top') return '올해 맨 위 반';
      if (m === 'pick') {
        const e = jget('classMap', {})[cfg.classPick];
        return e ? (typeof e === 'string' ? e : e.n) : '(목록에서 고른 반)';
      }
      return cfg.classKey;
    }

    function updateInfo() {
      if (!ui) return;
      const set = (id, t) => { const e = ui.sh.getElementById(id); if (e) e.textContent = t; };
      set('i-id', cfg.id || '입력 필요');
      set('i-pw', cfg.pw ? (pwShown ? cfg.pw : '*'.repeat(cfg.pw.length)) : '입력 필요');
      set('i-c', classLabel());
      set('i-site-n', siteName());
      set('i-site-u', host + path);
      set('i-site-d', DEST_LABEL[cfg.dest] || cfg.dest);
    }

    // ---- 모드(열림 / 작게 / 숨김) ----
    function applyMode() {
      if (!ui) return;
      const m = getMode();
      ui.win.style.display = m === 'open' ? 'flex' : 'none';
      ui.bar.style.display = m === 'min' ? 'flex' : 'none';
      if (m === 'open') placeWin();
    }
    function setMode(m) { GM_setValue('uiMode', m); applyMode(); }

    function placeWin(x, y) {
      const win = ui.win;
      const sz = jget('uiSize', null);
      if (sz && sz.w && sz.h && !win.__sized) {
        win.style.width = Math.min(sz.w, innerWidth * 0.96) + 'px';
        win.style.height = Math.min(sz.h, innerHeight * 0.96) + 'px';
        win.__sized = true;
      }
      if (x == null) {
        const p = jget('uiPos', null);
        const w = win.offsetWidth || 380;
        x = p ? p.x : innerWidth - w - 16;
        y = p ? p.y : 16;
      }
      const w = win.offsetWidth || 380;
      win.style.left = Math.max(80 - w, Math.min(x, innerWidth - 80)) + 'px';
      win.style.top = Math.max(0, Math.min(y, innerHeight - 40)) + 'px';
    }

    function toggleUi() {
      forceShown = true;
      manualOpen = true;
      if (!ensureUi()) return;
      setMode(getMode() === 'open' ? 'min' : 'open');
    }

    // ---- 탭 ----
    function tabOrder() {
      const saved = jget('tabOrder', null);
      const o = Array.isArray(saved) ? saved.filter((x) => TAB_IDS.indexOf(x) > -1) : [];
      TAB_IDS.forEach((x) => { if (o.indexOf(x) < 0) o.push(x); });
      return o;
    }

    function renderTabs() {
      const box = ui.sh.getElementById('tabs');
      box.textContent = '';
      const cur = GM_getValue('uiTab', 'share');
      let dragId = null;
      tabOrder().forEach((id) => {
        const def = TABS.filter((t) => t.id === id)[0];
        const b = mk('button', 'tab' + (id === cur ? ' on' : ''), def.label);
        b.type = 'button';
        b.dataset.t = id;
        b.draggable = true;
        b.onclick = () => activate(id);
        b.addEventListener('dragstart', (e) => {
          dragId = id;
          b.classList.add('dragging');
          try { e.dataTransfer.setData('text/plain', id); e.dataTransfer.effectAllowed = 'move'; } catch (x) {}
        });
        b.addEventListener('dragend', () => {
          dragId = null;
          box.querySelectorAll('.tab').forEach((t) => t.classList.remove('dragging', 'over'));
        });
        b.addEventListener('dragover', (e) => { if (dragId && dragId !== id) { e.preventDefault(); b.classList.add('over'); } });
        b.addEventListener('dragleave', () => b.classList.remove('over'));
        b.addEventListener('drop', (e) => {
          e.preventDefault();
          if (!dragId || dragId === id) return;
          const o = tabOrder().filter((x) => x !== dragId);
          o.splice(o.indexOf(id), 0, dragId);
          jset('tabOrder', o);
          renderTabs();
        });
        box.appendChild(b);
      });
    }

    function activate(id) {
      if (!ui) return;
      if (TAB_IDS.indexOf(id) < 0) id = 'share';
      GM_setValue('uiTab', id);
      ui.sh.querySelectorAll('.tab').forEach((t) => t.classList.toggle('on', t.dataset.t === id));
      ui.sh.querySelectorAll('.pane').forEach((p) => p.classList.toggle('on', p.dataset.p === id));
      if ((id === 'share' || id === 'task' || id === 'story') && !ui.loaded[id]) fillList(id);
      if (id === 'lab' && !ui.labMounted && self.NWLab) {
        ui.labMounted = true;
        self.NWLab.mount(ui.sh.getElementById('lab-box'));
      }
      if (id === 'set') updateInfo();
    }

    function nextTab() {
      const o = tabOrder(), i = o.indexOf(GM_getValue('uiTab', 'share'));
      activate(o[(i + 1) % o.length]);
    }

    // ---- 설정 화면 ----
    function initSettings() {
      const sh = ui.sh;
      const q = (s) => sh.querySelector(s), all = (s) => sh.querySelectorAll(s);
      q('#s-id').value = cfg.id;
      q('#s-pw').value = cfg.pw;
      q('#s-en').checked = cfg.enabled;
      q('#s-ui').checked = cfg.showUi;
      q('#s-fs').checked = cfg.fsOn;
      q('#s-all').checked = cfg.showAll;
      q('#s-ds').value = cfg.doneSec;
      all('input[name="nwd"]').forEach((r) => { r.checked = r.value === cfg.dest; });
      q('#s-url').value = cfg.custom;
      all('input[name="nwc"]').forEach((r) => { r.checked = r.value === cfg.classMode; });
      q('#s-ck').value = GM_getValue('classKey', '') || DEFAULT_CLASS;

      all('.stab').forEach((t) => {
        t.onclick = () => {
          all('.stab').forEach((x) => x.classList.toggle('on', x === t));
          all('.spane').forEach((pn) => pn.classList.toggle('on', pn.dataset.s === t.dataset.s));
        };
      });

      const sel = q('#s-cp');
      const map = jget('classMap', {});
      const items = Object.keys(map).map((k) => {
        const e = map[k];
        return typeof e === 'string' ? { p: k, n: e, y: 0 } : { p: k, n: e.n, y: e.y || 0 };
      }).sort((a, b) => (b.y - a.y) || a.n.localeCompare(b.n));
      if (!items.length) {
        const o = document.createElement('option');
        o.value = '';
        o.textContent = '목록이 없어요. 옆 버튼으로 불러오세요';
        sel.appendChild(o);
      } else {
        items.forEach((i) => {
          const o = document.createElement('option');
          o.value = i.p;
          o.textContent = (i.y ? i.y + '년 ' : '') + i.n;
          if (i.p === cfg.classPick) o.selected = true;
          sel.appendChild(o);
        });
      }

      const pwIn = q('#s-pw'), pwBtn = q('#s-pwshow');
      const hidePw = () => {
        clearTimeout(pwTimer);
        pwShown = false;
        pwIn.type = 'password';
        pwBtn.textContent = '보이기';
        pwBtn.disabled = false;
        updateInfo();
      };
      pwBtn.onclick = () => {
        clearTimeout(pwTimer);
        pwShown = true;
        pwIn.type = 'text';
        pwBtn.textContent = '3초 후 가림';
        pwBtn.disabled = true;
        updateInfo();
        pwTimer = setTimeout(hidePw, 3000);
      };

      q('#s-reload').onclick = () => {
        GM_setValue('noEnter', now());
        setTimeout(() => { location.href = FOLIO_MAIN; }, 30);
      };
      q('#s-go').onclick = () => {
        GM_setValue('forceEnter', now());
        setTimeout(() => { location.href = FOLIO_MAIN; }, 30);
      };
      q('#retry').onclick = () => {
        try { sessionStorage.removeItem('nw_tries'); } catch (e) {}
        setTimeout(() => location.reload(), 30);
      };
      q('#s-save').onclick = () => {
        const wasNeed = curState && curState.st === 'need';
        const d = sh.querySelector('input[name="nwd"]:checked');
        const c = sh.querySelector('input[name="nwc"]:checked');
        GM_setValue('id', q('#s-id').value.trim());
        GM_setValue('pw', q('#s-pw').value);
        GM_setValue('enabled', q('#s-en').checked);
        GM_setValue('showUi', q('#s-ui').checked);
        GM_setValue('fsOn', q('#s-fs').checked);
        GM_setValue('showAll', q('#s-all').checked);
        GM_setValue('doneSec', q('#s-ds').value);
        GM_setValue('dest', d ? d.value : 'auto');
        GM_setValue('customUrl', q('#s-url').value.trim());
        GM_setValue('classMode', c ? c.value : 'name');
        GM_setValue('classKey', q('#s-ck').value.trim());
        GM_setValue('classPick', q('#s-cp').value);
        updateInfo();
        const sv = q('#s-saved');
        if (wasNeed && hasCreds()) {
          sv.textContent = '저장했어요. 로그인을 시작해요';
          try { sessionStorage.removeItem('nw_tries'); } catch (e) {}
          setTimeout(() => location.reload(), 500);
          return;
        }
        sv.textContent = '저장했어요';
        setTimeout(() => { sv.textContent = ''; }, 2000);
      };
    }

    // ---- 창 만들기 ----
    function ensureUi() {
      if (ui && ui.host.isConnected) return ui;
      if (!document.documentElement) return null;
      ensureFont();
      const host = document.createElement('div');
      host.id = ROOT_ID;
      host.style.cssText = 'all:initial;position:fixed;left:0;top:0;width:0;height:0;z-index:2147483647;display:block';
      const sh = host.attachShadow({ mode: 'open' });
      sh.innerHTML = UI_HTML.replace('__CSS__', () => UI_CSS);
      document.documentElement.appendChild(host);
      ui = { host: host, sh: sh, win: sh.getElementById('win'), bar: sh.getElementById('bar'), loaded: {}, labMounted: false };
      const q = (s) => sh.querySelector(s);

      sh.getElementById('bar-img').src = whaleUrl();
      // 페이지의 단축키가 입력 중인 글자를 가로채지 않게
      ['keydown', 'keyup', 'keypress'].forEach((n) => host.addEventListener(n, (e) => e.stopPropagation()));
      ui.win.addEventListener('pointerdown', () => { manualOpen = true; });

      // 버튼
      q('#b-min').onclick = () => { manualOpen = true; setMode('min'); };
      q('#b-hide').onclick = () => { manualOpen = true; setMode('hide'); };
      ui.bar.onclick = () => { manualOpen = true; setMode('open'); };
      ui.bar.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); manualOpen = true; setMode('open'); } };
      sh.querySelectorAll('[data-r]').forEach((b) => { b.onclick = () => { ui.loaded[b.dataset.r] = false; fillList(b.dataset.r); }; });
      const gb = q('#simg');
      gb.onclick = () => {
        storyImgOn = !storyImgOn;
        gb.textContent = storyImgOn ? '이미지 접기' : '이미지도 보기';
        sh.querySelectorAll('#body-story .sx-item').forEach((r) => { if (r.__setImgs) r.__setImgs(storyImgOn); });
      };

      // 창 끌기
      const hd = q('#hd');
      let drag = null;
      hd.addEventListener('pointerdown', (e) => {
        if (e.button !== 0 || e.target.closest('button')) return;
        const r = ui.win.getBoundingClientRect();
        drag = { sx: e.clientX, sy: e.clientY, ox: r.left, oy: r.top };
        try { hd.setPointerCapture(e.pointerId); } catch (x) {}
        e.preventDefault();
      });
      hd.addEventListener('pointermove', (e) => { if (drag) placeWin(drag.ox + e.clientX - drag.sx, drag.oy + e.clientY - drag.sy); });
      const endDrag = (e) => {
        if (!drag) return;
        drag = null;
        try { hd.releasePointerCapture(e.pointerId); } catch (x) {}
        const r = ui.win.getBoundingClientRect();
        jset('uiPos', { x: Math.round(r.left), y: Math.round(r.top) });
      };
      hd.addEventListener('pointerup', endDrag);
      hd.addEventListener('pointercancel', endDrag);

      // 크기 기억
      try {
        let rt = null;
        new ResizeObserver(() => {
          const w = ui.win.offsetWidth, h = ui.win.offsetHeight;
          if (!w || !h) return;
          clearTimeout(rt);
          rt = setTimeout(() => jset('uiSize', { w: w, h: h }), 400);
        }).observe(ui.win);
      } catch (e) {}
      window.addEventListener('resize', () => { if (ui && getMode() === 'open') placeWin(); });

      // 업데이트 안내 확인
      q('#m-ok').onclick = () => { GM_setValue('seenSignal', UPDATE_SIGNAL); q('#modal').style.display = 'none'; };

      initSettings();
      renderTabs();
      applyMode();
      activate(GM_getValue('uiTab', 'share'));
      updateInfo();
      return ui;
    }

    // ---- 상태 표시 ----
    const STAGE_TXT = { working: '작동 중', done: '완료', error: '확인 필요', need: '입력 필요', idle: '대기 중' };

    function updateTime() {
      if (!ui) return;
      const el = ui.sh.getElementById('st-time');
      if (!el || !curState) return;
      let txt = '';
      if (curState.st === 'working') {
        const s = GM_getValue('flowStart', 0);
        if (s && now() - s < 180000) txt = '로그인 후 ' + ((now() - s) / 1000).toFixed(1) + '초';
      } else {
        txt = curState.time || '';
      }
      el.textContent = txt;
      el.style.display = txt ? 'block' : 'none';
    }

    function renderState(u) {
      whenRoot(() => {
        curState = u;
        if (!uiOK()) return;
        const stage = u.st || 'idle';
        // 입력이 필요하거나 오류가 났을 때는 숨겨 둔 창도 다시 열어서 알려 준다
        if ((stage === 'need' || stage === 'error') && getMode() !== 'open') GM_setValue('uiMode', 'open');
        if (!ensureUi()) return;
        applyMode();
        const sh = ui.sh, q = (s) => sh.querySelector(s);
        const st = q('#st');
        st.setAttribute('data-st', stage);
        st.style.display = stage === 'idle' ? 'none' : 'flex';
        q('#dot').setAttribute('data-st', stage);
        q('#bar-dot').setAttribute('data-st', stage);
        q('#chip').textContent = STAGE_TXT[stage] || '';
        q('#st-t').textContent = u.t || '';
        const s = q('#st-s');
        s.textContent = u.s || '';
        s.style.display = u.s ? 'block' : 'none';
        q('#retry').style.display = stage === 'error' ? 'block' : 'none';
        updateInfo();
        updateTime();

        clearInterval(tickTimer);
        clearTimeout(closeTimer);
        if (stage === 'working') tickTimer = setInterval(updateTime, 250);
        if (stage === 'done' && u.closeAt && !manualOpen) {
          closeTimer = setTimeout(() => {
            if (!manualOpen && getMode() === 'open') setMode('min');
          }, Math.max(0, u.closeAt - now()));
        }
        if (stage === 'need') {
          activate('set');
          const idEl = q('#s-id');
          if (idEl && !cfg.id) setTimeout(() => idEl.focus(), 50);
        }
      });
    }

    function say(title, sub, stage, o) {
      o = o || {};
      const u = { t: title, s: sub || '', st: stage || 'working', ts: now(), time: o.time || '', custom: !!o.custom };
      if (u.st === 'done') u.closeAt = now() + cfg.doneSec * 1000;
      GM_setValue('ui', JSON.stringify(u));
      if (cfg.showUi) renderState(u);
    }

    function showNeed() {
      manualOpen = true;
      forceShown = true;
      GM_setValue('uiMode', 'open');
      renderState({
        t: '아이디와 비밀번호를 입력해 주세요',
        s: '아래 계정 탭에 입력하고 저장하면 자동으로 로그인해요.',
        st: 'need',
        ts: now()
      });
    }

    function endFlow() {
      GM_setValue('ui', '');
      if (curState && curState.st !== 'need') renderState(IDLE);
    }

    function flowLive() {
      const u = jget('ui', null);
      return !!(u && u.st === 'working' && now() - u.ts < LIVE_KEEP);
    }

    function finishTime() {
      const s = GM_getValue('flowStart', 0);
      GM_setValue('flowStart', 0);
      if (!s || now() - s > 180000) return '';
      return '로그인부터 ' + ((now() - s) / 1000).toFixed(1) + '초';
    }

    // 업데이트 안내
    const UPDATE_SIGNAL = 'U-20261012-S5-w9Kd2';
    const UPDATE_NOTES = [
      '모든 화면이 하나의 작은 창으로 합쳐졌어요 (끌어서 옮길 수 있어요)',
      '위쪽 탭에서 공유방 · 과제방 · 이야기방을 바로 볼 수 있어요',
      '위쪽 − 버튼을 누르면 왼쪽에 하얀 바로 줄어들고, 바를 누르면 다시 열려요',
      '새 탭 "실험실"에 유용한 기능 ' + (self.NWLab ? self.NWLab.count : 44) + '개가 들어 있어요',
      '사이트에 들어가면 전체화면(F11)으로 바뀌어요 (설정에서 끌 수 있어요)'
    ];
    function checkUpdate() {
      if (!uiOK() || !flowHost() || GM_getValue('seenSignal', '') === UPDATE_SIGNAL) return;
      whenRoot(() => {
        if (!ensureUi()) return;
        const ul = ui.sh.getElementById('m-ul');
        ul.textContent = '';
        UPDATE_NOTES.forEach((n) => ul.appendChild(mk('li', '', n)));
        ui.sh.getElementById('m-sig').textContent = '업데이트 신호값: ' + UPDATE_SIGNAL;
        ui.sh.getElementById('modal').style.display = 'flex';
      });
    }

    // ======================= 목록 (공유방 / 이야기방 / 과제방) =======================
    const BOARD_MAX = 100;   // 공유방
    const STORY_MAX = 40;    // 이야기방
    const TASK_MAX = 60;     // 과제방
    const FOLIO_ORIGIN = 'https://folio.itt.link';
    function mk(tag, cls, text) {
      const e = document.createElement(tag);
      if (cls) e.className = cls;
      if (text != null) e.textContent = text;
      return e;
    }
    const hostOf = (u) => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return u; } };
    const safeUrl = (u) => {
      try { const x = new URL(u, FOLIO_ORIGIN); return /^https?:$/.test(x.protocol) ? x.href : null; } catch (e) { return null; }
    };
    // 게시글 본문(HTML)을 글자만 뽑는다 (스크립트는 실행되지 않음)
    function plain(html) {
      if (!html) return '';
      try {
        const s = String(html).replace(/<br\s*\/?>/gi, '\n').replace(/<\/(p|div|li)>/gi, '\n');
        const doc = new DOMParser().parseFromString(s, 'text/html');
        doc.querySelectorAll('script,style').forEach((e) => e.remove());
        const t = doc.body.textContent || '';
        return t.replace(/ /g, ' ').replace(/\n{3,}/g, '\n\n').trim();
      } catch (e) { return ''; }
    }

    // 현재 보고 있는 반이 "내 반"일 때만 목록 주소(bbsId, trgetId)를 기억한다.
    function myClassNow(name) {
      const m = cfg.classMode;
      if (m === 'name') return !name || name.indexOf(cfg.classKey) > -1;
      const fresh = now() - GM_getValue('enterTs', 0) < 30000;
      if (m === 'pick') return path === cfg.classPick || (isClassPage && fresh);
      return isClassPage && fresh;
    }

    function learnBoardIds() {
      if (host !== 'folio.itt.link') return;
      const idsOf = (code) => {
        const a = document.querySelector('#' + code + ' a');
        if (!a) return null;
        try {
          const u = new URL(a.getAttribute('href'), location.href);
          const bbsId = u.searchParams.get('bbsId'), trgetId = u.searchParams.get('trgetId');
          return bbsId && trgetId ? { bbsId: bbsId, trgetId: trgetId } : null;
        } catch (e) { return null; }
      };
      const share = idsOf('BBSA50');
      if (!share) return;
      const cn = document.querySelector('.classCon a');
      const name = cn ? cn.textContent.replace(/\s+/g, '') : '';
      if (!myClassNow(name)) return;
      const story = idsOf('BBSA20'), task = idsOf('BBSA40');
      jset('boardIds', {
        bbsId: share.bbsId, trgetId: share.trgetId, name: name, ts: now(),
        story: story ? story.bbsId : '', task: task ? task.bbsId : ''
      });
    }
    // 목록 JSON을 불러온다. 로그인 세션(쿠키)은 브라우저가 알아서 보내 준다.
    function loadList(b, max) {
      return new Promise((res) => {
        if (host === 'folio.itt.link') {
          self.NWBoard.pull(location.origin, b, max).then((items) => res({ ok: true, items: items }))
            .catch((e) => res({ ok: false, err: String((e && e.message) || e) }));
          return;
        }
        try {
          chrome.runtime.sendMessage({ t: 'board', b: b, max: max }, (r) => {
            if (chrome.runtime.lastError || !r) res({ ok: false, err: '확장 프로그램 연결 실패' });
            else res(r);
          });
        } catch (e) { res({ ok: false, err: '확장 프로그램 연결 실패' }); }
      });
    }

    const viewUrl = (b, no) => FOLIO_ORIGIN + '/cop/cmy/bbs/selectBoardList.do?bbsId=' + encodeURIComponent(b.bbsId) +
      '&trgetId=' + encodeURIComponent(b.trgetId) + '&nttNo=' + encodeURIComponent(no);
    const downUrl = (f, no) => FOLIO_ORIGIN + '/cmm/fms/FileDown.do?atchFileId=' + encodeURIComponent(f.id) +
      '&fileSn=' + encodeURIComponent(f.sn) + '&nttNo=' + encodeURIComponent(no);
    // 공유방: 아래 가로 바
    function renderShare(it, b) {
      const row = mk('div', 'bd-item');
      const t = mk('a', 'bd-t', it.title);
      t.href = viewUrl(b, it.no);
      row.appendChild(t);
      row.appendChild(mk('div', 'bd-m', [it.who, it.date].filter(Boolean).join(' · ')));
      if (it.links.length || it.files.length) {
        const chips = mk('div', 'bd-chips');
        it.links.forEach((l) => {
          const u = safeUrl(l);
          if (!u) return;
          const a = mk('a', 'bd-c l', '링크 · ' + hostOf(u));
          a.href = u; a.title = u;
          chips.appendChild(a);
        });
        it.files.forEach((f) => {
          const a = mk('a', 'bd-c f', '파일 · ' + (f.n || '첨부파일'));
          a.href = downUrl(f, it.no);
          a.title = f.n || '';
          chips.appendChild(a);
        });
        row.appendChild(chips);
      }
      return row;
    }

    // 이야기방: 글 + 큰 사진 (세로 스크롤)
    const STORY_IMG_MAX = 8;
    let storyImgOn = false; // 위쪽 "이미지도 보기" 버튼 상태
    function renderStory(it, b) {
      const row = mk('div', 'sx-item');
      const who = mk('div', 'sx-who');
      who.appendChild(mk('div', 'sx-name', it.who || '(이름 없음)'));
      who.appendChild(mk('div', 'sx-date', it.date));
      row.appendChild(who);
      let txt = plain(it.cn);
      if (txt.length > 700) txt = txt.slice(0, 700) + '…';
      if (txt) row.appendChild(mk('div', 'sx-txt', txt));
      const imgs = it.files.filter((f) => f.img);
      const rest = it.files.filter((f) => !f.img), links = it.links.map(safeUrl).filter(Boolean);
      // 사진은 "이미지도 보기"를 눌러야 크게 나오고, 안 누르면 그냥 이미지 파일 이름으로만 보여준다
      const imgChips = mk('div', 'bd-chips');
      imgs.forEach((f) => { const a = mk('a', 'bd-c f', '이미지 파일 · ' + (f.n || '이미지')); a.href = downUrl(f, it.no); a.title = f.n; imgChips.appendChild(a); });
      const box = mk('div', 'sx-imgs');
      box.style.display = 'none';
      const fill = () => {
        imgs.slice(0, STORY_IMG_MAX).forEach((f) => {
          const full = downUrl(f, it.no);
          const first = safeUrl(f.src) || full;
          const a = mk('a', 'sx-img');
          a.href = first; a.target = '_blank'; a.rel = 'noopener'; a.title = f.n;
          const im = document.createElement('img');
          im.alt = f.n || '사진';
          let tried = 0;
          im.onerror = () => {
            if (tried++ === 0 && first !== full) { im.src = full; a.href = full; }
            else a.remove();
          };
          im.src = first;
          a.appendChild(im);
          box.appendChild(a);
        });
        if (imgs.length > STORY_IMG_MAX) box.appendChild(mk('div', 'sx-more', '사진 ' + (imgs.length - STORY_IMG_MAX) + '장 더 있어요 (원본 글에서 보기)'));
      };
      if (imgs.length) {
        const btn = mk('button', 'sx-btn');
        btn.type = 'button';
        who.insertBefore(btn, who.lastChild);
        let filled = false;
        row.__setImgs = (on) => {
          if (on && !filled) { filled = true; fill(); }
          box.style.display = on ? 'flex' : 'none';
          imgChips.style.display = on ? 'none' : 'flex';
          btn.classList.toggle('on', on);
          btn.textContent = on ? '이미지 접기' : '이미지도 보기 (' + imgs.length + ')';
          row.__on = on;
        };
        btn.onclick = () => row.__setImgs(!row.__on);
        row.appendChild(box);
        row.appendChild(imgChips);
        row.__setImgs(storyImgOn);
      }
      if (rest.length || links.length) {
        const chips = mk('div', 'bd-chips');
        links.forEach((u) => { const a = mk('a', 'bd-c l', '링크 · ' + hostOf(u)); a.href = u; a.title = u; chips.appendChild(a); });
        rest.forEach((f) => { const a = mk('a', 'bd-c f', '파일 · ' + (f.n || '첨부파일')); a.href = downUrl(f, it.no); a.title = f.n; chips.appendChild(a); });
        row.appendChild(chips);
      }
      const o = mk('a', 'sx-open', '원본 글 열기 ›');
      o.href = viewUrl(b, it.no);
      row.appendChild(o);
      return row;
    }

    // 과제방: 상태(OPEN/READY/CLOSE), 제출 기간, 내 제출 상태
    const taskKind = (it) => it.endAt === 'Y' ? 'close' : (it.startAt === 'N' && it.endAt === 'N' && it.tmp01 ? 'redy' : 'open');
    const TASK_RANK = { open: 0, redy: 1, close: 2 };
    function renderTask(it, b) {
      const k = taskKind(it);
      const a = mk('a', 'tk-item ' + k);
      a.href = viewUrl(b, it.no);
      const top = mk('div', 'tk-top');
      top.appendChild(mk('span', 'tk-chip', { open: 'OPEN', redy: 'READY', close: 'CLOSE' }[k]));
      top.appendChild(mk('div', 'tk-t', it.title));
      a.appendChild(top);
      const sub = [it.room, it.course, it.danwon].filter(Boolean).join(' › ');
      if (sub) a.appendChild(mk('div', 'tk-s', sub));
      const row = mk('div', 'tk-row');
      row.appendChild(mk('span', '', '제출 기간 ' + (it.tmp01 ? it.tmp01 + ' ~ ' + (it.tmp02 || '') : '기한 없음')));
      let st = '', cls = '';
      if (it.reply === 'Y') { st = '평가완료'; cls = 'ok'; }
      else if (it.reply === 'F') { st = k === 'close' ? '제출완료' : '피드백'; cls = 'ok'; }
      else if (it.reply === 'S') { st = '제출중'; }
      else if (k === 'close') { st = '미제출'; cls = 'warn'; }
      else { st = '제출전'; }
      row.appendChild(mk('span', 'tk-st ' + cls, st));
      if (it.priv) row.appendChild(mk('span', '', '· 학생 간 비공개'));
      a.appendChild(row);
      return a;
    }

    const LISTS = {
      share: { key: 'share', label: '공유방', max: BOARD_MAX, render: renderShare },
      task: { key: 'task', label: '과제방', max: TASK_MAX, render: renderTask,
        sort: (x, y) => TASK_RANK[taskKind(x)] - TASK_RANK[taskKind(y)] },
      story: { key: 'story', label: '이야기방', max: STORY_MAX, render: renderStory }
    };

    // 세 목록이 같이 쓰는 불러오기 틀
    async function fillList(key) {
      if (!ui) return;
      const o = LISTS[key];
      if (!o) return;
      const body = ui.sh.getElementById('body-' + key), sub = ui.sh.getElementById('sub-' + key);
      ui.loaded[key] = true;
      const msg = (t, btn) => {
        body.textContent = '';
        const d = mk('div', 'bd-msg', t);
        if (btn) {
          d.appendChild(document.createElement('br'));
          const bt = mk('button', 'sbtn', btn.label);
          bt.type = 'button';
          bt.onclick = btn.fn;
          d.appendChild(bt);
        }
        body.appendChild(d);
      };
      const goClass = () => { GM_setValue('forceEnter', now()); setTimeout(() => { location.href = FOLIO_MAIN; }, 30); };
      const ids = jget('boardIds', null);
      const bbsId = ids && (o.key === 'share' ? ids.bbsId : ids[o.key]);
      if (!ids || !ids.trgetId || !bbsId) {
        ui.loaded[key] = false;
        sub.textContent = '';
        msg(ids && ids.bbsId
          ? o.label + ' 주소를 아직 몰라요. 톡톡클래스 내 반에 한 번 더 들어가면 기억해요.'
          : '주소를 아직 몰라요. 톡톡클래스 내 반에 한 번 들어가면 자동으로 기억해요.',
          { label: '내 반으로 가기', fn: goClass });
        return;
      }
      const b = { bbsId: bbsId, trgetId: ids.trgetId };
      sub.textContent = (ids.name || '');
      msg('불러오는 중...');
      const r = await loadList(b, o.max);
      if (!ui || !ui.host.isConnected) return;
      if (!r.ok) {
        ui.loaded[key] = false;
        msg(r.err === 'LOGIN' ? '로그인이 필요해요. 로그인한 뒤 다시 열어 주세요.' : '불러오지 못했어요 (' + r.err + ')',
            { label: '다시 시도', fn: () => fillList(key) });
        return;
      }
      const items = o.sort ? r.items.slice().sort(o.sort) : r.items;
      if (!items.length) { msg(o.label + '에 올라온 게시물이 없어요.'); return; }
      body.textContent = '';
      body.scrollTop = 0;
      sub.textContent = (ids.name ? ids.name + ' · ' : '') + Math.min(items.length, o.max) + '개';
      items.slice(0, o.max).forEach((it) => body.appendChild(o.render(it, b)));
    }

    // 반 주소를 새로 알게 되면 열려 있는 목록을 다시 불러온다
    function learnAndRefresh() {
      learnBoardIds();
      if (!ui) return;
      ui.loaded = {};
      const t = GM_getValue('uiTab', 'share');
      if (LISTS[t] && getMode() === 'open') fillList(t);
    }
    function runLogin() {
      const MAX = 4;
      const KEY = 'nw_tries';

      const fs = GM_getValue('flowStart', 0);
      if (!fs || now() - fs > 180000) {
        GM_setValue('flowStart', now());
        GM_setValue('dismiss', 0);
      }
      GM_setValue('pending', now());

      if (!curState || curState.st !== 'working') {
        say('지금 사이트: 로그인 페이지', '불러오는 중', 'working');
      }

      let rec;
      try { rec = JSON.parse(sessionStorage.getItem(KEY) || '{}'); } catch (e) { rec = {}; }
      if (!rec.t || now() - rec.t > 60000) rec = { t: now(), n: 0 };
      const save = () => sessionStorage.setItem(KEY, JSON.stringify(rec));

      if (rec.n >= MAX) {
        GM_setValue('pending', 0);
        say('자동 로그인을 멈췄어요', '짧은 시간에 여러 번 시도했어요. 아이디와 비밀번호를 확인한 뒤 다시 시도를 눌러 주세요.', 'error');
        return;
      }

      const used = new WeakSet();
      let stopped = false;
      const vis = (el) => !!el && el.offsetParent !== null;
      const mine = (el) => !!el.closest('#__nw_root__');

      function setVal(el, v) {
        const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value').set;
        el.focus();
        setter.call(el, v);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
      }

      function findBtn() {
        const sel = ['#loginStart', '#loginBtn', 'button.btn_submit',
                     'button[type="submit"]', 'input[type="submit"]'];
        for (const s of sel) {
          const b = document.querySelector(s);
          if (b && !mine(b) && vis(b) && !b.disabled) return b;
        }
        return null;
      }

      function clickBtn(pw) {
        let n = 0;
        const iv = setInterval(() => {
          const b = findBtn();
          if (b) { clearInterval(iv); b.click(); return; }
          if (++n > 60) {
            clearInterval(iv);
            if (pw && pw.form) pw.form.submit();
          }
        }, 25);
      }

      function keepLogin() {
        document.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
          if (mine(cb)) return;
          if (!cb.checked && vis(cb.parentElement || cb)) cb.click();
        });
      }

      function failMsg() {
        const el = document.querySelector('#fail_message, .invalid_desc');
        return (el && el.textContent.trim()) || '';
      }

      function tick() {
        if (stopped) return;
        const pw = Array.from(document.querySelectorAll('input[type="password"]')).filter((x) => !mine(x))[0] || null;
        const id = document.getElementById('user_id');
        const screen = (pw && !mine(pw) && vis(pw)) ? 'pw' : (vis(id) ? 'id' : 'wait');

        const err = failMsg();
        if (err && used.size) {
          stopped = true;
          rec.n = MAX; save();
          GM_setValue('pending', 0);
          say('로그인이 안 됐어요', err, 'error');
          return;
        }

        if (screen === 'wait') return;

        const target = screen === 'pw' ? pw : id;
        if (used.has(target)) return;

        const isPw = screen === 'pw';
        used.add(target);
        rec.n++; save();
        GM_setValue('pending', now());

        say('지금 사이트: ' + (isPw ? '비밀번호 입력' : '이메일 입력'),
            isPw ? '비밀번호를 넣고 로그인을 눌러요' : '이메일을 넣고 다음을 눌러요',
            'working');

        setVal(target, isPw ? cfg.pw : cfg.id);
        if (isPw) keepLogin();
        clickBtn(isPw ? pw : null);
      }

      function start() {
        tick();
        let n = 0;
        const iv = setInterval(() => {
          tick();
          if (stopped || ++n > 750) clearInterval(iv);
        }, 40);
      }
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start, { once: true });
      } else {
        start();
      }
    }

    function runNewtab() {
      const t = GM_getValue('pending', 0);
      const inFlow = flowLive();
      const u = destUrl();

      if ((t && now() - t < 120000) || inFlow) {
        GM_setValue('pending', 0);
        if (u) {
          say('지금 사이트: 뉴탭',
              cfg.dest === 'custom' ? '설정한 주소로 가는 중' : '톡톡클래스로 가는 중',
              'working', { custom: cfg.dest === 'custom' });
          try { window.stop(); } catch (e) {}
          location.replace(u);
        } else {
          say('지금 사이트: 뉴탭', '로그인이 끝났어요', 'done', { time: finishTime(), board: true });
        }
      } else {
        endFlow();
      }
    }

    const pathOf = (href) => {
      try { return new URL(href, location.href).pathname.replace(/;.*$/, ''); } catch (e) { return href; }
    };

    function listClasses() {
      const out = [];
      document.querySelectorAll('section.classList').forEach((sec, i) => {
        const h = sec.querySelector('h3');
        const m = h && h.textContent.match(/(20\d\d)/);
        const year = m ? parseInt(m[1], 10) : 0;
        sec.querySelectorAll('li.cmy a[href^="/cmy/"]').forEach((a) => {
          const st = a.querySelector('.st');
          const name = ((st && st.textContent) || a.textContent).replace(/\s+/g, '');
          const href = a.getAttribute('href');
          out.push({ sec: i, year: year, name: name, href: href, path: pathOf(href) });
        });
      });
      return out;
    }

    function pickClass(final) {
      const all = listClasses();
      if (!all.length) return null;

      if (cfg.classMode === 'pick' && cfg.classPick) {
        const c = all.filter((x) => x.path === cfg.classPick)[0];
        if (c) return c;
        if (!final) return null;
      }
      if (cfg.classMode !== 'top') {
        return all.filter((x) => x.name.indexOf(cfg.classKey) > -1)[0] || null;
      }
      if (!final) return all.filter((x) => x.sec === 0)[0] || null;
      const maxYear = Math.max.apply(null, all.map((x) => x.year));
      return all.filter((x) => x.year === maxYear)[0];
    }

    function rememberClasses(list) {
      const m = jget('classMap', {});
      list.forEach((c) => { m[c.path] = { n: c.name, y: c.year }; });
      jset('classMap', m);
    }

    function autoEnter(quiet) {
      if (!quiet) say('지금 사이트: 톡톡클래스', '내 반 찾는 중', 'working');
      let done = false, mo;

      const go = (c) => {
        done = true;
        if (mo) mo.disconnect();
        rememberClasses(listClasses());
        GM_setValue('enterTs', now());
        say('지금 사이트: 톡톡클래스', c.name + ' 들어가는 중', 'working');
        try { window.stop(); } catch (e) {}
        location.replace(new URL(c.href, location.href).href);
      };

      const attempt = (final) => {
        if (done || !document.body) return;
        const c = pickClass(final);
        if (c) { go(c); return; }
        if (final) {
          done = true;
          if (mo) mo.disconnect();
          if (quiet) return;
          const what = cfg.classMode === 'name' ? cfg.classKey + ' 반이 목록에 없어요'
                     : cfg.classMode === 'pick' ? '고른 반이 목록에 없어요'
                     : '반 목록이 비어 있어요';
          say('들어갈 반을 못 찾았어요', what, 'error');
        }
      };

      mo = new MutationObserver(() => attempt(false));
      mo.observe(document.documentElement, { childList: true, subtree: true });
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => attempt(true), { once: true });
      } else {
        attempt(true);
      }
    }

    function runFolio() {
      const inFlow = flowLive();
      GM_setValue('pending', 0);

      if (isFolioHome) {
        const nav = performance.getEntriesByType && performance.getEntriesByType('navigation')[0];
        const backFwd = !!(nav && nav.type === 'back_forward');
        let refHost = '', refPath = '';
        try { const r = new URL(document.referrer); refHost = r.hostname; refPath = r.pathname; } catch (e) {}
        const inSite = refHost === host && !/^\/uat\//.test(refPath);
        const recent = now() - GM_getValue('enterTs', 0) < 8000;
        const force = now() - GM_getValue('forceEnter', 0) < 20000;
        const noEnter = now() - GM_getValue('noEnter', 0) < 20000;
        GM_setValue('forceEnter', 0);
        GM_setValue('noEnter', 0);

        document.addEventListener('DOMContentLoaded', () => rememberClasses(listClasses()), { once: true });

        if (noEnter) {
          say('반 목록을 저장했어요', '설정 화면에서 고를 수 있어요', 'done');
        } else if (recent && !force) {
          say('반으로 못 들어갔어요', '톡톡클래스 메인으로 돌아왔어요', 'error');
        } else if (force || (cfg.dest === 'auto' && (inFlow || (!backFwd && !inSite)))) {
          autoEnter(false);
        } else if (inFlow) {
          say('지금 사이트: 톡톡클래스', '메인 화면이에요', 'done', { time: finishTime(), board: true });
        } else {
          endFlow();
        }
      } else if (isClassPage) {
        if (inFlow || now() - GM_getValue('enterTs', 0) < 20000) {
          const e = jget('classMap', {})[path];
          const name = e ? (typeof e === 'string' ? e : e.n) : '내 클래스';
          say('지금 사이트: 톡톡클래스', name, 'done', { time: finishTime(), board: true });
        } else {
          endFlow();
        }
      } else if (inFlow && cfg.dest === 'auto') {
        autoEnter(true);
      } else if (inFlow && cfg.dest === 'custom') {
        say('지금 사이트: 톡톡클래스', '도착했어요', 'done', { time: finishTime(), board: true });
      } else {
        endFlow();
      }
    }

    function runOther() {
      const u = jget('ui', null);
      if (u && u.st === 'working' && u.custom && now() - u.ts < 12000) {
        say('지금 사이트: ' + host, '도착했어요', 'done', { time: finishTime(), board: true });
      }
    }

    // ======================= 시작 =======================
    function bootUi() {
      if (!uiOK()) return;
      whenRoot(() => {
        if (!ensureUi()) return;
        if (!cfg.showUi) return;
        const u = jget('ui', null);
        if (!u || !u.t) return;
        if (u.st === 'working') {
          const left = LIVE_KEEP - (now() - u.ts);
          if (left > 0) {
            renderState(u);
            if (!flowHost()) setTimeout(() => { if (curState && curState.st === 'working') renderState(IDLE); }, left);
          }
          return;
        }
        if (u.st === 'done' && u.closeAt && now() < u.closeAt) renderState(u);
      });
    }

    // 사이트에 들어가면 전체화면 (같은 탭에서 같은 사이트를 다시 열 때는 건드리지 않는다)
    function maybeFullscreen() {
      if (!cfg.fsOn || window.top !== window) return;
      try {
        if (sessionStorage.getItem('nw_fs')) return;
        sessionStorage.setItem('nw_fs', '1');
      } catch (e) { return; }
      try { chrome.runtime.sendMessage({ t: 'fs' }, () => { void chrome.runtime.lastError; }); } catch (e) {}
    }

    whenRoot(ensureFont);
    if (self.NWLab) {
      self.NWLab.init({ get: GM_getValue, set: GM_setValue, jget: jget, jset: jset });
      whenRoot(() => self.NWLab.boot());
    }
    maybeFullscreen();
    bootUi();

    const needUi = !hasCreds() && (flowHost() || getMode() !== 'hide');
    if (needUi) {
      showNeed();
    } else if (host === 'auth.worksmobile.com') {
      if (cfg.enabled) runLogin();
    } else if (host === 'newtab.itt.link') {
      runNewtab();
    } else if (host === 'folio.itt.link') {
      runFolio();
    } else {
      runOther();
    }

    if (host === 'folio.itt.link') {
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', learnAndRefresh, { once: true });
      else learnAndRefresh();
    }
    checkUpdate();

    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (ui && getMode() === 'open' && e.composedPath().indexOf(ui.host) > -1) { manualOpen = true; setMode('min'); }
        return;
      }
      const one = (e.ctrlKey || e.altKey) && !e.shiftKey && (e.code === 'Digit1' || e.key === '1');
      const two = (e.ctrlKey || e.altKey) && !e.shiftKey && (e.code === 'Digit2' || e.key === '2');
      if (one) {
        e.preventDefault();
        e.stopPropagation();
        toggleUi();
      } else if (two) {
        e.preventDefault();
        e.stopPropagation();
        forceShown = true;
        manualOpen = true;
        if (!ensureUi()) return;
        if (getMode() !== 'open') setMode('open'); else nextTab();
      }
    }, true);

    try {
      chrome.runtime.onMessage.addListener((m) => {
        if (m && m.t === 'toggle') toggleUi();
      });
    } catch (e) {}
  }

  try {
    chrome.storage.local.get(null, (data) => {
      Object.assign(cache, data || {});
      main();
    });
  } catch (e) {
    main();
  }
})();
