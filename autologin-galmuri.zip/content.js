(function () {
  'use strict';

  const cache = {};

  function GM_getValue(k, d) {
    return Object.prototype.hasOwnProperty.call(cache, k) ? cache[k] : d;
  }
  function GM_setValue(k, v) {
    cache[k] = v;
    try { chrome.storage.local.set({ [k]: v }); } catch (e) {}
  }

  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area !== 'local') return;
      for (const k in ch) {
        if (ch[k].newValue === undefined) delete cache[k]; else cache[k] = ch[k].newValue;
      }
    });
  } catch (e) {}

  function main() {
    const DEFAULT_CLASS = '6학년2반';
    const FOLIO_MAIN = 'https://folio.itt.link/cop/cmy/index.do';
    const FLOW_HOSTS = ['auth.worksmobile.com', 'newtab.itt.link', 'folio.itt.link'];
    const LIVE_KEEP = 30000;

    const host = location.hostname;
    const path = location.pathname.replace(/;.*$/, '');
    const now = () => Date.now();

    const isFolioHome = host === 'folio.itt.link' &&
      /^\/(index\.do|main\.do|cop\/cmy\/(index|main)\.do)?$/.test(path);
    const isClassPage = host === 'folio.itt.link' && /^\/cmy\/[^\/]+\.do$/.test(path);

    const jget = (k, d) => {
      try { const v = GM_getValue(k, ''); return v ? JSON.parse(v) : d; } catch (e) { return d; }
    };
    const jset = (k, v) => GM_setValue(k, JSON.stringify(v));

    const cfg = {
      get id() { return GM_getValue('id', ''); },
      get pw() { return GM_getValue('pw', ''); },
      get enabled() { return GM_getValue('enabled', true); },
      get showUi() { return GM_getValue('showUi', true); },
      get boardOn() { return GM_getValue('boardOn', true); },
      get doneSec() {
        const n = parseInt(GM_getValue('doneSec', 3), 10);
        return isNaN(n) ? 3 : Math.min(30, Math.max(1, n));
      },
      get dest() {
        const d = GM_getValue('dest', 'auto');
        return (d === 'classroom' || d === 'class') ? 'auto' : d;
      },
      get custom() { return GM_getValue('customUrl', ''); },
      get classMode() { return GM_getValue('classMode', 'name'); },
      get classKey() { return (GM_getValue('classKey', '') || DEFAULT_CLASS).replace(/\s+/g, ''); },
      get classPick() { return GM_getValue('classPick', ''); }
    };

    const hasCreds = () => !!(cfg.id && cfg.pw);

    function destUrl() {
      const d = cfg.dest;
      if (d === 'auto' || d === 'folio') return FOLIO_MAIN;
      if (d === 'custom' && cfg.custom) return cfg.custom;
      return null;
    }

    function fontCss() {
      let u = '';
      try { u = chrome.runtime.getURL('font.woff2'); } catch (e) {}
      return u ? "@font-face{font-family:'Galmuri9';src:url('" + u + "') format('woff2');font-display:block}" : '';
    }

    const ROOT_CSS = `
#__nw_panel__{position:fixed;inset:0;z-index:2147483647;background:#f1f5f9;display:flex;align-items:center;
  justify-content:center;overflow:hidden;margin:0;padding:0;color:#1e293b;font-size:14px;line-height:1.4;text-align:left}`;

    const RAW_CSS = `
*{box-sizing:border-box;margin:0;padding:0;font-family:'Galmuri9','Malgun Gothic','Apple SD Gothic Neo',sans-serif!important}
.nw-main{display:flex;align-items:center;justify-content:center;gap:20px;padding:6px;width:940px;height:530px;flex:none;transform-origin:center center}
.nw-card{background:#fff;border-radius:16px;box-shadow:0 10px 25px -5px rgba(0,0,0,.08);border:1px solid #e2e8f0;padding:20px;display:flex;flex-direction:column}

.nw-left{width:320px;height:490px;flex:none;gap:8px}
.nw-imgbox{width:100%;height:170px;flex:none;display:flex;align-items:center;justify-content:center;text-align:center}
.nw-big{font-size:52px;font-weight:700;line-height:1.15;color:#1e293b;letter-spacing:2px}
.nw-lsec{width:100%;flex:1;min-height:0;display:flex;flex-direction:column;justify-content:flex-end;gap:6px}
.nw-label{font-size:14px;font-weight:600;color:#475569;display:flex;align-items:center;gap:8px}
.nw-chip{display:inline-block;padding:2px 10px;border-radius:12px;background:#94a3b8;color:#fff;font-size:12px;font-weight:700}
.nw-box{width:100%;min-height:100px;padding:10px 12px;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc}
.nw-box[data-st=working]{background:#eff6ff;border-color:#93c5fd}
.nw-box[data-st=working] .nw-chip{background:#2563eb}
.nw-box[data-st=done]{background:#f0fdf4;border-color:#86efac}
.nw-box[data-st=done] .nw-chip{background:#22c55e}
.nw-box[data-st=error]{background:#fef2f2;border-color:#fca5a5}
.nw-box[data-st=error] .nw-chip{background:#ef4444}
.nw-box[data-st=need]{background:#fffbeb;border-color:#fcd34d}
.nw-box[data-st=need] .nw-chip{background:#f59e0b}
.nw-st-t{font-size:15px;font-weight:700;color:#1e293b;word-break:keep-all}
.nw-st-s{font-size:12px;color:#475569;margin-top:3px;line-height:1.45;word-break:keep-all}
.nw-st-time{font-size:11px;color:#94a3b8;margin-top:4px}
.nw-btn{width:100%;padding:11px;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:700;cursor:pointer;flex:none;margin-top:6px}
.nw-btn.red{background:#ef4444}
.nw-btn.red:hover{background:#dc2626}
.nw-btn.out{background:#f8fafc;color:#475569;border:1px solid #cbd5e1}
.nw-btn.out:hover{background:#f1f5f9;color:#1e293b}

.nw-right{flex:1 1 0;min-width:0;height:490px;display:flex;flex-direction:column;gap:10px}
.nw-right>.nw-card{min-width:0;min-height:0;overflow:hidden}
.nw-set{flex:0 0 58%;padding:14px 16px}
.nw-info{flex:1;padding:10px 14px}
.nw-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid #f1f5f9;flex:none}
.nw-title{font-size:16px;font-weight:700;color:#1e293b}
.nw-badge{background:#fee2e2;color:#b91c1c;font-size:11px;font-weight:600;padding:3px 10px;border-radius:20px}

.nw-tabs{display:flex;gap:4px;margin-bottom:6px;flex:none}
.nw-tab{padding:3px 10px;font-size:12px;border:1px solid #e2e8f0;border-radius:6px;background:#fff;color:#64748b;cursor:pointer}
.nw-tab.on{background:#0f172a;color:#fff;border-color:#0f172a}
.nw-body{flex:1;min-height:0;overflow-y:auto;padding-right:4px}
.nw-pane{display:none}
.nw-pane.on{display:block}
.nw-row{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:6px 2px;border-bottom:1px solid #f1f5f9;font-size:13px;color:#334155;cursor:pointer}
.nw-row.col{flex-direction:column;align-items:stretch;cursor:default;gap:3px}
.nw-row.rad{justify-content:flex-start}
.nw-row input[type=checkbox],.nw-row input[type=radio]{width:16px;height:16px;accent-color:#2563eb;flex:none;cursor:pointer}
.nw-lb{font-size:11px;color:#64748b}
.nw-in{width:100%;padding:6px 8px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;background:#fff;color:#1e293b;outline:none}
.nw-in:focus{border-color:#2563eb}
.nw-in.num{width:72px;text-align:right}
.nw-two{display:flex;gap:6px;align-items:center}
.nw-foot{display:flex;justify-content:flex-end;align-items:center;gap:6px;padding-top:8px;flex:none}
.nw-sbtn{padding:6px 12px;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc;color:#334155;font-size:12px;font-weight:700;cursor:pointer;white-space:nowrap}
.nw-sbtn:hover{background:#eff6ff;border-color:#2563eb}
.nw-sbtn.main{background:#2563eb;border-color:#2563eb;color:#fff}
.nw-sbtn.main:hover{background:#1d4ed8}
.nw-saved{color:#16a34a;font-weight:700;font-size:12px;margin-right:auto}

.nw-ibody{flex:1;min-height:0;display:grid;grid-template-columns:1fr 1fr;gap:10px}
.nw-ibox{border-radius:12px;border:1px solid #e2e8f0;background:#f8fafc;padding:10px 14px;display:flex;flex-direction:column;gap:5px;min-width:0;overflow:hidden}
.nw-ih{font-size:12px;font-weight:700;color:#4338ca}
.nw-k{font-size:10px;color:#64748b;margin-top:2px}
.nw-v{font-size:13px;font-weight:700;color:#1e293b;word-break:break-all;line-height:1.35}`;

    const PANEL_CSS = ROOT_CSS + RAW_CSS.replace(/([^{}]+)\{/g, (m, sel) =>
      sel.split(',').map((s) => '#__nw_panel__ ' + s.trim()).join(',') + '{');

    const PANEL_HTML = `
<style>${fontCss()}${PANEL_CSS}</style>
<div class="nw-main" id="__nw_main__">

  <div class="nw-card nw-left">
    <div class="nw-imgbox"><div class="nw-big">자동<br>로그인</div></div>
    <div class="nw-lsec">
      <div class="nw-label">지금 하는 일 <span class="nw-chip" id="__nw_chip__">대기 중</span></div>
      <div class="nw-box" id="__nw_status__" data-st="idle">
        <div class="nw-st-t" id="__nw_st_t__"></div>
        <div class="nw-st-s" id="__nw_st_s__"></div>
        <div class="nw-st-time" id="__nw_st_time__"></div>
      </div>
      <button type="button" class="nw-btn out" id="__nw_retry__" style="display:none">다시 시도</button>
    </div>
    <button type="button" class="nw-btn red" id="__nw_close__">닫기</button>
  </div>

  <div class="nw-right">
    <div class="nw-card nw-set">
      <div class="nw-head">
        <div class="nw-title">설정</div>
        <div class="nw-badge">Ctrl+1 · Alt+1 · Esc</div>
      </div>
      <div class="nw-tabs">
        <button type="button" class="nw-tab on" data-p="acc">계정</button>
        <button type="button" class="nw-tab" data-p="act">동작</button>
        <button type="button" class="nw-tab" data-p="dst">이동</button>
        <button type="button" class="nw-tab" data-p="cls">반</button>
      </div>
      <div class="nw-body">
        <div class="nw-pane on" data-p="acc">
          <div class="nw-row col"><span class="nw-lb">아이디</span><input class="nw-in" id="__nw_id__" type="text" autocomplete="off"></div>
          <div class="nw-row col"><span class="nw-lb">비밀번호</span><div class="nw-two"><input class="nw-in" id="__nw_pw__" type="password" autocomplete="new-password"><button type="button" class="nw-sbtn" id="__nw_pwshow__">비밀번호 보이기</button></div></div>
        </div>
        <div class="nw-pane" data-p="act">
          <label class="nw-row"><span>자동 로그인 사용</span><input type="checkbox" id="__nw_en__"></label>
          <label class="nw-row"><span>작동 중 화면 표시</span><input type="checkbox" id="__nw_ui__"></label>
          <label class="nw-row"><span>로그인 후 공유방·이야기방·과제방 목록 보여주기</span><input type="checkbox" id="__nw_bd__"></label>
          <div class="nw-row"><span>완료 후 화면 유지 (초)</span><input class="nw-in num" id="__nw_ds__" type="number" min="1" max="30"></div>
        </div>
        <div class="nw-pane" data-p="dst">
          <label class="nw-row rad"><input type="radio" name="nwd" value="auto"><span>내 반으로 바로 들어가기</span></label>
          <label class="nw-row rad"><input type="radio" name="nwd" value="folio"><span>톡톡클래스 메인</span></label>
          <label class="nw-row rad"><input type="radio" name="nwd" value="stay"><span>이동 안 함</span></label>
          <label class="nw-row rad"><input type="radio" name="nwd" value="custom"><span>직접 입력</span></label>
          <div class="nw-row col"><input class="nw-in" id="__nw_url__" type="text" placeholder="https://..."></div>
        </div>
        <div class="nw-pane" data-p="cls">
          <label class="nw-row rad"><input type="radio" name="nwc" value="name"><span>이름으로 찾기</span></label>
          <div class="nw-row col"><input class="nw-in" id="__nw_ck__" type="text" placeholder="예: 6학년2반"></div>
          <label class="nw-row rad"><input type="radio" name="nwc" value="pick"><span>목록에서 고르기</span></label>
          <div class="nw-row col"><div class="nw-two"><select class="nw-in" id="__nw_cp__"></select><button type="button" class="nw-sbtn" id="__nw_reload__">목록 불러오기</button></div></div>
          <label class="nw-row rad"><input type="radio" name="nwc" value="top"><span>올해 맨 위 반</span></label>
        </div>
      </div>
      <div class="nw-foot">
        <span class="nw-saved" id="__nw_saved__"></span>
        <button type="button" class="nw-sbtn" id="__nw_go__">지금 내 반으로</button>
        <button type="button" class="nw-sbtn main" id="__nw_save__">저장</button>
      </div>
    </div>

    <div class="nw-card nw-info">
      <div class="nw-head" style="margin-bottom:6px;padding-bottom:4px"><div class="nw-title">현재 사이트 · 내 계정</div></div>
      <div class="nw-ibody">
        <div class="nw-ibox">
          <div class="nw-ih">현재 사이트</div>
          <div><div class="nw-k">사이트</div><div class="nw-v" id="__nw_site_n__"></div></div>
          <div><div class="nw-k">주소</div><div class="nw-v" id="__nw_site_u__" style="font-size:11px;font-weight:400"></div></div>
          <div><div class="nw-k">로그인 후 이동</div><div class="nw-v" id="__nw_site_d__"></div></div>
        </div>
        <div class="nw-ibox">
          <div class="nw-ih">내 계정</div>
          <div><div class="nw-k">이메일</div><div class="nw-v" id="__nw_a_id__"></div></div>
          <div><div class="nw-k">비밀번호</div><div class="nw-v" id="__nw_a_pw__"></div></div>
          <div><div class="nw-k">들어갈 반</div><div class="nw-v" id="__nw_a_c__"></div></div>
        </div>
      </div>
    </div>
  </div>
</div>`;

    let boardAfterPanel = false, fsGrant = false;
    let curState = null, prevOverflow = '', closeTimer = null, tickTimer = null, manualOpen = false, pwShown = false, pwTimer = null;
    const IDLE = { t: '대기 중', s: 'Ctrl+1 또는 Alt+1로 열고 닫아요', st: 'idle', ts: 0 };
    const dismissed = () => now() - GM_getValue('dismiss', 0) < 120000;

    function whenRoot(fn, n) {
      n = n || 0;
      if (document.documentElement) { fn(); return; }
      if (n < 400) setTimeout(() => whenRoot(fn, n + 1), 5);
    }

    function fitPanel() {
      const m = document.getElementById('__nw_main__');
      if (!m) return;
      const k = Math.max(0.4, Math.min(window.innerWidth / 940, window.innerHeight / 530, 3));
      m.style.transform = 'scale(' + k + ')';
    }

    const DEST_LABEL = {
      auto: '내 반으로 바로 들어가기',
      folio: '톡톡클래스 메인',
      stay: '이동 안 함',
      custom: '직접 입력한 주소'
    };

    function siteName() {
      if (host === 'auth.worksmobile.com') return 'NAVER WORKS 로그인';
      if (host === 'newtab.itt.link') return '아이톡톡 뉴탭';
      if (host === 'folio.itt.link') {
        if (isClassPage) return '톡톡클래스 (내 반)';
        if (isFolioHome) return '톡톡클래스 메인';
        return '톡톡클래스';
      }
      return host;
    }

    function classLabel() {
      const m = cfg.classMode;
      if (m === 'top') return '올해 맨 위 반';
      if (m === 'pick') {
        const e = jget('classMap', {})[cfg.classPick];
        return e ? (typeof e === 'string' ? e : e.n) : '(목록에서 고른 반)';
      }
      return cfg.classKey;
    }

    function updateInfo() {
      const set = (id, t) => { const e = document.getElementById(id); if (e) e.textContent = t; };
      set('__nw_a_id__', cfg.id || '입력 필요');
      set('__nw_a_pw__', cfg.pw ? (pwShown ? cfg.pw : '*'.repeat(cfg.pw.length)) : '입력 필요');
      set('__nw_a_c__', classLabel());
      set('__nw_site_n__', siteName());
      set('__nw_site_u__', host + path);
      set('__nw_site_d__', DEST_LABEL[cfg.dest] || cfg.dest);
    }

    function updateTime() {
      const el = document.getElementById('__nw_st_time__');
      if (!el || !curState) return;
      let txt = '';
      if (curState.st === 'working') {
        const s = GM_getValue('flowStart', 0);
        if (s && now() - s < 180000) txt = '로그인 후 ' + ((now() - s) / 1000).toFixed(1) + '초';
      } else {
        txt = curState.time || '';
      }
      el.textContent = txt;
      el.style.display = txt ? 'block' : 'none';
    }

    function removePanel(fade) {
      const p = document.getElementById('__nw_panel__');
      if (!p) return;
      clearInterval(tickTimer);
      clearTimeout(closeTimer);
      clearTimeout(pwTimer);
      pwShown = false;
      document.documentElement.style.overflow = prevOverflow;
      manualOpen = false;
      if (fade) {
        p.style.transition = 'opacity .4s';
        p.style.opacity = '0';
        setTimeout(() => p.remove(), 400);
      } else {
        p.remove();
      }
      if (boardAfterPanel) {
        boardAfterPanel = false;
        if (cfg.boardOn) openBoard();
      }
    }

    function closeByUser() {
      GM_setValue('dismiss', now());
      removePanel(false);
    }

    function initPanel(p) {
      const q = (s) => p.querySelector(s);
      const all = (s) => p.querySelectorAll(s);

      q('#__nw_id__').value = cfg.id;
      q('#__nw_pw__').value = cfg.pw;
      q('#__nw_en__').checked = cfg.enabled;
      q('#__nw_ui__').checked = cfg.showUi;
      q('#__nw_bd__').checked = cfg.boardOn;
      q('#__nw_ds__').value = cfg.doneSec;
      all('input[name="nwd"]').forEach((r) => { r.checked = r.value === cfg.dest; });
      q('#__nw_url__').value = cfg.custom;
      all('input[name="nwc"]').forEach((r) => { r.checked = r.value === cfg.classMode; });
      q('#__nw_ck__').value = GM_getValue('classKey', '') || DEFAULT_CLASS;
      updateInfo();

      all('.nw-tab').forEach((t) => {
        t.onclick = () => {
          all('.nw-tab').forEach((x) => x.classList.toggle('on', x === t));
          all('.nw-pane').forEach((pn) => pn.classList.toggle('on', pn.getAttribute('data-p') === t.getAttribute('data-p')));
        };
      });

      const sel = q('#__nw_cp__');
      const map = jget('classMap', {});
      const items = Object.keys(map).map((k) => {
        const e = map[k];
        return typeof e === 'string' ? { p: k, n: e, y: 0 } : { p: k, n: e.n, y: e.y || 0 };
      }).sort((a, b) => (b.y - a.y) || a.n.localeCompare(b.n));
      if (!items.length) {
        const o = document.createElement('option');
        o.value = '';
        o.textContent = '아직 목록이 없어요. 옆 버튼으로 불러오세요';
        sel.appendChild(o);
      } else {
        items.forEach((i) => {
          const o = document.createElement('option');
          o.value = i.p;
          o.textContent = (i.y ? i.y + '년 ' : '') + i.n;
          if (i.p === cfg.classPick) o.selected = true;
          sel.appendChild(o);
        });
      }

      const pwIn = q('#__nw_pw__'), pwBtn = q('#__nw_pwshow__');
      const hidePw = () => {
        clearTimeout(pwTimer);
        pwShown = false;
        pwIn.type = 'password';
        pwBtn.textContent = '비밀번호 보이기';
        pwBtn.disabled = false;
        updateInfo();
      };
      pwBtn.onclick = () => {
        clearTimeout(pwTimer);
        pwShown = true;
        pwIn.type = 'text';
        pwBtn.textContent = '3초 후 가려져요';
        pwBtn.disabled = true;
        updateInfo();
        pwTimer = setTimeout(hidePw, 3000);
      };

      q('#__nw_close__').onclick = closeByUser;
      q('#__nw_reload__').onclick = () => {
        GM_setValue('noEnter', now());
        setTimeout(() => { location.href = FOLIO_MAIN; }, 30);
      };
      q('#__nw_go__').onclick = () => {
        GM_setValue('forceEnter', now());
        setTimeout(() => { location.href = FOLIO_MAIN; }, 30);
      };
      q('#__nw_retry__').onclick = () => {
        try { sessionStorage.removeItem('nw_tries'); } catch (e) {}
        GM_setValue('dismiss', 0);
        setTimeout(() => location.reload(), 30);
      };
      q('#__nw_save__').onclick = () => {
        const wasNeed = curState && curState.st === 'need';
        const d = p.querySelector('input[name="nwd"]:checked');
        const c = p.querySelector('input[name="nwc"]:checked');
        GM_setValue('id', q('#__nw_id__').value.trim());
        GM_setValue('pw', q('#__nw_pw__').value);
        GM_setValue('enabled', q('#__nw_en__').checked);
        GM_setValue('showUi', q('#__nw_ui__').checked);
        GM_setValue('boardOn', q('#__nw_bd__').checked);
        GM_setValue('doneSec', q('#__nw_ds__').value);
        GM_setValue('dest', d ? d.value : 'auto');
        GM_setValue('customUrl', q('#__nw_url__').value.trim());
        GM_setValue('classMode', c ? c.value : 'name');
        GM_setValue('classKey', q('#__nw_ck__').value.trim());
        GM_setValue('classPick', q('#__nw_cp__').value);
        updateInfo();
        const sv = q('#__nw_saved__');
        if (wasNeed && hasCreds()) {
          sv.textContent = '저장했어요. 로그인을 시작해요';
          try { sessionStorage.removeItem('nw_tries'); } catch (e) {}
          GM_setValue('dismiss', 0);
          setTimeout(() => location.reload(), 500);
          return;
        }
        sv.textContent = '저장했어요';
        setTimeout(() => { sv.textContent = ''; }, 2000);
      };
    }

    function ensurePanel() {
      let p = document.getElementById('__nw_panel__');
      if (p) return p;
      const root = document.documentElement;
      prevOverflow = root.style.overflow;
      root.style.overflow = 'hidden';
      p = document.createElement('div');
      p.id = '__nw_panel__';
      p.innerHTML = PANEL_HTML;
      root.appendChild(p);
      initPanel(p);
      fitPanel();
      return p;
    }

    function renderState(u) {
      whenRoot(() => {
        // 전체화면은 브라우저를 켜고 처음 들어간 사이트에서 한 번만. (설정 열기·입력 필요·오류는 예외)
        const shown = !!document.getElementById('__nw_panel__');
        if (!shown && !fsGrant && !manualOpen && u.st !== 'need' && u.st !== 'error') { curState = u; return; }
        const p = ensurePanel();
        curState = u;
        const stage = u.st || 'idle';
        const q = (s) => p.querySelector(s);
        q('#__nw_status__').setAttribute('data-st', stage);
        q('#__nw_chip__').textContent = { working: '작동 중', done: '완료', error: '확인 필요', need: '입력 필요', idle: '대기 중' }[stage] || '';
        q('#__nw_st_t__').textContent = u.t || '';
        const s = q('#__nw_st_s__');
        s.textContent = u.s || '';
        s.style.display = u.s ? 'block' : 'none';
        q('#__nw_retry__').style.display = stage === 'error' ? 'block' : 'none';
        updateInfo();
        updateTime();
        fitPanel();

        clearInterval(tickTimer);
        clearTimeout(closeTimer);
        if (stage === 'working') tickTimer = setInterval(updateTime, 250);
        if ((stage === 'done' || stage === 'idle') && u.closeAt && !manualOpen) {
          closeTimer = setTimeout(() => {
            removePanel(true);
            GM_setValue('ui', '');
          }, Math.max(0, u.closeAt - now()));
        }
        if (stage === 'need') {
          const idEl = q('#__nw_id__');
          if (idEl && !cfg.id) setTimeout(() => idEl.focus(), 50);
        }
      });
    }

    function say(title, sub, stage, o) {
      o = o || {};
      const u = { t: title, s: sub || '', st: stage || 'working', ts: now(), time: o.time || '', custom: !!o.custom };
      if (u.st === 'done') u.closeAt = now() + cfg.doneSec * 1000;
      GM_setValue('ui', JSON.stringify(u));
      if (cfg.showUi && !dismissed()) renderState(u);
      if (u.st === 'done' && o.board && cfg.boardOn && now() - GM_getValue('boardTs', 0) > 10000) {
        GM_setValue('boardTs', now());
        // 전체화면이 떠 있으면 그게 닫힌 뒤에, 아니면 바로 목록을 연다
        if (document.getElementById('__nw_panel__')) boardAfterPanel = true; else openBoard();
      }
    }

    function showNeed() {
      manualOpen = true;
      GM_setValue('dismiss', 0);
      renderState({
        t: '아이디와 비밀번호를 입력해 주세요',
        s: '오른쪽 설정의 계정 탭에 입력하고 저장하면 자동으로 로그인해요.',
        st: 'need',
        ts: now()
      });
    }

    function endFlow() {
      GM_setValue('ui', '');
      if (!manualOpen) removePanel(false);
    }

    function flowLive() {
      const u = jget('ui', null);
      return !!(u && u.st === 'working' && now() - u.ts < LIVE_KEEP);
    }

    function finishTime() {
      const s = GM_getValue('flowStart', 0);
      GM_setValue('flowStart', 0);
      if (!s || now() - s > 180000) return '';
      return '로그인부터 ' + ((now() - s) / 1000).toFixed(1) + '초';
    }

    function togglePanel() {
      if (document.getElementById('__nw_panel__')) { closeByUser(); return; }
      manualOpen = true;
      GM_setValue('dismiss', 0);
      if (!hasCreds()) { showNeed(); return; }
      const u = jget('ui', null);
      const live = u && u.st === 'working' && now() - u.ts < LIVE_KEEP;
      renderState(live ? u : IDLE);
    }

    function runLogin() {
      const MAX = 4;
      const KEY = 'nw_tries';

      const fs = GM_getValue('flowStart', 0);
      if (!fs || now() - fs > 180000) {
        GM_setValue('flowStart', now());
        GM_setValue('dismiss', 0);
      }
      GM_setValue('pending', now());

      if (!curState || curState.st !== 'working') {
        say('지금 사이트: 로그인 페이지', '불러오는 중', 'working');
      }

      let rec;
      try { rec = JSON.parse(sessionStorage.getItem(KEY) || '{}'); } catch (e) { rec = {}; }
      if (!rec.t || now() - rec.t > 60000) rec = { t: now(), n: 0 };
      const save = () => sessionStorage.setItem(KEY, JSON.stringify(rec));

      if (rec.n >= MAX) {
        GM_setValue('pending', 0);
        say('자동 로그인을 멈췄어요', '짧은 시간에 여러 번 시도했어요. 아이디와 비밀번호를 확인한 뒤 다시 시도를 눌러 주세요.', 'error');
        return;
      }

      const used = new WeakSet();
      let stopped = false;
      const vis = (el) => !!el && el.offsetParent !== null;
      const mine = (el) => !!el.closest('#__nw_panel__');

      function setVal(el, v) {
        const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value').set;
        el.focus();
        setter.call(el, v);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
      }

      function findBtn() {
        const sel = ['#loginStart', '#loginBtn', 'button.btn_submit',
                     'button[type="submit"]', 'input[type="submit"]'];
        for (const s of sel) {
          const b = document.querySelector(s);
          if (b && !mine(b) && vis(b) && !b.disabled) return b;
        }
        return null;
      }

      function clickBtn(pw) {
        let n = 0;
        const iv = setInterval(() => {
          const b = findBtn();
          if (b) { clearInterval(iv); b.click(); return; }
          if (++n > 60) {
            clearInterval(iv);
            if (pw && pw.form) pw.form.submit();
          }
        }, 25);
      }

      function keepLogin() {
        document.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
          if (mine(cb)) return;
          if (!cb.checked && vis(cb.parentElement || cb)) cb.click();
        });
      }

      function failMsg() {
        const el = document.querySelector('#fail_message, .invalid_desc');
        return (el && el.textContent.trim()) || '';
      }

      function tick() {
        if (stopped) return;
        const pw = Array.from(document.querySelectorAll('input[type="password"]')).filter((x) => !mine(x))[0] || null;
        const id = document.getElementById('user_id');
        const screen = (pw && !mine(pw) && vis(pw)) ? 'pw' : (vis(id) ? 'id' : 'wait');

        const err = failMsg();
        if (err && used.size) {
          stopped = true;
          rec.n = MAX; save();
          GM_setValue('pending', 0);
          say('로그인이 안 됐어요', err, 'error');
          return;
        }

        if (screen === 'wait') return;

        const target = screen === 'pw' ? pw : id;
        if (used.has(target)) return;

        const isPw = screen === 'pw';
        used.add(target);
        rec.n++; save();
        GM_setValue('pending', now());

        say('지금 사이트: ' + (isPw ? '비밀번호 입력' : '이메일 입력'),
            isPw ? '비밀번호를 넣고 로그인을 눌러요' : '이메일을 넣고 다음을 눌러요',
            'working');

        setVal(target, isPw ? cfg.pw : cfg.id);
        if (isPw) keepLogin();
        clickBtn(isPw ? pw : null);
      }

      function start() {
        tick();
        let n = 0;
        const iv = setInterval(() => {
          tick();
          if (stopped || ++n > 750) clearInterval(iv);
        }, 40);
      }
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start, { once: true });
      } else {
        start();
      }
    }

    function runNewtab() {
      const t = GM_getValue('pending', 0);
      const inFlow = flowLive();
      const u = destUrl();

      if ((t && now() - t < 120000) || inFlow) {
        GM_setValue('pending', 0);
        if (u) {
          say('지금 사이트: 뉴탭',
              cfg.dest === 'custom' ? '설정한 주소로 가는 중' : '톡톡클래스로 가는 중',
              'working', { custom: cfg.dest === 'custom' });
          try { window.stop(); } catch (e) {}
          location.replace(u);
        } else {
          say('지금 사이트: 뉴탭', '로그인이 끝났어요', 'done', { time: finishTime(), board: true });
        }
      } else {
        endFlow();
      }
    }

    const pathOf = (href) => {
      try { return new URL(href, location.href).pathname.replace(/;.*$/, ''); } catch (e) { return href; }
    };

    function listClasses() {
      const out = [];
      document.querySelectorAll('section.classList').forEach((sec, i) => {
        const h = sec.querySelector('h3');
        const m = h && h.textContent.match(/(20\d\d)/);
        const year = m ? parseInt(m[1], 10) : 0;
        sec.querySelectorAll('li.cmy a[href^="/cmy/"]').forEach((a) => {
          const st = a.querySelector('.st');
          const name = ((st && st.textContent) || a.textContent).replace(/\s+/g, '');
          const href = a.getAttribute('href');
          out.push({ sec: i, year: year, name: name, href: href, path: pathOf(href) });
        });
      });
      return out;
    }

    function pickClass(final) {
      const all = listClasses();
      if (!all.length) return null;

      if (cfg.classMode === 'pick' && cfg.classPick) {
        const c = all.filter((x) => x.path === cfg.classPick)[0];
        if (c) return c;
        if (!final) return null;
      }
      if (cfg.classMode !== 'top') {
        return all.filter((x) => x.name.indexOf(cfg.classKey) > -1)[0] || null;
      }
      if (!final) return all.filter((x) => x.sec === 0)[0] || null;
      const maxYear = Math.max.apply(null, all.map((x) => x.year));
      return all.filter((x) => x.year === maxYear)[0];
    }

    function rememberClasses(list) {
      const m = jget('classMap', {});
      list.forEach((c) => { m[c.path] = { n: c.name, y: c.year }; });
      jset('classMap', m);
    }

    function autoEnter(quiet) {
      if (!quiet) say('지금 사이트: 톡톡클래스', '내 반 찾는 중', 'working');
      let done = false, mo;

      const go = (c) => {
        done = true;
        if (mo) mo.disconnect();
        rememberClasses(listClasses());
        GM_setValue('enterTs', now());
        say('지금 사이트: 톡톡클래스', c.name + ' 들어가는 중', 'working');
        try { window.stop(); } catch (e) {}
        location.replace(new URL(c.href, location.href).href);
      };

      const attempt = (final) => {
        if (done || !document.body) return;
        const c = pickClass(final);
        if (c) { go(c); return; }
        if (final) {
          done = true;
          if (mo) mo.disconnect();
          if (quiet) return;
          const what = cfg.classMode === 'name' ? cfg.classKey + ' 반이 목록에 없어요'
                     : cfg.classMode === 'pick' ? '고른 반이 목록에 없어요'
                     : '반 목록이 비어 있어요';
          say('들어갈 반을 못 찾았어요', what, 'error');
        }
      };

      mo = new MutationObserver(() => attempt(false));
      mo.observe(document.documentElement, { childList: true, subtree: true });
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => attempt(true), { once: true });
      } else {
        attempt(true);
      }
    }

    function runFolio() {
      const inFlow = flowLive();
      GM_setValue('pending', 0);

      if (isFolioHome) {
        const nav = performance.getEntriesByType && performance.getEntriesByType('navigation')[0];
        const backFwd = !!(nav && nav.type === 'back_forward');
        let refHost = '', refPath = '';
        try { const r = new URL(document.referrer); refHost = r.hostname; refPath = r.pathname; } catch (e) {}
        const inSite = refHost === host && !/^\/uat\//.test(refPath);
        const recent = now() - GM_getValue('enterTs', 0) < 8000;
        const force = now() - GM_getValue('forceEnter', 0) < 20000;
        const noEnter = now() - GM_getValue('noEnter', 0) < 20000;
        GM_setValue('forceEnter', 0);
        GM_setValue('noEnter', 0);

        document.addEventListener('DOMContentLoaded', () => rememberClasses(listClasses()), { once: true });

        if (noEnter) {
          say('반 목록을 저장했어요', '설정 화면에서 고를 수 있어요', 'done');
        } else if (recent && !force) {
          say('반으로 못 들어갔어요', '톡톡클래스 메인으로 돌아왔어요', 'error');
        } else if (force || (cfg.dest === 'auto' && (inFlow || (!backFwd && !inSite)))) {
          autoEnter(false);
        } else if (inFlow) {
          say('지금 사이트: 톡톡클래스', '메인 화면이에요', 'done', { time: finishTime(), board: true });
        } else {
          endFlow();
        }
      } else if (isClassPage) {
        if (inFlow || now() - GM_getValue('enterTs', 0) < 20000) {
          const e = jget('classMap', {})[path];
          const name = e ? (typeof e === 'string' ? e : e.n) : '내 클래스';
          say('지금 사이트: 톡톡클래스', name, 'done', { time: finishTime(), board: true });
        } else {
          endFlow();
        }
      } else if (inFlow && cfg.dest === 'auto') {
        autoEnter(true);
      } else if (inFlow && cfg.dest === 'custom') {
        say('지금 사이트: 톡톡클래스', '도착했어요', 'done', { time: finishTime(), board: true });
      } else {
        endFlow();
      }
    }

    function runOther() {
      const u = jget('ui', null);
      if (u && u.st === 'working' && u.custom && now() - u.ts < 12000) {
        say('지금 사이트: ' + host, '도착했어요', 'done', { time: finishTime(), board: true });
      }
    }

    // ===== 공유방(아래 가로 바) + 이야기방(왼쪽, 세로 스크롤) + 과제방(오른쪽) =====
    const BOARD_MAX = 100;   // 공유방
    const STORY_MAX = 40;    // 이야기방
    const TASK_MAX = 60;     // 과제방
    const FOLIO_ORIGIN = 'https://folio.itt.link';
    const UPDATE_SIGNAL = 'U-20261012-S4-m8Rt5';
    const UPDATE_NOTES = [
      '사이트에 들어가면 전체화면이 나와요 (브라우저를 켜고 처음 한 번만)',
      '이야기방 사진은 "이미지도 보기"를 눌러야 크게 나와요. 안 누르면 이미지 파일 이름으로만 보여줘요',
      '공유방 목록이 두 줄로 나와요',
      '왼쪽 이야기방 · 오른쪽 과제방 · 아래 공유방',
      'Ctrl+2 또는 Alt+2로 어디서든 열고 닫아요'
    ];

    const BOARD_RAW = `
*{box-sizing:border-box;margin:0;padding:0;font-family:'Galmuri9','Malgun Gothic','Apple SD Gothic Neo',sans-serif!important}
.bd-card{width:min(720px,100%);max-height:100%;background:#fff;border-radius:16px;border:1px solid #e2e8f0;box-shadow:0 10px 25px -5px rgba(0,0,0,.25);display:flex;flex-direction:column;overflow:hidden}
.bd-title{font-size:16px;font-weight:700;color:#1e293b}
.bd-b{padding:6px 12px;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc;color:#334155;font-size:12px;font-weight:700;cursor:pointer;margin-left:6px}
.bd-b:hover{background:#eff6ff;border-color:#2563eb}
.bd-ok{margin-top:14px;width:100%;padding:11px;border:none;border-radius:8px;background:#2563eb;color:#fff;font-size:14px;font-weight:700;cursor:pointer}
.bd-ok:hover{background:#1d4ed8}
.bd-ul{margin:10px 0 0 18px;font-size:13px;color:#334155;line-height:1.7}
.bd-sig{margin-top:10px;font-size:11px;color:#94a3b8;word-break:break-all}`;

    const BAR_RAW = `
*{box-sizing:border-box;margin:0;padding:0;font-family:'Galmuri9','Malgun Gothic','Apple SD Gothic Neo',sans-serif!important}
.bd-pn{pointer-events:auto;min-width:0;min-height:0;background:#fff;border-radius:14px;border:1px solid #e2e8f0;box-shadow:0 4px 20px rgba(15,23,42,.25);display:flex;flex-direction:column;overflow:hidden}
.bd-story{grid-area:1/1/2/2}
.bd-task{grid-area:1/2/2/3}
.bd-bar{grid-area:2/1/3/3}
.bd-head{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:9px 14px;border-bottom:1px solid #f1f5f9;flex:none}
.bd-hl{display:flex;align-items:baseline;gap:8px;min-width:0}
.bd-title{font-size:15px;font-weight:700;color:#1e293b;white-space:nowrap}
.bd-sub{font-size:11px;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bd-btns{display:flex;flex:none}
.bd-b{padding:4px 10px;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc;color:#334155;font-size:12px;font-weight:700;cursor:pointer;margin-left:6px}
.bd-b:hover{background:#eff6ff;border-color:#2563eb}
.bd-b.red{background:#ef4444;border-color:#ef4444;color:#fff}
.bd-msg{margin:auto;padding:12px;text-align:center;color:#475569;font-size:13px;line-height:1.6;word-break:keep-all}
.bd-msg .bd-b{margin:8px 0 0}

.bd-body{flex:1;min-height:0;display:grid;grid-auto-flow:column;grid-template-rows:repeat(2,minmax(0,1fr));grid-auto-columns:250px;gap:8px 10px;overflow-x:auto;overflow-y:hidden;padding:10px 14px 12px;overscroll-behavior:contain;scrollbar-width:thin}
.bd-item{min-width:0;min-height:0;padding:8px 12px;border:1px solid #e2e8f0;border-radius:12px;background:#f8fafc;display:flex;flex-direction:column;min-height:0}
.bd-item:hover{border-color:#93c5fd;background:#f1f7ff}
.bd-t{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:13px;font-weight:700;color:#1e293b;text-decoration:none;word-break:break-all;line-height:1.4}
.bd-t:hover{color:#2563eb;text-decoration:underline}
.bd-m{font-size:11px;color:#94a3b8;margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:none}
.bd-chips{display:flex;flex-wrap:wrap;gap:5px;margin-top:6px;overflow-y:auto;min-height:0;scrollbar-width:thin}
.bd-c{display:inline-block;max-width:100%;padding:3px 9px;border-radius:12px;font-size:11px;text-decoration:none;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bd-c.l{background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe}
.bd-c.f{background:#f0fdf4;color:#15803d;border:1px solid #bbf7d0}
.bd-c:hover{filter:brightness(.93)}

.bd-col{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;overscroll-behavior:contain;scrollbar-width:thin;display:flex;flex-direction:column}
.sx-item{flex:none;padding:16px 18px 18px;border-bottom:8px solid #f1f5f9}
.sx-who{display:flex;align-items:baseline;justify-content:space-between;gap:8px}
.sx-name{font-size:15px;font-weight:700;color:#1e293b}
.sx-date{font-size:11px;color:#94a3b8;flex:none}
.sx-txt{margin-top:8px;font-size:14px;line-height:1.6;color:#334155;white-space:pre-wrap;word-break:break-all}
.sx-imgs{display:flex;flex-direction:column;gap:10px;margin-top:12px}
.sx-img{display:block;width:100%;background:#f1f5f9;border-radius:10px;overflow:hidden;line-height:0;text-align:center}
.sx-img img{max-width:100%;max-height:520px;width:auto;height:auto;object-fit:contain;cursor:zoom-in}
.sx-more{font-size:12px;color:#64748b;text-align:center;padding:2px}
.sx-btn{flex:none;padding:3px 10px;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc;color:#334155;font-size:12px;font-weight:700;cursor:pointer}
.sx-btn:hover{background:#eff6ff;border-color:#2563eb}
.sx-btn.on{background:#2563eb;border-color:#2563eb;color:#fff}
.sx-open{display:inline-block;margin-top:10px;font-size:12px;color:#2563eb;text-decoration:none}
.sx-open:hover{text-decoration:underline}

.tk-item{flex:none;display:block;margin:10px 14px 0;padding:12px 14px;border:1px solid #e2e8f0;border-left:6px solid #94a3b8;border-radius:12px;background:#f8fafc;text-decoration:none;color:inherit}
.tk-item:last-child{margin-bottom:12px}
.tk-item:hover{background:#f1f7ff;border-color:#93c5fd}
.tk-item.open{border-left-color:#2563eb}
.tk-item.redy{border-left-color:#f59e0b}
.tk-top{display:flex;align-items:center;gap:8px}
.tk-chip{flex:none;padding:2px 9px;border-radius:12px;font-size:11px;font-weight:700;color:#fff;background:#94a3b8}
.open .tk-chip{background:#2563eb}
.redy .tk-chip{background:#f59e0b}
.tk-t{font-size:15px;font-weight:700;color:#1e293b;line-height:1.35;word-break:break-all}
.tk-s{margin-top:6px;font-size:12px;color:#64748b;line-height:1.5;word-break:keep-all}
.tk-row{margin-top:6px;display:flex;flex-wrap:wrap;gap:6px;align-items:center;font-size:12px;color:#334155}
.tk-st{padding:2px 8px;border-radius:8px;background:#e2e8f0;color:#334155;font-weight:700}
.tk-st.ok{background:#dcfce7;color:#15803d}
.tk-st.warn{background:#fee2e2;color:#b91c1c}`;

    const scope = (css, ids) => css.replace(/([^{}]+)\{/g, (m, sel) =>
      sel.split(',').map((s) => ids.map((id) => id + ' ' + s.trim()).join(',')).join(',') + '{');

    // 업데이트 안내(가운데 팝업)
    const UPDATE_CSS = '#__nw_update__{position:fixed;inset:0;z-index:2147483647;background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;margin:0;padding:12px;font-size:14px;line-height:1.4;text-align:left;color:#1e293b}' +
      scope(BOARD_RAW, ['#__nw_update__']);
    // 목록 화면: 왼쪽(이야기방, 약 58%) + 오른쪽(과제방) + 아래 전체 폭(공유방 바). 카드 밖은 클릭이 그대로 통과.
    const BOARD_CSS = '#__nw_board__{position:fixed;inset:0;z-index:2147483647;pointer-events:none;margin:0;padding:10px;display:grid;grid-template-columns:58fr 42fr;grid-template-rows:minmax(0,1fr) clamp(280px,42vh,440px);gap:10px;font-size:14px;line-height:1.4;text-align:left;color:#1e293b}' +
      scope(BAR_RAW, ['#__nw_board__']);

    function mk(tag, cls, text) {
      const e = document.createElement(tag);
      if (cls) e.className = cls;
      if (text != null) e.textContent = text;
      return e;
    }
    const hostOf = (u) => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return u; } };
    const safeUrl = (u) => {
      try { const x = new URL(u, FOLIO_ORIGIN); return /^https?:$/.test(x.protocol) ? x.href : null; } catch (e) { return null; }
    };
    // 게시글 본문(HTML)을 글자만 뽑는다 (스크립트는 실행되지 않음)
    function plain(html) {
      if (!html) return '';
      try {
        const s = String(html).replace(/<br\s*\/?>/gi, '\n').replace(/<\/(p|div|li)>/gi, '\n');
        const doc = new DOMParser().parseFromString(s, 'text/html');
        doc.querySelectorAll('script,style').forEach((e) => e.remove());
        const t = doc.body.textContent || '';
        return t.replace(/ /g, ' ').replace(/\n{3,}/g, '\n\n').trim();
      } catch (e) { return ''; }
    }

    // 현재 보고 있는 반이 "내 반"일 때만 목록 주소(bbsId, trgetId)를 기억한다.
    function myClassNow(name) {
      const m = cfg.classMode;
      if (m === 'name') return !name || name.indexOf(cfg.classKey) > -1;
      const fresh = now() - GM_getValue('enterTs', 0) < 30000;
      if (m === 'pick') return path === cfg.classPick || (isClassPage && fresh);
      return isClassPage && fresh;
    }

    function learnBoardIds() {
      if (host !== 'folio.itt.link') return;
      const idsOf = (code) => {
        const a = document.querySelector('#' + code + ' a');
        if (!a) return null;
        try {
          const u = new URL(a.getAttribute('href'), location.href);
          const bbsId = u.searchParams.get('bbsId'), trgetId = u.searchParams.get('trgetId');
          return bbsId && trgetId ? { bbsId: bbsId, trgetId: trgetId } : null;
        } catch (e) { return null; }
      };
      const share = idsOf('BBSA50');
      if (!share) return;
      const cn = document.querySelector('.classCon a');
      const name = cn ? cn.textContent.replace(/\s+/g, '') : '';
      if (!myClassNow(name)) return;
      const story = idsOf('BBSA20'), task = idsOf('BBSA40');
      jset('boardIds', {
        bbsId: share.bbsId, trgetId: share.trgetId, name: name, ts: now(),
        story: story ? story.bbsId : '', task: task ? task.bbsId : ''
      });
    }

    // 목록 JSON을 불러온다. 로그인 세션(쿠키)은 브라우저가 알아서 보내 준다.
    function loadList(b, max) {
      return new Promise((res) => {
        if (host === 'folio.itt.link') {
          self.NWBoard.pull(location.origin, b, max).then((items) => res({ ok: true, items: items }))
            .catch((e) => res({ ok: false, err: String((e && e.message) || e) }));
          return;
        }
        try {
          chrome.runtime.sendMessage({ t: 'board', b: b, max: max }, (r) => {
            if (chrome.runtime.lastError || !r) res({ ok: false, err: '확장 프로그램 연결 실패' });
            else res(r);
          });
        } catch (e) { res({ ok: false, err: '확장 프로그램 연결 실패' }); }
      });
    }

    const viewUrl = (b, no) => FOLIO_ORIGIN + '/cop/cmy/bbs/selectBoardList.do?bbsId=' + encodeURIComponent(b.bbsId) +
      '&trgetId=' + encodeURIComponent(b.trgetId) + '&nttNo=' + encodeURIComponent(no);
    const downUrl = (f, no) => FOLIO_ORIGIN + '/cmm/fms/FileDown.do?atchFileId=' + encodeURIComponent(f.id) +
      '&fileSn=' + encodeURIComponent(f.sn) + '&nttNo=' + encodeURIComponent(no);

    function closeBoard() {
      const p = document.getElementById('__nw_board__');
      if (p) p.remove();
    }

    // 세 목록이 같이 쓰는 불러오기 틀
    async function fillList(p, o) {
      const body = p.querySelector(o.body), sub = p.querySelector(o.sub);
      const msg = (t, btn) => {
        body.textContent = '';
        const d = mk('div', 'bd-msg', t);
        if (btn) {
          d.appendChild(document.createElement('br'));
          const bt = mk('button', 'bd-b', btn.label);
          bt.type = 'button';
          bt.onclick = btn.fn;
          d.appendChild(bt);
        }
        body.appendChild(d);
      };
      const goClass = () => { GM_setValue('forceEnter', now()); setTimeout(() => { location.href = FOLIO_MAIN; }, 30); };
      const ids = jget('boardIds', null);
      const bbsId = ids && (o.key === 'share' ? ids.bbsId : ids[o.key]);
      if (!ids || !ids.trgetId || !bbsId) {
        sub.textContent = '';
        msg(ids && ids.bbsId
          ? o.label + ' 주소를 아직 몰라요. 톡톡클래스 내 반에 한 번 더 들어가면 기억해요.'
          : '주소를 아직 몰라요. 톡톡클래스 내 반에 한 번 들어가면 자동으로 기억해요.',
          { label: '내 반으로 가기', fn: goClass });
        return;
      }
      const b = { bbsId: bbsId, trgetId: ids.trgetId };
      sub.textContent = (ids.name || '');
      msg('불러오는 중...');
      const r = await loadList(b, o.max);
      if (!document.getElementById('__nw_board__')) return;
      if (!r.ok) {
        msg(r.err === 'LOGIN' ? '로그인이 필요해요. 로그인한 뒤 다시 열어 주세요.' : '불러오지 못했어요 (' + r.err + ')',
            { label: '다시 시도', fn: () => fillList(p, o) });
        return;
      }
      const items = o.sort ? r.items.slice().sort(o.sort) : r.items;
      if (!items.length) { msg(o.label + '에 올라온 게시물이 없어요.'); return; }
      body.textContent = '';
      body.scrollLeft = 0;
      body.scrollTop = 0;
      sub.textContent = (ids.name ? ids.name + ' · ' : '') + Math.min(items.length, o.max) + '개' + (o.hint || '');
      items.slice(0, o.max).forEach((it) => body.appendChild(o.render(it, b)));
    }

    // 공유방: 아래 가로 바
    function renderShare(it, b) {
      const row = mk('div', 'bd-item');
      const t = mk('a', 'bd-t', it.title);
      t.href = viewUrl(b, it.no);
      row.appendChild(t);
      row.appendChild(mk('div', 'bd-m', [it.who, it.date].filter(Boolean).join(' · ')));
      if (it.links.length || it.files.length) {
        const chips = mk('div', 'bd-chips');
        it.links.forEach((l) => {
          const u = safeUrl(l);
          if (!u) return;
          const a = mk('a', 'bd-c l', '링크 · ' + hostOf(u));
          a.href = u; a.title = u;
          chips.appendChild(a);
        });
        it.files.forEach((f) => {
          const a = mk('a', 'bd-c f', '파일 · ' + (f.n || '첨부파일'));
          a.href = downUrl(f, it.no);
          a.title = f.n || '';
          chips.appendChild(a);
        });
        row.appendChild(chips);
      }
      return row;
    }

    // 이야기방: 글 + 큰 사진 (세로 스크롤)
    const STORY_IMG_MAX = 8;
    let storyImgOn = false; // 위쪽 "이미지도 보기" 버튼 상태
    function renderStory(it, b) {
      const row = mk('div', 'sx-item');
      const who = mk('div', 'sx-who');
      who.appendChild(mk('div', 'sx-name', it.who || '(이름 없음)'));
      who.appendChild(mk('div', 'sx-date', it.date));
      row.appendChild(who);
      let txt = plain(it.cn);
      if (txt.length > 700) txt = txt.slice(0, 700) + '…';
      if (txt) row.appendChild(mk('div', 'sx-txt', txt));
      const imgs = it.files.filter((f) => f.img);
      const rest = it.files.filter((f) => !f.img), links = it.links.map(safeUrl).filter(Boolean);
      // 사진은 "이미지도 보기"를 눌러야 크게 나오고, 안 누르면 그냥 이미지 파일 이름으로만 보여준다
      const imgChips = mk('div', 'bd-chips');
      imgs.forEach((f) => { const a = mk('a', 'bd-c f', '이미지 파일 · ' + (f.n || '이미지')); a.href = downUrl(f, it.no); a.title = f.n; imgChips.appendChild(a); });
      const box = mk('div', 'sx-imgs');
      box.style.display = 'none';
      const fill = () => {
        imgs.slice(0, STORY_IMG_MAX).forEach((f) => {
          const full = downUrl(f, it.no);
          const first = safeUrl(f.src) || full;
          const a = mk('a', 'sx-img');
          a.href = first; a.target = '_blank'; a.rel = 'noopener'; a.title = f.n;
          const im = document.createElement('img');
          im.alt = f.n || '사진';
          let tried = 0;
          im.onerror = () => {
            if (tried++ === 0 && first !== full) { im.src = full; a.href = full; }
            else a.remove();
          };
          im.src = first;
          a.appendChild(im);
          box.appendChild(a);
        });
        if (imgs.length > STORY_IMG_MAX) box.appendChild(mk('div', 'sx-more', '사진 ' + (imgs.length - STORY_IMG_MAX) + '장 더 있어요 (원본 글에서 보기)'));
      };
      if (imgs.length) {
        const btn = mk('button', 'sx-btn');
        btn.type = 'button';
        who.insertBefore(btn, who.lastChild);
        let filled = false;
        row.__setImgs = (on) => {
          if (on && !filled) { filled = true; fill(); }
          box.style.display = on ? 'flex' : 'none';
          imgChips.style.display = on ? 'none' : 'flex';
          btn.classList.toggle('on', on);
          btn.textContent = on ? '이미지 접기' : '이미지도 보기 (' + imgs.length + ')';
          row.__on = on;
        };
        btn.onclick = () => row.__setImgs(!row.__on);
        row.appendChild(box);
        row.appendChild(imgChips);
        row.__setImgs(storyImgOn);
      }
      if (rest.length || links.length) {
        const chips = mk('div', 'bd-chips');
        links.forEach((u) => { const a = mk('a', 'bd-c l', '링크 · ' + hostOf(u)); a.href = u; a.title = u; chips.appendChild(a); });
        rest.forEach((f) => { const a = mk('a', 'bd-c f', '파일 · ' + (f.n || '첨부파일')); a.href = downUrl(f, it.no); a.title = f.n; chips.appendChild(a); });
        row.appendChild(chips);
      }
      const o = mk('a', 'sx-open', '원본 글 열기 ›');
      o.href = viewUrl(b, it.no);
      row.appendChild(o);
      return row;
    }

    // 과제방: 상태(OPEN/READY/CLOSE), 제출 기간, 내 제출 상태
    const taskKind = (it) => it.endAt === 'Y' ? 'close' : (it.startAt === 'N' && it.endAt === 'N' && it.tmp01 ? 'redy' : 'open');
    const TASK_RANK = { open: 0, redy: 1, close: 2 };
    function renderTask(it, b) {
      const k = taskKind(it);
      const a = mk('a', 'tk-item ' + k);
      a.href = viewUrl(b, it.no);
      const top = mk('div', 'tk-top');
      top.appendChild(mk('span', 'tk-chip', { open: 'OPEN', redy: 'READY', close: 'CLOSE' }[k]));
      top.appendChild(mk('div', 'tk-t', it.title));
      a.appendChild(top);
      const sub = [it.room, it.course, it.danwon].filter(Boolean).join(' › ');
      if (sub) a.appendChild(mk('div', 'tk-s', sub));
      const row = mk('div', 'tk-row');
      row.appendChild(mk('span', '', '제출 기간 ' + (it.tmp01 ? it.tmp01 + ' ~ ' + (it.tmp02 || '') : '기한 없음')));
      let st = '', cls = '';
      if (it.reply === 'Y') { st = '평가완료'; cls = 'ok'; }
      else if (it.reply === 'F') { st = k === 'close' ? '제출완료' : '피드백'; cls = 'ok'; }
      else if (it.reply === 'S') { st = '제출중'; }
      else if (k === 'close') { st = '미제출'; cls = 'warn'; }
      else { st = '제출전'; }
      row.appendChild(mk('span', 'tk-st ' + cls, st));
      if (it.priv) row.appendChild(mk('span', '', '· 학생 간 비공개'));
      a.appendChild(row);
      return a;
    }

    const LISTS = [
      { key: 'share', label: '공유방', body: '#bd-body', sub: '#bd-sub', max: BOARD_MAX, hint: ' (옆으로 스크롤)', render: renderShare },
      { key: 'story', label: '이야기방', body: '#bd-sbody', sub: '#bd-ssub', max: STORY_MAX, hint: ' (아래로 스크롤)', render: renderStory },
      { key: 'task', label: '과제방', body: '#bd-tbody', sub: '#bd-tsub', max: TASK_MAX, render: renderTask,
        sort: (x, y) => TASK_RANK[taskKind(x)] - TASK_RANK[taskKind(y)] }
    ];
    const fillAll = (p) => LISTS.forEach((o) => fillList(p, o));

    function openBoard() {
      if (document.getElementById('__nw_board__')) return;
      whenRoot(() => {
        if (document.getElementById('__nw_board__')) return;
        const p = document.createElement('div');
        p.id = '__nw_board__';
        const head = (title, subId, rId, extra) =>
          '<div class="bd-head"><div class="bd-hl"><div class="bd-title">' + title + '</div><div class="bd-sub" id="' + subId + '"></div></div>' +
          '<div class="bd-btns"><button type="button" class="bd-b" id="' + rId + '">새로고침</button>' + (extra || '') + '</div></div>';
        p.innerHTML = '<style>' + fontCss() + BOARD_CSS + '</style>' +
          '<div class="bd-pn bd-story">' + head('이야기방', 'bd-ssub', 'bd-sr', '<button type="button" class="bd-b" id="bd-simg">이미지도 보기</button>') + '<div class="bd-col" id="bd-sbody"></div></div>' +
          '<div class="bd-pn bd-task">' + head('과제방', 'bd-tsub', 'bd-tr') + '<div class="bd-col" id="bd-tbody"></div></div>' +
          '<div class="bd-pn bd-bar">' + head('공유방 게시물', 'bd-sub', 'bd-r', '<button type="button" class="bd-b red" id="bd-x">닫기</button>') +
          '<div class="bd-body" id="bd-body"></div></div>';
        document.documentElement.appendChild(p);
        // 마우스 휠(세로)을 가로 스크롤로 바꿔 준다 (공유방 바만)
        p.querySelector('#bd-body').addEventListener('wheel', (e) => {
          if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
            e.currentTarget.scrollLeft += e.deltaY;
            e.preventDefault();
          }
        }, { passive: false });
        p.querySelector('#bd-x').onclick = closeBoard;
        p.querySelector('#bd-r').onclick = () => fillList(p, LISTS[0]);
        p.querySelector('#bd-sr').onclick = () => fillList(p, LISTS[1]);
        const gb = p.querySelector('#bd-simg');
        const syncGb = () => { gb.textContent = storyImgOn ? '이미지 접기' : '이미지도 보기'; };
        gb.onclick = () => {
          storyImgOn = !storyImgOn;
          syncGb();
          p.querySelectorAll('#bd-sbody .sx-item').forEach((r) => { if (r.__setImgs) r.__setImgs(storyImgOn); });
        };
        syncGb();
        p.querySelector('#bd-tr').onclick = () => fillList(p, LISTS[2]);
        const go = () => { learnBoardIds(); fillAll(p); };
        if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go, { once: true });
        else go();
      });
    }

    function toggleBoard() {
      if (document.getElementById('__nw_board__')) closeBoard(); else openBoard();
    }

    // 업데이트 안내: 업데이트마다 UPDATE_SIGNAL 값이 달라지고, 확인을 누를 때까지 접속 시마다 보여준다.
    function checkUpdate() {
      if (FLOW_HOSTS.indexOf(host) < 0 || GM_getValue('seenSignal', '') === UPDATE_SIGNAL) return;
      whenRoot(() => {
        if (document.getElementById('__nw_update__')) return;
        const p = document.createElement('div');
        p.id = '__nw_update__';
        p.innerHTML = '<style>' + fontCss() + UPDATE_CSS + '</style><div class="bd-card" style="width:min(420px,100%);padding:20px">' +
          '<div class="bd-title" style="font-size:20px">업데이트 됐어요!</div><ul class="bd-ul" id="nw-up-ul"></ul>' +
          '<div class="bd-sig" id="nw-up-sig"></div><button type="button" class="bd-ok" id="nw-up-ok">확인</button></div>';
        document.documentElement.appendChild(p);
        const ul = p.querySelector('#nw-up-ul');
        UPDATE_NOTES.forEach((n) => ul.appendChild(mk('li', '', n)));
        p.querySelector('#nw-up-sig').textContent = '업데이트 신호값: ' + UPDATE_SIGNAL;
        p.querySelector('#nw-up-ok').onclick = () => { GM_setValue('seenSignal', UPDATE_SIGNAL); p.remove(); };
      });
    }

    (function boot() {
      if (!cfg.showUi || dismissed()) return;
      const u = jget('ui', null);
      if (!u || !u.t) return;
      const flowHost = FLOW_HOSTS.indexOf(host) > -1;
      if (u.st === 'working') {
        const left = LIVE_KEEP - (now() - u.ts);
        if (left > 0) {
          renderState(u);
          if (!flowHost) setTimeout(() => { if (!manualOpen) removePanel(true); }, left);
        }
        return;
      }
      if (u.st === 'done' && u.closeAt && now() < u.closeAt) renderState(u);
    })();

    const needUi = !hasCreds() && (FLOW_HOSTS.indexOf(host) > -1 || !dismissed());
    if (needUi) {
      showNeed();
    } else if (host === 'auth.worksmobile.com') {
      if (cfg.enabled) runLogin();
    } else if (host === 'newtab.itt.link') {
      runNewtab();
    } else if (host === 'folio.itt.link') {
      runFolio();
    } else {
      runOther();
    }

    // 사이트에 들어가면 전체화면 (브라우저를 켜고 처음 한 번만)
    if (hasCreds() && cfg.showUi && !dismissed()) {
      try {
        chrome.runtime.sendMessage({ t: 'fs' }, (r) => {
          if (chrome.runtime.lastError || !r || !r.first) return;
          fsGrant = true;
          const u = jget('ui', null);
          const live = u && u.st === 'working' && now() - u.ts < LIVE_KEEP;
          renderState(live ? u : { t: '대기 중', s: 'Ctrl+1 또는 Alt+1로 열고 닫아요', st: 'idle', ts: now(), closeAt: now() + cfg.doneSec * 1000 });
        });
      } catch (e) {}
    }

    window.addEventListener('resize', fitPanel);

    if (host === 'folio.itt.link') {
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', learnBoardIds, { once: true });
      else learnBoardIds();
    }
    checkUpdate();

    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (document.getElementById('__nw_board__')) { closeBoard(); return; }
        if (document.getElementById('__nw_panel__')) closeByUser();
        return;
      }
      if ((e.ctrlKey || e.altKey) && !e.shiftKey && (e.code === 'Digit2' || e.key === '2')) {
        e.preventDefault();
        e.stopPropagation();
        toggleBoard();
        return;
      }
      if ((e.ctrlKey || e.altKey) && !e.shiftKey && (e.code === 'Digit1' || e.key === '1')) {
        e.preventDefault();
        e.stopPropagation();
        togglePanel();
      }
    }, true);

    try {
      chrome.runtime.onMessage.addListener((m) => {
        if (m && m.t === 'toggle') togglePanel();
        if (m && m.t === 'board-toggle') toggleBoard();
      });
    } catch (e) {}
  }

  try {
    chrome.storage.local.get(null, (data) => {
      Object.assign(cache, data || {});
      main();
    });
  } catch (e) {
    main();
  }
})();
