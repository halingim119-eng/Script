chrome.action.onClicked.addListener((tab) => {
  if (tab.id != null) chrome.tabs.sendMessage(tab.id, { t: 'toggle' }).catch(() => {});
});

// 확장 프로그램을 처음 켰는데 아이디/비밀번호가 없으면 새 탭을 열어 설정 화면을 바로 띄운다.
// (이미 열려 있던 탭에는 content script가 들어가지 않으므로 새 탭이 필요)
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['id', 'pw'], (d) => {
    if (!d || !d.id || !d.pw) chrome.tabs.create({ url: 'https://folio.itt.link/cop/cmy/index.do' });
  });
});

// 다른 사이트(목적지)에서도 목록(공유방·이야기방·과제방)을 불러올 수 있게 대신 가져다 준다.
importScripts('shared.js');

// 전체화면은 브라우저를 켜고 처음 들어간 사이트에서만 한 번 (storage.session은 브라우저를 닫으면 사라짐)
let fsClaimed = false;
chrome.runtime.onMessage.addListener((m, sender, send) => {
  if (m && m.t === 'fs') {
    if (fsClaimed) { send({ first: false }); return false; }
    fsClaimed = true;
    chrome.storage.session.get('fsShown')
      .then((d) => {
        if (d && d.fsShown) { send({ first: false }); return; }
        return chrome.storage.session.set({ fsShown: 1 }).then(() => send({ first: true }));
      })
      .catch(() => send({ first: false }));
    return true;
  }
  if (m && m.t === 'board') {
    self.NWBoard.pull('https://folio.itt.link', m.b, m.max)
      .then((items) => send({ ok: true, items: items }))
      .catch((e) => send({ ok: false, err: String((e && e.message) || e) }));
    return true;
  }
});
