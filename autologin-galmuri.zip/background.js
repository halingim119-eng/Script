chrome.action.onClicked.addListener((tab) => {
  if (tab.id != null) chrome.tabs.sendMessage(tab.id, { t: 'toggle' }).catch(() => {});
});

// 확장 프로그램을 처음 켰는데 아이디/비밀번호가 없으면 새 탭을 열어 설정 화면을 바로 띄운다.
// (이미 열려 있던 탭에는 content script가 들어가지 않으므로 새 탭이 필요)
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['id', 'pw'], (d) => {
    if (!d || !d.id || !d.pw) chrome.tabs.create({ url: 'https://folio.itt.link/cop/cmy/index.do' });
  });
});

// 다른 사이트(목적지)에서도 공유방 목록을 불러올 수 있게 대신 가져다 준다.
const BOARD_MAX = 15;
async function pullBoard(b) {
  const out = [], seen = {};
  for (let page = 1; page <= 3 && out.length < BOARD_MAX; page++) {
    const p = new URLSearchParams({
      trgetId: b.trgetId, bbsId: b.bbsId, nttNo: '', searchOrdrCode: '', searchOrdrCodeDp: '',
      searchCate: '', searchTextbook: '', searchCnd: 'ALL', pageUnit: String(BOARD_MAX),
      pageSize: String(BOARD_MAX), pageIndex: String(page), searchOthbcAt: '', loadingEndYn: 'N',
      ajaxFlag: 'Y', searchWrd: ''
    });
    const r = await fetch('https://folio.itt.link/cop/cmy/bbs/selectBoardList.json?' + p.toString(), { credentials: 'include' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    let j;
    try { j = await r.json(); } catch (e) { throw new Error('LOGIN'); }
    const list = (j && j.data && j.data.resultList) || [];
    let added = 0;
    list.forEach((i) => {
      if (!i || !i.frstRegisterId || seen[i.nttNo] || out.length >= BOARD_MAX) return;
      seen[i.nttNo] = 1;
      added++;
      out.push({
        no: i.nttNo, title: i.nttSj || '(제목 없음)', who: i.ntcrNm || '',
        date: i.frstRegisterPnttmTmp || '',
        links: (i.linkList || []).map((l) => l.link).filter(Boolean),
        files: (i.fileList || []).map((f) => ({ n: f.orignlFileNm, id: f.atchFileId, sn: f.fileSn }))
      });
    });
    if (!added) break;
  }
  return out;
}

chrome.runtime.onMessage.addListener((m, sender, send) => {
  if (m && m.t === 'board') {
    pullBoard(m.b)
      .then((items) => send({ ok: true, items: items }))
      .catch((e) => send({ ok: false, err: String((e && e.message) || e) }));
    return true;
  }
});
