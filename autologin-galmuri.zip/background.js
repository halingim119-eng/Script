chrome.action.onClicked.addListener((tab) => {
  if (tab.id != null) chrome.tabs.sendMessage(tab.id, { t: 'toggle' }).catch(() => {});
});

// 확장 프로그램을 처음 켰는데 아이디/비밀번호가 없으면 새 탭을 열어 설정 화면을 바로 띄운다.
// (이미 열려 있던 탭에는 content script가 들어가지 않으므로 새 탭이 필요)
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['id', 'pw'], (d) => {
    if (!d || !d.id || !d.pw) chrome.tabs.create({ url: 'https://folio.itt.link/cop/cmy/index.do' });
  });
});
