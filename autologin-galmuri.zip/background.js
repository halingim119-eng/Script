chrome.action.onClicked.addListener((tab) => {
  if (tab.id != null) chrome.tabs.sendMessage(tab.id, { t: 'toggle' }).catch(() => {});
});

// 확장 프로그램을 처음 켰는데 아이디/비밀번호가 없으면 새 탭을 열어 설정 화면을 바로 띄운다.
// (이미 열려 있던 탭에는 content script가 들어가지 않으므로 새 탭이 필요)
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['id', 'pw'], (d) => {
    if (!d || !d.id || !d.pw) chrome.tabs.create({ url: 'https://folio.itt.link/cop/cmy/index.do' });
  });
});

// ---- 로그인 진행 중 전체화면 ----
// content.js가 { t:'fs', on:true/false, flow:<flowStart> }를 보내면 창을 전체화면으로 바꾸고,
// 끝나면 원래 상태(보통/최대화)로 되돌린다. 서비스 워커는 꺼질 수 있어서 상태는 storage.session에 둔다.
const FS_KEY = 'fsState';
const getFs = async () => (await chrome.storage.session.get(FS_KEY))[FS_KEY] || {};
const setFs = (o) => chrome.storage.session.set({ [FS_KEY]: o });

async function fsOn(winId, flow) {
  const all = await getFs();
  const cur = all[winId];
  const win = await chrome.windows.get(winId);
  if (win.state === 'fullscreen') return;
  // 같은 로그인 과정에서 이미 전체화면으로 만들었는데 지금 아니라면 사용자가 직접 끈 것 → 다시 켜지 않는다.
  if (cur && cur.flow === flow) return;
  all[winId] = { prev: win.state === 'minimized' ? 'normal' : win.state, flow };
  await setFs(all);
  await chrome.windows.update(winId, { state: 'fullscreen' });
}

async function fsOff(winId) {
  const all = await getFs();
  const cur = all[winId];
  if (!cur) return;
  delete all[winId];
  await setFs(all);
  try {
    const win = await chrome.windows.get(winId);
    if (win.state === 'fullscreen') await chrome.windows.update(winId, { state: cur.prev || 'normal' });
  } catch (e) {}
}

chrome.runtime.onMessage.addListener((m, sender) => {
  if (!m || m.t !== 'fs' || !sender.tab || sender.tab.windowId == null) return;
  const w = sender.tab.windowId;
  (m.on ? fsOn(w, m.flow || 0) : fsOff(w)).catch(() => {});
});

chrome.windows.onRemoved.addListener(async (id) => {
  const all = await getFs();
  if (all[id]) { delete all[id]; await setFs(all); }
});
