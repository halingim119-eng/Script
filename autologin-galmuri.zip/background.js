chrome.action.onClicked.addListener((tab) => {
  if (tab.id != null) chrome.tabs.sendMessage(tab.id, { t: 'toggle' }).catch(() => {});
});

// 확장 프로그램을 처음 켰는데 아이디/비밀번호가 없으면 새 탭을 열어 설정 화면을 바로 띄운다.
// (이미 열려 있던 탭에는 content script가 들어가지 않으므로 새 탭이 필요)
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['id', 'pw'], (d) => {
    if (!d || !d.id || !d.pw) chrome.tabs.create({ url: 'https://folio.itt.link/cop/cmy/index.do' });
  });
});

// 다른 사이트(목적지)에서도 목록(공유방·이야기방·과제방)을 불러올 수 있게 대신 가져다 준다.
importScripts('shared.js');

// 전체화면(F11과 같은 창 상태). 끌 때는 켜기 전 상태(보통 최대화)로 되돌린다.
async function setFullscreen(windowId, mode) {
  try {
    const w = await chrome.windows.get(windowId);
    if (w.type !== 'normal') return;
    const key = 'prev_' + windowId;
    const isFs = w.state === 'fullscreen';
    if (mode === 'on' && isFs) return;
    if (!isFs) {
      await chrome.storage.session.set({ [key]: w.state || 'maximized' });
      await chrome.windows.update(windowId, { state: 'fullscreen' });
    } else {
      const d = await chrome.storage.session.get(key);
      const prev = d[key] && d[key] !== 'fullscreen' ? d[key] : 'maximized';
      await chrome.windows.update(windowId, { state: prev });
    }
  } catch (e) {}
}

chrome.runtime.onMessage.addListener((m, sender, send) => {
  if (m && (m.t === 'fs' || m.t === 'fs-toggle')) {
    if (sender.tab && sender.tab.windowId != null) {
      setFullscreen(sender.tab.windowId, m.t === 'fs' ? 'on' : 'toggle').then(() => send({ ok: true }));
      return true;
    }
    send({ ok: false });
    return false;
  }
  if (m && m.t === 'board') {
    self.NWBoard.pull('https://folio.itt.link', m.b, m.max)
      .then((items) => send({ ok: true, items: items }))
      .catch((e) => send({ ok: false, err: String((e && e.message) || e) }));
    return true;
  }
});
