// 공유방 / 이야기방 / 과제방 목록을 불러오는 공통 코드 (content.js, background.js가 같이 씀)
(function (g) {
  'use strict';
  const PAGE = 20;
  const IMG = /\.(jpe?g|png|gif|webp|bmp|heic|svg)$/i;

  function mapItem(i) {
    const files = (i.fileList || []).map((f) => {
      const cdn = (f.fileCdnUrl && f.fileCdnUrl !== 'null') ? f.fileCdnUrl : f.fileStreWebCours;
      return {
        n: f.orignlFileNm || '', id: f.atchFileId, sn: f.fileSn,
        img: IMG.test(f.orignlFileNm || ''),
        src: (cdn && f.streFileNm) ? (cdn + '/' + f.streFileNm) : ''
      };
    });
    const st = (i.studentList && i.studentList[0]) || {};
    return {
      no: i.nttNo, title: i.nttSj || '(제목 없음)', who: i.ntcrNm || '',
      date: i.frstRegisterPnttmTmp || '', cn: i.nttCn || '',
      links: (i.linkList || []).map((l) => l.link).filter(Boolean),
      files: files,
      // 과제방에서 쓰는 값
      startAt: i.startAt, endAt: i.endAt, tmp01: i.tmp01 || '', tmp02: i.tmp02 || '',
      reply: i.replySttus || '', room: st.assignRoomNm || '', course: i.course || i.sbjectNm || '',
      danwon: i.danwonNm || '', priv: i.othbcAt === 'N'
    };
  }

  async function pull(base, b, max) {
    max = max || 100;
    const out = [], seen = {};
    for (let page = 1; page <= 12 && out.length < max; page++) {
      const p = new URLSearchParams({
        trgetId: b.trgetId, bbsId: b.bbsId, nttNo: '', searchOrdrCode: '', searchOrdrCodeDp: '',
        searchCate: '', searchTextbook: '', searchCnd: 'ALL', pageUnit: String(PAGE),
        pageSize: String(PAGE), pageIndex: String(page), searchOthbcAt: '', loadingEndYn: 'N',
        ajaxFlag: 'Y', searchWrd: ''
      });
      const r = await fetch(base + '/cop/cmy/bbs/selectBoardList.json?' + p.toString(), { credentials: 'include' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      let j;
      try { j = await r.json(); } catch (e) { throw new Error('LOGIN'); }
      const list = (j && j.data && j.data.resultList) || [];
      let added = 0;
      list.forEach((i) => {
        if (!i || !i.frstRegisterId || seen[i.nttNo] || out.length >= max) return;
        seen[i.nttNo] = 1;
        added++;
        out.push(mapItem(i));
      });
      if (!added) break;
    }
    return out;
  }

  g.NWBoard = { pull: pull };
})(self);
